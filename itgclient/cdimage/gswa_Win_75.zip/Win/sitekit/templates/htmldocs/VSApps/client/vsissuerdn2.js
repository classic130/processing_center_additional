var strCertIssuerDN2 = "%%::certIssuerDN%%"
