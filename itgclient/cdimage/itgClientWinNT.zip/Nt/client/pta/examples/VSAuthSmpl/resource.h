//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VSAuthSmpl.rc
//
#define IDD_CREATEPROF                  1000
#define IDC_EDIT1                       1000
#define IDC_USERNAME                    1000
#define IDB_CIRCLE                      1001
#define IDD_OPENPROF                    1001
#define IDB_DIAMOND                     1002
#define IDC_CIRCLE                      1002
#define IDB_SQUARE                      1003
#define IDC_SQUARE                      1003
#define IDB_CROSS                       1004
#define IDC_ELLIPSE                     1004
#define IDB_CROSSBMP                    1004
#define IDB_ELLIPSE                     1005
#define IDC_CROSSBMP                    1005
#define IDB_SEMICIRCLE                  1006
#define IDC_SEMICIRCLE                  1006
#define IDC_DIAMOND                     1007
#define IDC_PASSWRDPOS1                 1008
#define IDC_PASSWRDPOS2                 1009
#define IDC_PASSWRDPOS3                 1010
#define IDC_PASSWRDPOS4                 1011
#define IDC_PASSWRDPOS5                 1012
#define IDC_PASSWRDPOS6                 1013
#define IDC_PASSWRDPOS7                 1014
#define IDC_PASSWRDPOS8                 1015
#define IDC_BUTTON1                     1020
#define IDC_CLEAR                       1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1003
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
