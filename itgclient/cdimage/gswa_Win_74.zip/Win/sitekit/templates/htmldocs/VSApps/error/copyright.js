var COPYRIGHT_STRING = "Copyright &copy; 2014"
