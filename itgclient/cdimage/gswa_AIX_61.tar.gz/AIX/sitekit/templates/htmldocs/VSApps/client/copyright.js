var COPYRIGHT_STRING = "Copyright &copy; 1998-2004"
