int test_main(int argc, char **argv);

#define main(X,Y)	test_main(X,Y)