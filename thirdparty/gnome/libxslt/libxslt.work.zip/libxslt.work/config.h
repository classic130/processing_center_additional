/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* #undef HAVE_ISINF */
/* #undef HAVE_ISNAN */
/* #undef HAVE_POW */
/* #undef HAVE_FLOOR */
/* #undef HAVE_FABS */
#define WITH_DEBUGGER 1

/* Define if you have the _stat function.  */
#define HAVE__STAT 1

/* Define if you have the asctime function.  */
#define HAVE_ASCTIME 1

/* Define if you have the ftime function.  */
#define HAVE_FTIME 1

/* Define if you have the gettimeofday function.  */
#define HAVE_GETTIMEOFDAY 1

/* Define if you have the gmtime function.  */
#define HAVE_GMTIME 1

/* Define if you have the localtime function.  */
#define HAVE_LOCALTIME 1

/* Define if you have the mktime function.  */
#define HAVE_MKTIME 1

/* Define if you have the stat function.  */
#define HAVE_STAT 1

/* Define if you have the time function.  */
#define HAVE_TIME 1

/* Define if you have the <ansidecl.h> header file.  */
/* #undef HAVE_ANSIDECL_H */

/* Define if you have the <dlfcn.h> header file.  */
#define HAVE_DLFCN_H 1

/* Define if you have the <float.h> header file.  */
#define HAVE_FLOAT_H 1

/* Define if you have the <fp_class.h> header file.  */
/* #undef HAVE_FP_CLASS_H */

/* Define if you have the <ieeefp.h> header file.  */
#define HAVE_IEEEFP_H 1

/* Define if you have the <math.h> header file.  */
#define HAVE_MATH_H 1

/* Define if you have the <nan.h> header file.  */
/* #undef HAVE_NAN_H */

/* Define if you have the <stdarg.h> header file.  */
#define HAVE_STDARG_H 1

/* Define if you have the <stdlib.h> header file.  */
#define HAVE_STDLIB_H 1

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H 1

/* Define if you have the <sys/stat.h> header file.  */
#define HAVE_SYS_STAT_H 1

/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1

/* Define if you have the <sys/timeb.h> header file.  */
#define HAVE_SYS_TIMEB_H 1

/* Define if you have the <sys/types.h> header file.  */
#define HAVE_SYS_TYPES_H 1

/* Define if you have the <time.h> header file.  */
#define HAVE_TIME_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Name of package */
#define PACKAGE "libxslt"

/* Version number of package */
#define VERSION "1.0.19"

