README for DocBook XML V4.1.2

This is DocBook XML V4.1.2, released 27 Aug 2000.

See 41chg.txt for information about what has changed since DocBook 4.0.

For more information about DocBook, please see

  http://www.oasis-open.org/docbook/

a partial mirror of the official DocBook site is available at

  http://docbook.org/

Please send all questions, comments, concerns, and bug reports to the
DocBook mailing list: docbook@lists.oasis-open.org
