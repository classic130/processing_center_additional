VERSION 1.3.3

Change Log:
-----------
https://bugs.internet2.edu/jira/browse/CPPXT

Documentation:
--------------
The OpenSAML wiki is the home for any documentation on the XMLTooling package.
https://spaces.internet2.edu/display/OpenSAML/

Reporting Bugs:
---------------
A Jira instance is available.
https://bugs.internet2.edu/

Support:
--------
A mailing list is available.
https://spaces.internet2.edu/display/OpenSAML/MailingList
