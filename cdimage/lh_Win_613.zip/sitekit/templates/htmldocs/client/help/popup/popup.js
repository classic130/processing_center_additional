function popUp(file)
	{
    window.open(file,'new','width=350,height=170');
	}