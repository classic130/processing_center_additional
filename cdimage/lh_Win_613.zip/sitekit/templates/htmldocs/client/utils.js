function writeHTMLcertDN(certDN) {
  var components = certDN.split("&nbsp;&nbsp;|&nbsp;&nbsp;");
  document.write(components[0]);
  var i= 1;
  while(i < components.length) {
    document.write('<br />' + components[i]);
    i++;
  }
}