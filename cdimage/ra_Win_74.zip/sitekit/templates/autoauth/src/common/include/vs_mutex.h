
/*--------------------------------------------------------------------\
| Copyright (C) Symantec Corporation created 2014. All rights reserved.|
| This is an unpublished work protected as such under copyright law.   |
| This work contains proprietary, confidential, and trade secret       |
| information of Symantec Corporation. Use, disclosure or reproduction |
| without the expressed written authorization of Symantec Corporation  |
| is prohibited.                                                       |
\---------------------------------------------------------------------*/

#ifndef VS_MUTEX_INCLUDED
#define VS_MUTEX_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


//==============================================================================
// includes
//==============================================================================

#include "vs_platform_defs.h"

//==============================================================================
// typedefs
//==============================================================================

#if defined(WIN32)

   #include <windows.h>
   typedef HANDLE VS_MutexHandle;

#elif defined(SOLARIS) || defined(AIX) || defined(LINUX)

   #include <pthread.h>
   typedef pthread_mutex_t VS_MutexHandle;

#elif defined(HPUX)

#ifdef PTHREAD_FIXED_ON_HP

   #include <pthread.h>
   typedef pthread_mutex_t VS_MutexHandle;

#else

	typedef void* VS_MutexHandle;

#endif

#else

   #error "includes and typedefs undefined on this platform"

#endif


//==============================================================================
// function prototypes
//==============================================================================

VS_PLATFORM_DLL_ENTRY int vs_mutex_create(VS_MutexHandle* mutexHandlePtr);
VS_PLATFORM_DLL_ENTRY int vs_mutex_lock(VS_MutexHandle mutexHandle);
VS_PLATFORM_DLL_ENTRY int vs_mutex_unlock(VS_MutexHandle mutexHandle);
VS_PLATFORM_DLL_ENTRY int vs_mutex_destroy(VS_MutexHandle mutexHandle);


#ifdef __cplusplus
}
#endif

#endif // VS_MUTEX_INCLUDED
