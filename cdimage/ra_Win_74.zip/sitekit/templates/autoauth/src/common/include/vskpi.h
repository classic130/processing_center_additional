/*
 * $Revision: 1.5.64.2 $
 * $Header: /cvsroot/mpki/vsaakm/vsaasrv/include/vskpi.h,v 1.5.64.2 2014/06/12 12:40:36 cnalkara Exp $
 */

/*--------------------------------------------------------------------\
| Copyright (C) Symantec Corporation created 2014. All rights reserved.|
| This is an unpublished work protected as such under copyright law.   |
| This work contains proprietary, confidential, and trade secret       |
| information of Symantec Corporation. Use, disclosure or reproduction |
| without the expressed written authorization of Symantec Corporation  |
| is prohibited.                                                       |
\---------------------------------------------------------------------*/


#ifndef _VSKPI_H_
#define _VSKPI_H_

#include "VSSubscriberInfo.h"



/* KPI-specific operations: */
#define VSKPI_CONFIGCHANGED       "ConfigChanged"
#define VSKPI_RECOVERKEY          "RecoverKey"
/* Start Add: TELIA Implementation */
#define VSKPI_RECOVERMULTKEY      "RecoverMultipleKey"
/* End Add: TELIA Implementation */
#define VSKPI_RECOVERKEY_BE       "recover key from krb"
#define VSKPI_RECOVERPREFLIGHT    "RecoverPreflight"
#define VSKPI_PICKUP              "PickupPKCS12"
#define VSKPI_SHUTDOWN            "Shutdown"
#define VSKPI_GETPWDFROMREFNUM    "GetPwdFromRefnum"
#define VSKPI_GETLOG              "GetLog"
#define VSKPI_GETSTATUS           "GetStatus"
#define VSKPI_INSERTNEWROW        "insertNewRow"
#define VSKPI_UPDATETOISSUED      "updateToIssued"
#define VSKPI_UPDATETOPENDING     "updateToPending"
#define VSKPI_RECOVERKEYANDCERT   "RecoverKeyAndCert"
#define VSKPI_RETRIEVEPASSWORD    "RetrievePassword"
#define VSKPI_UPDATECERTFORPICKUP "updateCertForPickup"
#define VSKPI_FINDENTRYBYWEBPIN   "findEntryByWebPin"
#define VSKPI_TESTCONNECTION      "testConnection"
#define VSKPI_DELETEFAILEDENTRY   "deleteFailedEntry"
#define VSKPI_CHANGE_PICKUP_PASSWORD "changePickUpPassword"

/* KPI-specific miscellaneous defines: */
#define VSAA_ENROLL_TRACK	        "enroll_track"
#define VSAA_FINGER_PRINT				  "fingerprint"
#define VSKPI_COMMONNAME          "common_name"
#define VSKPI_LASTNAME            "mail_lastName"
#define VSKPI_P12PATHNAME         "pkcs12_path"
#define VSKPI_P12FILENAME         "pkcs12_file"
#define VSKPI_P12PASSWORD         "pkcs12_password"
#define VSKPI_EVENTTIME           "event_time"
#define VSKPI_ORIGINATOR          "originator"
#define VSKPI_WEBPIN              "vs_field1"
#define VSKPI_SECRETCODE          "secretCode"
#define VSKPI_REFNUM              "kr_refnum"
#define VSKPI_KRB                 "krb"
#define VSKPI_PUBKEY			        "public_key"
#define VSKPI_CERT_OR_CRL			    "certOrCRL"
#define VSKPI_DUALKEY_ORIGINATOR  "VeriSign OnSite DualKey"
#define VSKPI_ONEKEY_ORIGINATOR   "VeriSign OnSite OneKey"
#define VSKPI_ENCRYPT_ORIGINATOR  "VeriSign OnSite Encryption"
#define VSKPI_SIGNING_ORIGINATOR  "VeriSign OnSite Signing"
#define VSKPI_CERT_IS_PENDING     0x3062
#define VSKPI_SESSIONKEY          "recovered_key"
#define VSKPI_KR_SESSIONKEY       "vs_kr_session_key"
#define VSKPI_VERSION_NAME        "version"
#define VSKPI_VERSION_VALUE       "0100"
#define VSKPI_PKCS7_UNMUNGED      "pkcs7_line"
#define VSKPI_PKCS8_UNMUNGED      "pkcs8_line"
#define VSKPI_PKCS7_BLOB          "pkcs7_blob"
#define VSKPI_PKCS8_BLOB          "pkcs8_blob"
#define VSKPI_ENT_PASSWORD        "enterprise_password"
#define VSKPI_START_TIME          "start_time"
#define VSKPI_NUM_KEYGEN          "num_keygen"
#define VSKPI_NUM_KEYRECOVERED    "num_keyrecovered"
#define VSKPI_KEY_FORMAT          "key_format"
#define VSKPI_CERT							  "cert"
#define VSKPI_TRANSACTION_ID		  "transaction_id"
#define VSKPI_CERT_STATUS		      "cert_status"
#define VSKPI_MASK                "mask"
#define VSKPI_IV                  "iv"
#define VSKPI_EPRIKEY             "encrypted_prikey"
#define VSKPI_PRIKEY			        "private_key"
#define VSKPI_PRIKEY_LEN          "private_key_len"
#define VSKPI_CERT_OR_CRL_LEN	    "certOrCRL_len"
#define VSKPI_ORIGINAL_OP    	    "original_operation"
#define VSKPI_CERT_SERIAL         "certSerial"
#define VSKPI_ISSUER_NAME         "issuerName"
#define VSKPI_PUBKEY_FORMAT       "public_key_format"
#define VSKPI_FOUND_ENTRY         "found_entry_by_webpin"
#define VSKPI_PKCSINFO            "pkcsInformation"
#define VSKPI_B64P12              "b64p12"
#define VSKPI_KEYSIZE             "keySize"

/* With Structured Arts removed, we need the PKCS7 chain from Symantec for a Key Recovery operation  *
 * It is the issuer chain, a PKCS7 chain with no root or EE cert.                                    *
 * Depending on the account CA design, if the Root CA is the Issuing CA                              *
 * then this is a PKCS7 encoding of the Root CA                                                      */
#define VSKPI_ISSUER_CHAIN        "pkcs7_issuer_chain"

/* Start Add: Feature request to support Dual Control for Key recovery */
#define VSKPI_ADMIN_EMAIL             "vs_email"
#define VSKPI_DUAL_CONTROL            "vs_kr_dual_control"
/* End Add: Feature request to support Dual Control for Key recovery */

/* Start Add: TELIA Implementation */
#define VSKPI_TEMP_PASSWORD             "tempPassword"
/* End Add: TELIA Implementation */
/* Predefined values for State column */
#define kDB_STATE_SUBMITTED      (const char *) "submitted"
#define kDB_STATE_UNUSED         (const char *) "unused"
#define kDB_STATE_PENDING        (const char *) "pending"
#define kDB_STATE_ISSUED         (const char *) "issued"
#define kDB_STATE_RENEWED        (const char *) "renewed"

#define	VSAASRV_PATH	           "VSAASRV_PATH"

/* Predefined values for key_format, and an enum used internally */
#define kKF_PKCS8                (const char *) "pkcs8"
#define kKF_PKCS12               (const char *) "pkcs12"

typedef enum {
  eKF_DEFAULT = 0,   /* meaning do whatever we think we should */
  eKF_PKCS8,         /* deliver only in PKCS8 + PKCS7 format   */
  eKF_PKCS12         /* deliver only in PKCS12 format          */
} VSKeyFormat;

#define kPKCS12_PASSWORD_MAX_LENGTH      50
#define kPKCS12_PASSWORD_DEFAULT_LENGTH  16
#define kDB_FINGER_PRINT_MAX_LENGTH      50
#define kDB_COMMONNAME_MAX_LENGTH        64
#define kDB_SQL_COMMAND_MAX_LENGTH       256
#define kDB_CERTIFICATE_MAX_LENGTH       5000
#define kDB_IV_MAX_LENGTH                50
#define kDB_MASK_MAX_LENGTH              50
#define kDB_STATUS_MAX_LENGTH            50
#define kDB_EPRIVKEY_MAX_LENGTH          2000

#define VSAA_KEY_RECOVER_EXCLUSIVE       3


typedef enum {
  eOP_ENCRYPT = 0,
  eOP_SIGNING,
  eOP_RECOVERY,
  eOP_PASSTHRU
} VSSubOperation;


typedef struct VSBlock {
  unsigned int length;
  void         *data;
} VSBlock;




/* Convenience type-caster:
 */
#define WRAP_STATUS(x) (VSAA_STATUS)(x)


#endif
