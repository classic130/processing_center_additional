/*
 * $Revision: 1.2.206.1 $
 * $Header: /cvsroot/mpki/vsaakm/vsaasrv/include/VSSubscriberInfo.h,v 1.2.206.1 2014/06/03 06:46:10 cnalkara Exp $
 */

/*--------------------------------------------------------------------\
| Copyright (C) Symantec Corporation created 2014. All rights reserved.|
| This is an unpublished work protected as such under copyright law.   |
| This work contains proprietary, confidential, and trade secret       |
| information of Symantec Corporation. Use, disclosure or reproduction |
| without the expressed written authorization of Symantec Corporation  |
| is prohibited.                                                       |
\---------------------------------------------------------------------*/


//////////////////////////////////////////////////////////////////////
//
// VSSubscriberInfo.h: interface for the VSSubscriberInfo class.
//
//////////////////////////////////////////////////////////////////////
#ifndef _VSSUBSCRIBERINFO_H_
#define _VSSUBSCRIBERINFO_H_


#if !defined(AFX_VSSUBSCRIBERINFO_H__825A9841_5237_11D2_A1FE_00A024DEBBAA__INCLUDED_)
#define AFX_VSSUBSCRIBERINFO_H__825A9841_5237_11D2_A1FE_00A024DEBBAA__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "vsverify.h"
#include "vsobject.h"


class VSSubscriberInfo : public VSObject  
{
public:
	VSSubscriberInfo();
	virtual ~VSSubscriberInfo();

  virtual const char *GetWebPin (void) const;
  virtual const char *GetCertState (void) const;
  virtual const char *GetMask (void) const;
  virtual const char *GetIV (void) const;
  virtual const char *GetEncryptedPrivateKey (void) const;
  virtual const char *GetCommonName (void) const;
  virtual const char *GetPKCS12Password (void) const;
  virtual const char *GetPKCS12Filename (void) const;
  virtual const char *GetEventTime (void) const;
  virtual const char *GetHost (void) const;
  virtual const char *GetCert (void) const;
  virtual const char *GetTransactionId (void) const;
  virtual const char *GetKRSessionKey (void) const;
  virtual const char *GetB64P12 (void) const;

  VSAA_STATUS SetWebPin (const char *webpin);
  VSAA_STATUS SetCertState (const char *certState);
  VSAA_STATUS SetMask (const char *mask);
  VSAA_STATUS SetIV (const char *iv);
  VSAA_STATUS SetEncryptedPrivateKey (const char *encPrvKey);
  VSAA_STATUS SetCommonName (const char *commonname);
  VSAA_STATUS SetPKCS12Password (const char *pkcs12password);
  VSAA_STATUS SetPKCS12Filename (const char *pkcs12filename);
  VSAA_STATUS SetEventTime (const char *eventTime);
  VSAA_STATUS SetHost (const char *host);
  VSAA_STATUS SetCert (const char *cert);
  VSAA_STATUS SetTransactionId (const char *xID);
  VSAA_STATUS SetKRSessionKey (const char *krSessionKey);
  VSAA_STATUS SetB64P12 (const char *b64p12);

protected:
  char   *m_webpin;                        // vs_field1
  char   *m_cert_state;
  char   *m_mask;
  char   *m_iv;
  char   *m_kr_session_key;
  char   *m_encryptedPrivateKey;
  char   *m_b64p12;
  char   *m_pkcs12password;
  char   *m_pkcs12filename;
  char   *m_commonname;
  char   *m_eventTime;
	char	 *m_host;
	char	 *m_cert;
	char	 *m_xId;

};

#endif // !defined(AFX_VSSUBSCRIBERINFO_H__825A9841_5237_11D2_A1FE_00A024DEBBAA__INCLUDED_)

#endif //_VSSUBSCRIBERINFO_H_
