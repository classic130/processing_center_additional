/*
 * $Revision: 1.5.66.1 $
 * $Header: /cvsroot/mpki/vsaakm/vsaautil/include/vsverifyexchange.h,v 1.5.66.1 2014/06/03 06:46:10 cnalkara Exp $
 */

/*--------------------------------------------------------------------\
| Copyright (C) Symantec Corporation created 2014. All rights reserved.|
| This is an unpublished work protected as such under copyright law.   |
| This work contains proprietary, confidential, and trade secret       |
| information of Symantec Corporation. Use, disclosure or reproduction |
| without the expressed written authorization of Symantec Corporation  |
| is prohibited.                                                       |
\---------------------------------------------------------------------*/

#ifndef _VSVERIFYEXCHANGE_H_
#define _VSVERIFYEXCHANGE_H_

#include "vsverify.h"

#ifdef __cplusplus
extern "C" {
#endif

#define VS_VERIFY_EXCHANGE_NAME	"VerifyExchange"
#define VS_EXCHANGE_DLL	        "vsexchange.dll"

typedef VSAA_STATUS (*VS_VERIFY_EXCHANGE_FUNC)(
			const VSAA_NAME userInput[], 
			FILE *fp);

VSAA_STATUS VerifyExchange(
			const VSAA_NAME userInput[], 
			FILE *fp);

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif

