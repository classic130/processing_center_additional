
/*--------------------------------------------------------------------\
| Copyright (C) Symantec Corporation created 2014. All rights reserved.|
| This is an unpublished work protected as such under copyright law.   |
| This work contains proprietary, confidential, and trade secret       |
| information of Symantec Corporation. Use, disclosure or reproduction |
| without the expressed written authorization of Symantec Corporation  |
| is prohibited.                                                       |
\---------------------------------------------------------------------*/


#ifndef _VSSQLCLEAN_H_
#define _VSSQLCLEAN_H_

int vsSQLClean(const char *inStr, char *outStr, int *outLen);
void vsSQLEscSingleQuote(const char *in, char *out, int *outLen);

#endif // _VSSQLCLEAN_H_
