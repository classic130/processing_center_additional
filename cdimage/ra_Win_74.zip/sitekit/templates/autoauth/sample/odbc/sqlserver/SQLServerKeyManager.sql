
/****** Object:  Table dbo.KeyRecovery    Script Date: 2/22/00 12:49:43 PM ******/
CREATE TABLE dbo.KeyRecovery (
	WebPin         	       varchar (50)  NOT NULL ,
	SubScriberName         varchar (255) NULL ,
	Status                 varchar (20)  NOT NULL ,
	EventTime              varchar (100) NOT NULL ,
	Mask                   varchar (80)  NOT NULL ,
	IV                     varchar (60)  NOT NULL ,
	P12Pwd                 varchar (100) NULL ,
	EPKey                  text          NOT NULL ,
	Cert                   text          NULL ,
)
GO

