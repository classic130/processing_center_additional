
/*--------------------------------------------------------------------\
| Copyright (C) Symantec Corporation created 2014. All rights reserved.|
| This is an unpublished work protected as such under copyright law.   |
| This work contains proprietary, confidential, and trade secret       |
| information of Symantec Corporation. Use, disclosure or reproduction |
| without the expressed written authorization of Symantec Corporation  |
| is prohibited.                                                       |
\---------------------------------------------------------------------*/

#include <string.h>
#include <ctype.h>
#include "vssqlclean.h"

#include <stdio.h>

#ifndef ODBC_MAX_SQL_LENGTH // this should already be defined in vsaaodbc.cpp
#define ODBC_MAX_SQL_LENGTH 8096
#endif

/*  Possible values for CharacterMap.status */
typedef enum {
  KEEP_CHAR = 0,
  INSERT_CHAR
} CharStatus;

typedef struct
{
	char *charPtr;
	CharStatus status;
} _VSSQLCLEAN_CharacterMap;

static int _VSSQLCLEAN_applyHeuristics(_VSSQLCLEAN_CharacterMap sQLClause[])
{
    int rc = 1; // 1 indicates the clause is accepted and cleaned, 0 the clause is rejected and cannot be cleaned
    int i = 0;
    int j = 0;
    int beginRange = 0;
    int endRange = 0;
    int masterCursor = 0;
    int clauseEnd = 0;
    
    int inLen = 0;
    
    int fNested = 0;
    int fProcessingValue = 0;
    
#define DQ_CHAR '"'
#define PS_CHAR "%s"
#define E_CHAR "="
#define Q_CHAR "'"
#define QQ_CHAR "''"
#define QPS_CHAR "'%s"    
   
    inLen = strlen(sQLClause->charPtr);
    
    do {
        if (*sQLClause[0].charPtr != DQ_CHAR)
        { //SQL clause must start with "
            rc = 1;
            break;
        }
        for (i=1; i<inLen; i++)
        {
            if (*sQLClause[i].charPtr == DQ_CHAR)
            { //the next " marks the end of the SQL clause
                clauseEnd = i;
                break;
            }
        }
        for (masterCursor=1; masterCursor<clauseEnd; masterCursor++)
        { //search from left to right
            if (rc == 0)
            {
                break;
            }

            if (!memcmp(sQLClause->charPtr+masterCursor, PS_CHAR, 2))
            { //found %s
                endRange = masterCursor;
                for (i=endRange; i>= beginRange; i--) 
                { //look back for the = sign
                    if (!memcmp(sQLClause->charPtr+i, E_CHAR, 1))
                    { //found = sign
                        fProcessingValue = 1;
                        beginRange = i; //mark the position for the = sign
                        break;
                        
                    } //end found = 
                } //end look back for = sign
                if ((i <= beginRange) && !fProcessingValue)
                { //no = sign found preceding the %s
                    rc = 0;
                    break;
                }
                if (fProcessingValue) {
                    for (j=beginRange; j<=endRange; j++)
                    { //looking for a ' between = and %s
                        if (!memcmp(sQLClause->charPtr+j, Q_CHAR, 1))
                        { //found a '
                            fNested = 1;
                            //masterCursor += 2;
                            break;
                        } 
                        
                    } //end looking for a ' between = and %s
                }
                
                if (!fNested && fProcessingValue)
                { //did not find a '
                    for (i=endRange; i>=beginRange; i--)
                    { //look back from %s for first whitespace
                        if (isspace(*(sQLClause->charPtr+i)))
                        { //found the position for the whitespace
                            // mark the following character for insert
                            sQLClause[i+1].status = INSERT_CHAR;
                            break;

                        } //end found the position for the whitespace
                        
                    } //end look back from %s for first whitespace
                    if (i < beginRange)
                    { // there is no whitespace between the = sign and the value, but still need to insert a quote
                        sQLClause[masterCursor].status = INSERT_CHAR;
                    }
                    
                } //end did not find a '
                
                
                
                if (!fNested && fProcessingValue)
                { //non-quoted (intended to be numeric type) found after = sign
                    for (i=endRange; i<=clauseEnd; i++)
                    { 
                        if ((!memcmp(sQLClause->charPtr+i, Q_CHAR, 1)) && (memcmp(sQLClause->charPtr+i, QQ_CHAR, 2)))
                        { //found a closing ' without an opening '
                            rc =0;
                            break;
                        } 
                        //search for the first whitespace after %s and mark for insertion
                        if (isspace(*(sQLClause->charPtr+i)))
                        { //found a whitespace, mark it for insertion
                            sQLClause[i].status = INSERT_CHAR;
                            masterCursor = i;
                            break;
                        }
                        else if (i == clauseEnd)
                        { 
                            sQLClause[i].status = INSERT_CHAR;
                            masterCursor = i;
                            break;
                        }
                    } 
                } //end non-quoted (intended to be numeric type) found after = sign
                
                else if (fProcessingValue)
                { // this is nested, need to move masterCursor to next character after closing quote
                    beginRange = masterCursor;
                    for (i=beginRange; i<=clauseEnd; i++)
                    {
                        if (!memcmp(sQLClause->charPtr+i, QQ_CHAR, 2)) // escaped quotes are ok inside nest
                        {
                            i++;
                            continue;
                        }
                        if (!memcmp(sQLClause->charPtr+i, QPS_CHAR, 2)) // '%s not allowed inside value
                        {
                            rc = 0;
                            break;
                        }
                        if (!memcmp(sQLClause->charPtr+i, Q_CHAR, 1))
                        { //found the closing quote
                            fNested = 0;
                            fProcessingValue = 0;
                            beginRange = masterCursor = i;
                            break;
                        }
                        if (i == clauseEnd) { //nested value to end of clause without closing '
                            //sQLClause[i].status = INSERT_CHAR;
                            //masterCursor = i;
                            rc = 0;
                            break;
                        }
                    }
                }
                
            } //end found %s
            
        } //end search from left to right
        
    } while(0);

    return rc;
}

static void _VSSQLCLEAN_string2CharMap(const char *inStr, _VSSQLCLEAN_CharacterMap outCharMap[])
{
    unsigned int i = 0;
    for (i=0; i<=strlen(inStr); i++) {
        outCharMap[i].charPtr = (char*)&inStr[i];
        outCharMap[i].status = KEEP_CHAR;
	}
	outCharMap[i+1].charPtr = '\0';
	outCharMap[i+1].status = KEEP_CHAR;
}

static void _VSSQLCLEAN_stackOutputString(char* outStr, _VSSQLCLEAN_CharacterMap sQLClause[])
{
	int i =0, j = 0;
	for (i=0; sQLClause[i].charPtr; i++) 
	{
/*		if ( sQLClause[i].status == DELETE_CHAR) 
		{
			continue;
		}
*/
		if (sQLClause[i].status == KEEP_CHAR) {
			outStr[j] = *sQLClause[i].charPtr;
			j++;
			continue;
		}

		if (sQLClause[i].status == INSERT_CHAR)
		{
			outStr[j] = '\'';
			j++;
			outStr[j] = *sQLClause[i].charPtr;
			j++;
			continue;
		}
	}
	if (sQLClause[i+1].status == INSERT_CHAR) {
		outStr[j] = '\'';
		j++;
	}
	outStr[j] = '\0';
}

int vsSQLClean(const char *inStr, char *outStr, int *outLen)
{
    int rc = 1;
#define MAX_SQL_CLAUSE_LENGTH ODBC_MAX_SQL_LENGTH*2
    _VSSQLCLEAN_CharacterMap sQLClause[MAX_SQL_CLAUSE_LENGTH];
    char localOutStr[MAX_SQL_CLAUSE_LENGTH] = "";
    
    do
    {
        
        _VSSQLCLEAN_string2CharMap(inStr, sQLClause);
        if ((rc = _VSSQLCLEAN_applyHeuristics(sQLClause)) == 0)
        {
            break;
        }
        _VSSQLCLEAN_stackOutputString(localOutStr, sQLClause);
        
        
        unsigned int localOutLen = strlen(localOutStr)+1;
        
        if (outStr == NULL) {
            *outLen = localOutLen;
        }else {
            memcpy(outStr, localOutStr, (*outLen)-1);
            memset(outStr+(*outLen)-1, 0, 1);
        }
    } while (0);
        return rc;
}

void vsSQLEscSingleQuote(const char *in, char *out, int *outLen)
{
    int i;
    const char *inPtr = in;

    if (!in) return;

    if (out == NULL) {
        for (i=0; *in; in++, i++)
        {
            if (*in == '\'') i++;
        }
        *outLen = i+1;
        return;
    }
    for (i=0; *in; in++)
    {
        out[i++] = *in;
        if (i >= *outLen)
          break;
        if (*in == '\'') // if a single quote is encountered, add another one
        {
            out[i++] = *in;
            if (i >= *outLen)
                break;
        }
    }
    out[i] = '\0';
}
