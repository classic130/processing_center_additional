
/*--------------------------------------------------------------------\
| Copyright (C) Symantec Corporation created 2014. All rights reserved.|
| This is an unpublished work protected as such under copyright law.   |
| This work contains proprietary, confidential, and trade secret       |
| information of Symantec Corporation. Use, disclosure or reproduction |
| without the expressed written authorization of Symantec Corporation  |
| is prohibited.                                                       |
\---------------------------------------------------------------------*/


/* This program sending the request to the ipayment Gateway and gets teh response
Author : Rajesh Kumar */

#ifndef _IPAYMENT_GATEWAY_H
#define _IPAYMENT_GATEWAY_H

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include "vsverify.h"
#ifndef WIN32
  #include <unistd.h>
  #include <sys/types.h>
  #include <sys/socket.h>
  #include <netinet/in.h>
  #include <netinet/tcp.h>
  #include <netdb.h>
#else
  #include <windows.h>
#endif

#define CN_LENGTH 256
#define BUFSIZE 1024

VSAA_STATUS iPaymentRequest(char* host, int port, char* requestData, char** responseData,char*,char*);
VSAA_STATUS initialize_ctx(const char* trustedCAsFileName);
void destroy_ctx();


#endif //_IPAYMENT_GATEWAY_H
