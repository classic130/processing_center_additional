/*
 * $Revision: 1.1.2.1.16.1 $
 * $Header: /cvsroot/mpki/vsaakm/common/include/Attic/localvsverify.h,v 1.1.2.1.16.1 2014/06/03 06:45:58 cnalkara Exp $
 */

/*--------------------------------------------------------------------\
| Copyright (C) Symantec Corporation created 2014. All rights reserved.|
| This is an unpublished work protected as such under copyright law.   |
| This work contains proprietary, confidential, and trade secret       |
| information of Symantec Corporation. Use, disclosure or reproduction |
| without the expressed written authorization of Symantec Corporation  |
| is prohibited.                                                       |
\---------------------------------------------------------------------*/



#ifndef _LOCALVSVERIFY_H_
#define _LOCALVSVERIFY_H_

#ifndef PACKAGED_SRC
#include "../../vsaasrv/include/vsverify.h"
#else
#include "vsverify.h"
#endif

#endif/*_LOCALVSVERIFY_H_*/
