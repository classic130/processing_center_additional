spool alter_key_recovery.log
--
alter table KeyRecovery
modify (
EPKey   VARCHAR2(2000) ) 
/
--

