/* $Id */

/*--------------------------------------------------------------------\
| Copyright (C) VeriSign, Inc. created 1998. All rights reserved.     |
| This is an unpublished work protected as such under copyright law.  |  
| This work contains proprietary, confidential, and trade secret      |
| information of VeriSign, Inc.  Use, disclosure or reproduction      |
| without the expressed written authorization of VeriSign, Inc.       |
| is prohibited.                                                      |
\--------------------------------------------------------------------*/

#ifndef _VSAALDAP_H_
#define _VSAALDAP_H_

/* LDAP SDK header files */

#include "ldap.h"         
#include "ldap_ssl.h"

#include "vsaautil.h"

#ifdef __cplusplus
extern "C" {
#endif

/* LDAP definitions */

#define LDAP_LOG           ("LDAP_ERROR_LOG")
#define LDAP_LOG_LEVEL     ("LDAP_LOG_LEVEL")
#define LDAP_LOG_FILE_NAME "vsaaldap.log"

#define CFG_BINDDN_BEGIN_CHAR     '"'
#define CFG_BINDDN_END_CHAR       '"'
#define CFG_BINDDN_ATTR_DELIMITER '+'

#define CFG_UPD_CERT_BIN_ATTR         "userCertificate;binary"
#define CFG_UPD_SMIME_CERT_BIN_ATTR   "userSMimeCertificate;binary"
#define CFG_UPD_CERT_SERIAL_ATTR      "x500uniqueidentifier"

#define DEFAULT_DN_EMAIL_SEARCH_TOKEN  "Email Address ="
#define DEFAULT_DN_EMAIL_VER_ATTR      "mail"

#define DEFAULT_PICKUP_DN_SEARCH_TOKEN  "Email Address ="
#define DEFAULT_PICKUP_DN_VER_ATTR      "mail"

#define DEFAULT_RENEWAL_DN_SEARCH_TOKEN "Email Address ="
#define DEFAULT_RENEWAL_DN_VER_ATTR     "mail"

#define VER_PREFIX    ("VER_LDAP_")
#define REG_PREFIX    ("REG_LDAP_")

#define VER_HOST      ("VER_LDAP_HOST_NAME")
#define VER_PORT      ("VER_LDAP_PORT")
#define VER_SSL_PORT  ("VER_LDAP_SSL_PORT")
#define VER_DN        ("VER_LDAP_BIND_DN")
#define VER_PWD       ("VER_LDAP_BIND_PWD")
#define VER_READ_DN   ("VER_LDAP_READ_DN")
#define VER_READ_PWD  ("VER_LDAP_READ_PWD")
#define VER_BASEDN    ("VER_LDAP_BASE_DN")
#define VER_OBJCLASS  ("VER_LDAP_OBJCLASS")
#define VER_EMAIL     ("VER_LDAP_EMAIL_ATTR")
#define VER_SSL       ("VER_LDAP_SSL")
#define VER_CERTDB    ("VER_LDAP_CERT")
#define VER_PROTOCOL_VERSION ("VER_LDAP_PROTOCOL_VERSION")

#define REG_HOST      ("REG_LDAP_HOST_NAME")
#define REG_PORT      ("REG_LDAP_PORT")
#define REG_SSL_PORT  ("REG_LDAP_SSL_PORT")
#define REG_DN        ("REG_LDAP_BIND_DN")
#define REG_PWD       ("REG_LDAP_BIND_PWD")
#define REG_READ_DN   ("REG_LDAP_READ_DN")
#define REG_READ_PWD  ("REG_LDAP_READ_PWD")
#define REG_BASEDN    ("REG_LDAP_BASE_DN")
#define REG_OBJCLASS  ("REG_LDAP_OBJCLASS")
#define REG_EMAIL     ("REG_LDAP_EMAIL_ATTR")
#define REG_SSL       ("REG_LDAP_SSL")
#define REG_CERTDB    ("REG_LDAP_CERT")
#define REG_PROTOCOL_VERSION ("REG_LDAP_PROTOCOL_VERSION")


#define RECOVER_PREFIX    ("RECOVER_LDAP_")

#define RECOVER_HOST            ("RECOVER_LDAP_HOST_NAME")
#define RECOVER_PORT            ("RECOVER_LDAP_PORT")
#define RECOVER_SSL_PORT        ("RECOVER_LDAP_SSL_PORT")
#define RECOVER_DN              ("RECOVER_LDAP_BIND_DN")
#define RECOVER_PWD             ("RECOVER_LDAP_BIND_PWD")
#define RECOVER_READ_DN         ("RECOVER_LDAP_READ_DN")
#define RECOVER_READ_PWD        ("RECOVER_LDAP_READ_PWD")
#define RECOVER_BASEDN          ("RECOVER_LDAP_BASE_DN")
#define RECOVER_OBJCLASS        ("RECOVER_LDAP_OBJCLASS")
#define RECOVER_EMAIL           ("RECOVER_LDAP_SEARCH_ATTR")
#define RECOVER_SSL             ("RECOVER_LDAP_SSL")
#define RECOVER_CERTDB          ("RECOVER_LDAP_CERT")
#define RECOVER_DN              ("RECOVER_LDAP_BIND_DN")
#define RECOVER_PWD             ("RECOVER_LDAP_BIND_PWD")
#define RECOVER_LDAP_ATTR_MAP   ("RECOVER_LDAP_ATTR_MAP")
#define RECOVER_PROTOCOL_VERSION ("RECOVER_LDAP_PROTOCOL_VERSION")

#define VER_HOST_EXTERNAL     ("VER_LDAP_HOST_NAME_EXTERNAL")
#define VER_PORT_EXTERNAL     ("VER_LDAP_PORT_EXTERNAL")
#define VER_SSL_PORT_EXTERNAL ("VER_LDAP_SSL_PORT_EXTERNAL")
#define VER_DN_EXTERNAL       ("VER_LDAP_BIND_DN_EXTERNAL")
#define VER_PWD_EXTERNAL      ("VER_LDAP_BIND_PWD_EXTERNAL")
#define VER_READ_DN_EXTERNAL  ("VER_LDAP_READ_DN_EXTERNAL")
#define VER_READ_PWD_EXTERNAL ("VER_LDAP_READ_PWD_EXTERNAL")
#define VER_BASEDN_EXTERNAL   ("VER_LDAP_BASE_DN_EXTERNAL")
#define VER_OBJCLASS_EXTERNAL ("VER_LDAP_OBJCLASS_EXTERNAL")
#define VER_EMAIL_EXTERNAL    ("VER_LDAP_EMAIL_ATTR_EXTERNAL")
#define VER_SSL_EXTERNAL      ("VER_LDAP_SSL_EXTERNAL")
#define VER_CERTDB_EXTERNAL   ("VER_LDAP_CERT_EXTERNAL")
#define REG_HOST_EXTERNAL     ("REG_LDAP_HOST_NAME_EXTERNAL")
#define REG_PORT_EXTERNAL     ("REG_LDAP_PORT_EXTERNAL")
#define REG_SSL_PORT_EXTERNAL ("REG_LDAP_SSL_PORT_EXTERNAL")
#define REG_DN_EXTERNAL       ("REG_LDAP_BIND_DN_EXTERNAL")
#define REG_PWD_EXTERNAL      ("REG_LDAP_BIND_PWD_EXTERNAL")
#define REG_READ_DN_EXTERNAL  ("REG_LDAP_READ_DN_EXTERNAL")
#define REG_READ_PWD_EXTERNAL ("REG_LDAP_READ_PWD_EXTERNAL")
#define REG_BASEDN_EXTERNAL   ("REG_LDAP_BASE_DN_EXTERNAL")
#define REG_OBJCLASS_EXTERNAL ("REG_LDAP_OBJCLASS_EXTERNAL")
#define REG_EMAIL_EXTERNAL    ("REG_LDAP_EMAIL_ATTR_EXTERNAL")
#define REG_SSL_EXTERNAL      ("REG_LDAP_SSL_EXTERNAL")
#define REG_CERTDB_EXTERNAL   ("REG_LDAP_CERT_EXTERNAL")

#define LDAP_ATTR_MAP         ("LDAP_ATTR_MAP")
#define LDAP_ATTR_SET         ("LDAP_ATTR_SET")
#define LDAP_ATTR_GET         ("LDAP_ATTR_GET")
#define LDAP_ATTR_REG         ("LDAP_ATTR_REG")
#define LDAP_ATTR_VER         ("LDAP_ATTR_VER")
#define LDAP_ATTR_UPD         ("LDAP_ATTR_UPD")
#define LDAP_ATTR_AUTH        ("LDAP_ATTR_AUTH")
#define LDAP_ATTR_MANUAL_AUTH ("LDAP_ATTR_MANUAL_VER")

#define LDAP_ATTR_CERT_STATUS          ("LDAP_ATTR_CERT_STATUS")
#define LDAP_VALUE_CERT_STATUS_VALID   ("LDAP_VALUE_CERT_STATUS_VALID")
#define LDAP_VALUE_CERT_STATUS_INVALID ("LDAP_VALUE_CERT_STATUS_INVALID")
#define LDAP_VALUE_CERT_STATUS_REVOKED ("LDAP_VALUE_CERT_STATUS_REVOKED")

/* structure to store LDAP server operation configuration */

typedef struct  {
    unsigned int errId;
    char*        errMsg;
} DIMError;

/* data structure to store information about a LDAP server */

typedef struct {
    char szHostName[MAX_CFG_VALUE_LENGTH];
    int  nPort;
    int  nSSLPort;
    char szBindDN[MAX_CFG_VALUE_LENGTH];
    char szBindPassword[MAX_CFG_VALUE_LENGTH];
    char szReadDN[MAX_CFG_VALUE_LENGTH];
    char szReadPassword[MAX_CFG_VALUE_LENGTH];
    char szBaseDN[MAX_CFG_VALUE_LENGTH];
    char szObjClass[MAX_CFG_VALUE_LENGTH];
    char szEmailAttr[MAX_CFG_VALUE_LENGTH];
    VSAA_BOOL nSSLEnabled;
    char szCertDB[MAX_CFG_VALUE_LENGTH];
    int  nProtocolVersion;
} DIMCfgLDAPHost;

/* data structure to store all configuration about DIM */

typedef struct
{
    /* there are possibly four LDAP servers: two internal and two external */

    DIMCfgLDAPHost verLDAPCfg;
    DIMCfgLDAPHost regLDAPCfg;
    DIMCfgLDAPHost verLDAPExternalCfg;
    DIMCfgLDAPHost regLDAPExternalCfg;
    DIMCfgLDAPHost recoverLDAPCfg;
    
    /* attributes for AA rules */

    VSAACfgNVPairList*    mapAttrListPtr;
    VSAACfgNVPairList*    setAttrListPtr;
    VSAACfgAttrList*      verAttrListPtr;
    VSAACfgNVPairList*    authAttrListPtr;
    VSAACfgAttrList*      manualAuthAttrListPtr;
    VSAACfgAttrList*      getAttrListPtr;
    VSAACfgNVTripleList*  regAttrListPtr;
    VSAACfgAttrList*      updAttrListPtr;

    VSAACfgNVPairList*    recoverMapAttrListPtr;

    /* attributes for certificate status */
    
    char certStatusAttrName[MAX_CFG_VALUE_LENGTH];
    char certStatusValid[MAX_CFG_VALUE_LENGTH];
    char certStatusInvalid[MAX_CFG_VALUE_LENGTH];
    char certStatusRevoked[MAX_CFG_VALUE_LENGTH];

    /* log flag */

    VSAA_BOOL             nLogEnabled;
    unsigned int          nLogLevel;

    VSAA_BOOL             nPrePickupProcess;
    VSAA_BOOL             nPreRevokeProcess;
    VSAA_BOOL             nPreRenewalProcess;

} DIMCfg, *DIMCfgPtr;

/* Ldap credentials */
typedef struct {
	char *userDN;
	char *passwd;
} DIMCred, *DIMCredPtr;



/*******************************************************
 * Function prototypes                                 *
 ******************************************************/

/* Log related functions */

char* DIM_GetErrorMsg(VSAA_STATUS status);
void  DIM_PrintCfg();

VSAA_STATUS DIM_LogError(VSAA_STATUS status);

/* Configuration related functions */

void DIM_SetDefaultCfg(DIMCfg* pDIMCfg);
void DIM_FreeCfg(DIMCfg* pDIMCfg);
void DIM_InitLDAPHostCfg(DIMCfgLDAPHost* hostCfgPtr);

VSAA_STATUS DIM_ReadConfigFile(const char* pszServiceCfgFileName);
VSAA_STATUS DIM_ValidateCfg(DIMCfg* pDIMCfg);

/* Some utility functions */
const char* DIM_GetFDFAttrName(const char* pszX500Attr);
const char* DIM_RecoverGetLdapAttrName(const char* pszX500Attr);

/* LDAP related functions */

VSAA_BOOL
DIM_IsExternalLDAPServerRequested(const VSAA_NAME userInput[]);

VSAA_STATUS
DIM_BuildEmailVerSetAttributes(
    VSAACfgAttrList   **verAttrListPtr, 
    VSAACfgNVPairList **setAttrListPtr, 
    const VSAA_NAME   userInput[]);

VSAA_STATUS
DIM_BuildPickupVerSetAttributes(
    VSAACfgAttrList   **verAttrListPtr, 
    VSAACfgNVPairList **setAttrListPtr, 
    const VSAA_NAME   userInput[]);

VSAA_STATUS
DIM_BuildRevokeVerSetAttributes(
    VSAACfgAttrList   **verAttrListPtr, 
    VSAACfgNVPairList **setAttrListPtr, 
    const VSAA_NAME   userInput[],
    int revoke_count);

VSAA_STATUS
DIM_BuildRenewalVerSetAttributes(
    VSAACfgAttrList   **verAttrListPtr, 
    VSAACfgNVPairList **setAttrListPtr, 
    const VSAA_NAME  userInput[]);

VSAA_STATUS DIM_BuildLDAPSearchFilter(
    char                         **ppszFilter,
    const VSAA_NAME              userInput[],
	const VSAACfgAttrList        *searchAttrListPtr,
	const VSAACfgNVPairList      *setAttrListPtr,
	const char                   *pszObjClass);

VSAA_STATUS DIM_RecoverBuildLDAPSearchFilter(
    char                         **ppszFilter,
    const VSAA_NAME              userInput[],
    char                         *searchAttr,
	const char                   *pszObjClass);


VSAA_STATUS 
DIM_PopulateConfigDN(
    char                 **ppszUserDN, 
    const char           szConfigDN[], 
    const VSAA_NAME      userInput[]);

VSAA_STATUS 
DIM_PopulateConfigPassword(
    char                 **ppszUserPWD, 
    const char           szConfigPWD[], 
    const VSAA_NAME      userInput[]);

VSAA_STATUS DIM_BuildBindDNPassword(
    char                 **ppszUserDN, 
    char                 **ppszUserPWD,
    const VSAA_NAME      userInput[], 
    const DIMCfgLDAPHost *pLdapHostCfg, 
    const char           *pszFilter);    

VSAA_STATUS 
DIM_QueryLDAPServer(
    LDAP           **ppLd,
    LDAPMessage    **ppResult,
    LDAPMessage    **ppEntry,
    const char     *pszHost, 
    unsigned int   nPort, 
    VSAA_BOOL       nSSLEnabled,
    const char     *pszCertDB,
    const char     *pszBaseDN,
    const char     *pszUserDN, 
    const char     *pszUserPWD,
    const char     *pszFilter,
    unsigned int   nProtocolVersion);

VSAA_STATUS
DIM_UpdateOneLDAPServerEntry(
    const LDAP                *pLdapID,
    const char                *pszDN,
    const char                *attr,
    const char                *value);    

VSAA_STATUS
DIM_DeleteOneLDAPServerAttr(
    const LDAP                *pLdapID,
    const char                *pszDN,
    const char                *attr);

VSAA_STATUS
DIM_UpdateLDAPServerEntry(
    const LDAP                  *pLdapID,
    const char                  *pszDN,
    const VSAACfgAttrList       *updAttrListPtr,
    const VSAA_NAME             userInput[]);

VSAA_STATUS
DIM_RegLDAPServerEntry(
    const LDAP                      *pLdapID,
    const char                      *pszDN,
    const VSAACfgNVTripleList       *regAttrListPtr,
    const VSAA_NAME                 userInput[]);

VSAA_STATUS
DIM_AugmentUserDataWithLDAPEntry(
    VSAA_NAME**               augmentedData,
    const VSAA_NAME           userInput[], 
    const char*               pszAuthValue,
    LDAP                      *pLdapID,
    LDAPMessage               *pEntry,
    const VSAACfgNVPairList   *setAttrListPtr,
    const VSAACfgAttrList     *getAttrListPtr);

VSAA_BOOL
DIM_VerifyUserDataWithLDAPEntry(    
    LDAP                      *pLdapID,
    LDAPMessage               *pEntry,
    const char                *pszX500Attr,
    const char                *pszUserData);

VSAA_BOOL
DIM_CompareUserInputWithLDAPEntry(
    const VSAA_NAME           userInput[],
    LDAP                      *pLdapID,
    LDAPMessage               *pEntry,
    const VSAACfgAttrList     *authAttrListPtr);

VSAA_BOOL
DIM_IsLDAPEntryAuthorized(
    LDAP                      *pLdapID,
    LDAPMessage               *pEntry,
    const char                *inputEncoding,
    const VSAACfgNVPairList   *authAttrListPtr);

void
DIM_FindCertLDAPAttr();

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif /* _VSAALDAP_H */
