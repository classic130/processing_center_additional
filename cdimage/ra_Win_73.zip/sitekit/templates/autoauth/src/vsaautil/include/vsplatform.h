/*
 * $Revision: 1.1.2.2 $
 * $Header: /cvsroot/mpki/vsaakm/vsaautil/include/Attic/vsplatform.h,v 1.1.2.2 2010/02/23 08:06:12 pchaudhari Exp $
 */

/*--------------------------------------------------------------------\
| Copyright (C) VeriSign, Inc. created 1998. All rights reserved.     |
| This is an unpublished work protected as such under copyright law.  |  
| This work contains proprietary, confidential, and trade secret      |
| information of VeriSign, Inc.  Use, disclosure or reproduction      |
| without the expressed written authorization of VeriSign, Inc.       |
| is prohibited.                                                      |
\--------------------------------------------------------------------*/

#ifndef _VSPLATFORM_H_
#define _VSPLATFORM_H_ 

// platfrom specific initialization/implementation
#ifdef WIN32
#include <windows.h>
#include <process.h>

typedef CRITICAL_SECTION RAWLock;

#define initLock(__l)               InitializeCriticalSection (__l)
#define finitLock(__l)              DeleteCriticalSection (__l)
#define acquireLock(__l)            EnterCriticalSection (__l)
#define releaseLock(__l)            LeaveCriticalSection (__l)

#define vs_getpid()                 GetCurrentProcessId  ()
#define vs_gettid()                 GetCurrentThreadId ()
#define vs_closethreadhadle(__h)    CloseHandle ((HANDLE)(__h))

#define vs_sleep(__ms)              Sleep ((__ms))
//typedef unsigned (__stdcall *PTHREAD_START) (void *)
#define STDCALL __stdcall
#define THREAD_RETURN unsigned

#elif defined(SOLARIS) || defined(HPUX) || defined(AIX) || defined(LINUX)
#include <pthread.h>

typedef pthread_mutex_t RAWLock;
#define initLock(__l)               pthread_mutex_init((__l), NULL)
#define finitLock(__l)              pthread_mutex_destroy((__l))
#define acquireLock(__l)            pthread_mutex_lock((__l))
#define releaseLock(__l)            pthread_mutex_unlock((__l))

#define vs_getpid()                 getpid ()
#define vs_gettid()                 pthread_self ()
#define vs_closethreadhadle(__h)    pthread_exit (0)

#include <time.h>
#include <unistd.h>
#define vs_sleep(__ms)      usleep(__ms)
#define STDCALL 
#define THREAD_RETURN int 

#else
#error "platform not supported"
#endif


#endif //#ifndef _VSPLATFORM_H_
