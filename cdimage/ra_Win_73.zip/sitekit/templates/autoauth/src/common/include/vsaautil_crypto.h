#ifndef _VSAAUTIL_ENCRYPT_H
#define _VSAAUTIL_ENCRYPT_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef VSAA_DECRYPT_LINK
    #ifdef WIN32
        #ifdef BUILD_DECRYPT_DLL
            #define VSAA_DECRYPT_LINK __declspec(dllexport)
        #elif defined(LOAD_DECRYPT_DLL)
            #define VSAA_DECRYPT_LINK __declspec(dllimport)
        #else 
            #define VSAA_DECRYPT_LINK
        #endif
    #else
        #define VSAA_DECRYPT_LINK
    #endif
#endif

int VSAA_DECRYPT_LINK
vsaautil_decrypt(const char *inputString, int inputStringLen, char *outputString, int *outputStringLen);

#ifdef __cplusplus
}
#endif

#endif /* _VSAAUTIL_ENCRYPT_H */

