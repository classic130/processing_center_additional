#ifndef _VSAAAPI_H
#define _VSAAAPI_H

#include "localvsverify.h"
#include "vslog.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef VSAA_LINK
    #ifdef WIN32
        #ifdef BUILD_DLL
            #define VSAA_LINK __declspec(dllexport)
        #elif defined(LOAD_DLL)
            #define VSAA_LINK __declspec(dllimport)
        #else 
            #define VSAA_LINK
        #endif
    #else
        #define VSAA_LINK
    #endif
#endif

/* Initialize the module */
VSAA_STATUS 
VSAA_LINK Initialize(
    const VSAA_NAME commonVSAAConfig[], 
    const char      *pszServiceCfgFileName, 
    VS_STATUS  (*VSAA_Log)(VS_LOG_TYPE level, int line, const char *filename, const char* trans_id, const char *format, ...)
    );

/* Release resources allocated for global data in this module */

VSAA_STATUS 
VSAA_LINK Finalize(void);

/* Register user certificate and other information to registration server */

VSAA_STATUS 
VSAA_LINK RegisterUser(const VSAA_NAME userInput[]);

/* Verify whether the given request should be approval for a certificate issue */

VSAA_STATUS 
VSAA_LINK VerifyUser(
    const VSAA_NAME userInput[], 
    VSAA_NAME       **augmentedData);


VSAA_STATUS 
VSAA_LINK KMOperation(
    const VSAA_NAME userInput[], 
    const char *operation);


/* Log error message */

VSAA_STATUS 
VSAA_LINK ErrorUser(const VSAA_NAME userInput[]);

VSAA_STATUS 
VSAA_LINK validateAuthenticationDataSource();

VSAA_STATUS 
VSAA_LINK validateRegistrationDataSource();

VSAA_STATUS 
VSAA_LINK validateRecoverDataSource();

//// Start: Put keystore KP to DB instead of SA file store
VSAA_STATUS VSAA_LINK validateKeyStoreDataSource();
VSAA_STATUS addKP2Db(const char* pubKeyBlock, const char* privKeyBlock, const char* commonName);
char* getPriByPub(const char* pubKey64Block);
VSAA_STATUS delKPInDb(const char* pubKeyBlock);
//// End:

#ifdef __cplusplus
}
#endif

#endif /* _VSAAAPI_H */

