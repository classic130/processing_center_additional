﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography.X509Certificates;
using System.Collections;
using System.IO;
using System.Web.Services.Protocols;

namespace SampleClient
{
    /**
     * This class demonstrate how to get enrollment policies from VeriSign PKI web service.
     * The service stub policyService and supporting classes are generated using WSDL.exe tool. Please see the readme.txt file for more details.
     */

    class SamplePolicyServiceClient
    {
        /**
         * make the default construct private so we can make the class singleton
         */
        private SamplePolicyServiceClient()
        {
            PoliciesResponse = null;
            validPolicy = false;
        }

        /**
         * This function returns the class that contains the enrollment policy from policy service
         * @return SamplePolicyServiceClient
         */
        public static SamplePolicyServiceClient getInstance()
        {
            if (null == instance)
            {
                instance = new SamplePolicyServiceClient();
            }
            instance.requestEnrollmentPolicy();
            return instance;
        }

        /**
         * Singleton instance of this class 
         */
        private static SamplePolicyServiceClient instance;

        /**
         * This function demonstrate how to get a enrollment policy from EnrollmentPolicyService
         * @return getPoliciesResponse
         */
        private getPoliciesResponse requestEnrollmentPolicy()
        {
            //Step 1: construct GetPolicies object that contains the information for policy request to PKI Web Service
            getPolicies getPolicies = new getPolicies();

            //Step 2: setup API version
            getPolicies.version = policyAPIVersion;

            //Step 3: create PolicyService Stub
            policyService requestPoliciesServiceStub = new policyService();
            requestPoliciesServiceStub.Url = SampleParameters.policyServiceURL;

            //Step 4: prepare for SSL mutual authentication between the sample application PKI Web service
            SoapHttpClientProtocol stub = (SoapHttpClientProtocol)requestPoliciesServiceStub;
            if (false == Utils.SetClientAuth(ref stub, SampleParameters.RACertificateDN))
            {
                return null; //Error
            }

            try
            {
                Console.WriteLine("\tMaking Web Service call for Policy.");
                //Step 5: Send the request to PKI web service to get enrollment policies
                PoliciesResponse = requestPoliciesServiceStub.requestPolicies(getPolicies);
            }
            catch (Exception exc)
            {
                Console.WriteLine("\tWeb Service Call failed. Error Message: '{0}'.", exc.Message);
                return null;
            }

            String policyFile = SampleParameters.sampleOutputPath + SampleParameters.samplePolicyResponse;
            if (File.Exists(policyFile))
            {
                File.Delete(policyFile);
            }
            TextWriter tw = new StreamWriter(policyFile, true);
            tw.WriteLine(Utils.XMLSerializePoliciesResponse(PoliciesResponse));
            tw.Close();
            Console.WriteLine("\tPolicy Response saved in '{0}' file.", policyFile);

            validPolicy = true;
            return PoliciesResponse;
        }

        /**
         * Returns an OID for a given refereceID
         */
        public OID getOIDByReferenceID(int referenceID)
        {
            OID oidReturn = null;
            if (null == PoliciesResponse)
            {
                //Error : Policy Call did not go through
                return oidReturn;
            }
            foreach (OID oid in PoliciesResponse.oIDs)
            {
                if (oid.oIDReferenceID == referenceID)
                {
                    oidReturn = oid;
                    break;
                }
        	}
            return oidReturn;
        }

        public bool IsValidPolicy() 
        {
            return validPolicy;
        }


        /**
         * This is function search a policy based on policy oid default name.
         */
        public CertificateEnrollmentPolicy[] getEnrollmentPoliciesByDefaultName(String defaultName) 
        {
            CertificateEnrollmentPolicy[] enrollmentPolicis = null;

            if (null == PoliciesResponse)
            {
                //Error : Policy Call did not go through
                return enrollmentPolicis;
            }

            foreach (OID oid in PoliciesResponse.oIDs)
            {
                if ((null != oid.defaultName) && 
                    (0 != oid.defaultName.Length) && 
                    (0 == oid.defaultName.CompareTo(defaultName)))
                {
                    foreach (CertificateEnrollmentPolicy policy in PoliciesResponse.response.policies)
                    {
                        if (policy.policyOIDReference == oid.oIDReferenceID)
                        {
                            enrollmentPolicis = new CertificateEnrollmentPolicy[1];
                            enrollmentPolicis[0] = policy; 
                            break;
                        }
                    }
                    if (null != enrollmentPolicis)
                    {
                        break;
                    }
                }
            }
            return enrollmentPolicis;
        }

        protected static String policyAPIVersion = "1.0";
        protected getPoliciesResponse PoliciesResponse;
        protected bool validPolicy;
    }
}
