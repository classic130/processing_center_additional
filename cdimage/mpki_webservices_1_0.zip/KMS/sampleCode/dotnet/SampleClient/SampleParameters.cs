﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

/**
 * This class defines the sample parameters used in the .NET sample application. 
 * You need to register for a VeriSign Managed PKI account and have an RA certificate installed in your user store before 
 * using this sample application.
 * If you will implement key escrow and recovery, you will also need to install the Key Management Server. Refer to Managed 
 * PKI Web Services Key Management Server Installation and Configuration Guide for procedures.
 * To prepare the sample application, you must modify the parameters in this file to suit your environment. 
 */

namespace SampleClient
{
    class SampleParameters
    {
        /**
         * These are the sample name/value pairs (NVPs) required by the enrollment policy for certificate enrollment using this client application. Modify the values in these NVPs as required.
         */
        static SampleParameters()
        {
            sampleInput.Add("common_name", "J. Doe" + DateTime.Now.Ticks);
            sampleInput.Add("mail_stop", "23");
            sampleInput.Add("jobTitle", "Engineer");
            sampleInput.Add("org_unit", "QA");
            sampleInput.Add("corp_company", "Acme Bank");
            sampleInput.Add("locality", "Mountain View");
            sampleInput.Add("mail_email", "jdoe@acme.com");
            sampleInput.Add("publish_flag", "yes");
            sampleInput.Add("private_extension", "Test Value for Extension");
            sampleInput.Add("rfc822name", "Extension");
        }

        // The sample application can enroll for a certificate against Automated Administration accounts and key escrow and 
        // recovery-enabled accounts. By default, this application will run against an Automated Administration account. 
        // Modify the appropriate section below for the type of account you are running this application against:
     
        //For an Automated Administration account, use the following Policy Name
        public static String PolicyName = "ManagedPKI_AutoAdmin";

        //For an PIV Account Singer, use the following Policy Name
        //public static String PolicyName = "ManagedPKI_PIV_Account_Signer";

        //For a key escrow and recovery-enabled account use the following Policy Name
        //public static String PolicyName = "ManagedPKI_KeyEscrow_DualKey_Signing";

        /*
         * Some Other possible values
        "ManagedPKI_AutoAdmin"
        "ManagedPKI_KeyEscrow_SingleKey"
        "ManagedPKI_KeyEscrow_DualKey_Encryption"
        "ManagedPKI_PIV_EndUser_Encryption"
        "ManagedPKI_PIV_Authentication"
        "ManagedPKI_PIV_Account_Signer" 
        "ManagedPKI_PIV_EndUser_Encryption"
        "ManagedPKI_PIV_EndUser_Signing"
        "ManagedPKI_PIV_Card"
        */

        //Update the following value to point to the DN of the RA certificate you will use for authentication
        public static String RACertificateDN = "CN=Admin, OU=QA, O=AcmeBank, L=Mountain View, S=California, C=US";

        //For a PIV account use the following Policy Name
//        public static String EncryptPolicyName = "ManagedPKI_PIV_EndUser_Encryption";

        //For a key escrow and recovery-enabled account use the following Policy Name
        public static String EncryptPolicyName = "ManagedPKI_KeyEscrow_DualKey_Encryption";

        /////////////////////////////////////////
        // Parameters Common to Web Services at VeriSign (Automated Administration Accounts) and at the Enterprise (Key Management Server) 
        /////////////////////////////////////////

        /*
                //Production service URLs (default). Use these URLs if you will run the application against the VeriSign production system. You must have installed a production RA certificate
                public static String policyServiceURL   = "https://pkiservices.verisign.com/policy/policyService";
                public static String enrollmentURL      = "https://pkiservices.verisign.com/enrollment/enrollmentService";
                public static String certificateMgmtURL = "https://pkiservices.verisign.com/management/certificateManagementService";
        */

        //Pilot service URLs. Use these URLs if you will run the application against the VeriSign pilot system. You must have installed a pilot RA certificate.
        public static String policyServiceURL   = "https://pilot-pkiservices.verisign.com/policy/policyService";
        public static String enrollmentURL      = "https://pilot-pkiservices.verisign.com/enrollment/enrollmentService";
        public static String certificateMgmtURL = "https://pilot-pkiservices.verisign.com/management/certificateManagementService";

        //service urls for enterprise
        public static String enterpriseServerURL = "https://hostname:8443/enrollment/enrollmentService";
        public static String enterpriseCertificateMgmtURL = "https://hostname:8443/management/certificateManagementService";
        
        //Sample public key blob, please replace this with your code genrated blob
        public static String Base64EncodedPublicKey = "MIICwjCCAisCAQAwgZwxOTA3BgNVBAMTME5hcG9sZW9uIEJvbmFwYXJ0ZUZrYlNXbHdha0lzWm5RRUdiaE9rMTc2NjY5MjIxODESMBAGA1UEBBMJQm9uYXBhcnRlMREwDwYDVQQpEwhOYXBvbGVvbjELMAkGA1UEBhMCVVMxFjAUBgNVBAsTDU1vdGhlciBSdXNzaWExEzARBgNVBAsTCldlYnNlcnZpY2UwgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAJX6L18pGPv1mFg1RlkDx+jKitydA/7Ce7I/ZLPz76XHNwiQ5ScBuXw1wsQIg1RO8pvqzOxwcKZjgnXnRuj4y8uAaGKzPkD7XmijV3YNfl2XTSZurQVLtt67ybAGU5s0ATMVVOSqzYHn+h9Mj4QhQ2AonQo01FoOTk8oIjR+SnGdAgMBAAGggeQwDQYDVR0PMQYEBAMCBeAwHwYDVR0lMRgEFjAUBggrBgEFBQcDAQYIKwYBBQUHAwcwTQYDVR0RMUYERDBCpEAwPjEdMBsGA1UEAwwUbG5laW1hbkB2ZXJpc2lnbi5jb20xHTAbBgNVBAsMFGxuZWltYW5AdmVyaXNpZ24uY29tMGMGA1UdEjFcBFowWKRAMD4xHTAbBgNVBAMMFGxuZWltYW5AdmVyaXNpZ24uY29tMR0wGwYDVQQLDBRsbmVpbWFuQHZlcmlzaWduLmNvbYEUbG5laW1hbkB2ZXJpc2lnbi5jb20wDQYJKoZIhvcNAQEFBQADgYEAC86BaUApVgwkxP2m64GQjocTC0Bs8jHXItWdGZ8yu45Vg7r72vBMfzE5imU7k21n0ibICF+iKmDYeRwUHyHrA4yQNtSLyhOSGGuYE1IHyn9ZMU6tfu+pyZiHdm7ObX8Tlt3t88Hz8rrGYhL0ZyrxsC0Gv/gafSbSer0zaUQ71KU=";

        //Location where the application will write the output files (enrolled certificates, renewed certificates, and log files). This location must exist, or the application will fail.
        public static String sampleOutputPath = "c:\\VeriSign\\PKIWebService\\";
        //Name of the saved policy file 
        public static String samplePolicyResponse = "policy.xml";

        //Name of the certificate file for the enrolled certificate
        public static String certFileName = "cert.p7b";
        //Name of the certificate file for the renewed certificate
        public static String renewCertFileName = "cert_renew.p7b";
        //Name of the certificate file for the enrolled signing certificate
        public static String kmsSignCertFileName = "kmsCert.pfx";
        //Name of the certificate file for the renewed signing certificate
        public static String kmsSignRenewCertFileName = "kmsCert_renew.pfx";
        //Name of the certificate file for the enrolled encrypt certificate
        public static String kmsEncryptCertFileName = "kmsEncryptCert.pfx";
        //Name of the certificate file for the recovered encrypt certificate
        public static String kmsRecoverCertFileName = "kmsRecoverCert.pfx";

        //Administrator certificate for the Key Recovery operation. The application must include an administrator 
        //certificate (as a x.509 message) as approval for a key recovery request. If your Key Management Server is 
        //configured to require multiple administrator approvals for key recovery requests, also provide the location 
        //for those additional administrator certificates. Add as many lines for additional administrator certificates 
        //as required by the Key Management Server.
        public static String enterpriseAdminCert1 = "c:\\VeriSign\\PKIWebService\\acmebankAdminCert1.509";
        public static String enterpriseAdminCert2 = "c:\\VeriSign\\PKIWebService\\acmebankAdminCert1.509";

        //Basic authentication information. By default, the application secures communications with the server hosting 
        //the Key Management Server using basic authentication (username and password. Enter the user name and password 
        //expected by the server. If you have implemented a different authentication method, modify the following 
        //section accordingly.
        public static String enterpriseServerUserID = "wsuser";
        public static String enterpriseServerUserPasswd = "wspwd";

        /**
	     * These are the sample NVPs required by enrollment policy for certificate enrollment. 
	     */
        public static Hashtable sampleInput = new Hashtable();
    }
}

