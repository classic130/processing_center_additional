﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Security.Cryptography.X509Certificates;
using System.Web.Services.Protocols;
using System.Net;
using System.Security.Cryptography.Pkcs;
using VeriSign.Cert.Enrollment;

/**
 * This is a utility class for the sample application.
 */
namespace SampleClient
{
    class Utils
    {
	    /**
	     * This function remove the dollar sign. We are assuming that all required input are prefixed with dollar sign.
	     */
	    public static String trimDollarSign(String value)
        {
            if (value[0] == '$')
            {
                return value.Substring(1);
            }
            else
            {
                return value;
            }
	    }

        
        /*
         * This function returns the certificate from Current User's certificate store for matching
         * Distinguished name.
         */
        public static X509Certificate2 GetCert(string subjectDistinguishedName)
        {
            X509Certificate2 cert = null;

            X509Store store = new X509Store(StoreName.My, StoreLocation.CurrentUser);
            store.Open(OpenFlags.ReadOnly);
            X509Certificate2Collection certCollection = store.Certificates.Find(
                                            X509FindType.FindBySubjectDistinguishedName,
                                            subjectDistinguishedName, true);
            try
            {
                cert = certCollection[0];
            }
            catch (Exception)
            {
                throw new Exception("Cert not found");
            }
            return (cert);
        }

        /*
         * this function displays all the certificates in the Current User's certificate store
         */
        public static void ListCerts()
        {
            X509Store store = new X509Store(StoreName.My, StoreLocation.CurrentUser);
            store.Open(OpenFlags.ReadOnly);

            foreach (X509Certificate2 x509 in store.Certificates)
            {
                Console.WriteLine("Certificate Name: {0} FriendlyName: {1}", x509.Subject, x509.FriendlyName);
            }
            return;
        }

        /**
         * This function sets the client auth certificate for the Verisign WebServices
         */
        public static bool SetClientAuth(ref SoapHttpClientProtocol stub, string certDN)
        {
            X509Certificate2 cert = Utils.GetCert(certDN);
            if (null == cert)
            {
                Console.WriteLine("\tNo Certificate found for the Client Auth! DN {0}", certDN);
                return false;
            }
//            Console.WriteLine("\tSetting: Client Cert (DN) = {0}", certDN);
            stub.ClientCertificates.Add(cert);
            return true;
        }

        /**
         * This function sets the Basic auth credentials for the Enterprise WebServices
         */
        public static bool setpEnterpriseServiceAuthentication(ref SoapHttpClientProtocol stub, String userID, String passwd)
        {
            NetworkCredential netCredential = new NetworkCredential(userID, passwd);
            stub.PreAuthenticate = true;
            Uri uri = new Uri(stub.Url);
            ICredentials credentials = netCredential.GetCredential(uri, "Basic");
            stub.Credentials = credentials;
            return true; 
        }

	    /**
	     * this function check if certificate is in renewal window
	     */
        public static bool isCertificateInRenewalWindow(X509Certificate2 cert, int certRenewalOverlap, bool canRenewExpiredCerts)
        {
            DateTime cerExpireDate = DateTime.Parse(cert.GetExpirationDateString());
            bool isCertExpired = (cerExpireDate.CompareTo(DateTime.Now) < 0);

            //check if the certificate is expired
            if (isCertExpired)
            {
                return canRenewExpiredCerts;
            }

            //If you are here then the Cert is Not expired yet
            TimeSpan expiredSince = cerExpireDate.Subtract(DateTime.Now);
            //check overlap period
            if (Math.Abs(expiredSince.Days) <= certRenewalOverlap)
            {
                return true;
            }
		    return false;
	    }

        /**
         * This function is a stub to generate the PKCS#10 for the requests. Please replace this with your implementation.
         */
        public static string generateCSRWithPublicKeyOnly(int keysize, String pKCS12FileName, String pKCS12Passwd)
        {
            //Please user your logic to create the dynamic value for this
            return SampleParameters.Base64EncodedPublicKey;
        }

        /**
        /* This function serializes RequestVSSecurityTokenEnrollmentType to XMLElement[]
        */
        public static XmlElement[] XMLSerializeRequestVSSecurityToken(RequestVSSecurityTokenEnrollmentType requestVSSecurityTokenEnrollment)
        {
            MemoryStream stream = null;
            TextWriter writer = null;
            try
            {
                stream = new MemoryStream(); // read xml in memory
                writer = new StreamWriter(stream, Encoding.UTF8);
                XmlSerializer serializer = new XmlSerializer(typeof(RequestVSSecurityTokenEnrollmentType));
                serializer.Serialize(writer, requestVSSecurityTokenEnrollment); // read object
                int count = (int)stream.Length; // saves object in memory stream

                byte[] arr = new byte[count];
                stream.Seek(0, SeekOrigin.Begin);
                // copy stream contents in byte array
                stream.Read(arr, 0, count);

                UTF8Encoding utf8 = new UTF8Encoding();
                XmlElement[] returnValue = new XmlElement[1];
                XmlDocument xd = new XmlDocument();
                xd.InnerXml = utf8.GetString(arr).Trim();
                returnValue[0] = xd.DocumentElement;

                return returnValue;
            }
            catch (System.Exception e)
            {
                System.Console.WriteLine(e.StackTrace.ToString());
                return null;
            }
            finally
            {
                if (stream != null) stream.Close();
                if (writer != null) writer.Close();
            }
        }

        /*
        /* This function serializes getPoliciesResponse to String
        */
        public static String XMLSerializePoliciesResponse(getPoliciesResponse policiesResponse)
        {
            MemoryStream stream = null;
            TextWriter writer = null;
            try
            {
                stream = new MemoryStream(); // read xml in memory
                writer = new StreamWriter(stream, Encoding.UTF8);
                XmlSerializer serializer = new XmlSerializer(typeof(getPoliciesResponse));
                serializer.Serialize(writer, policiesResponse); // read object
                int count = (int)stream.Length; // saves object in memory stream

                byte[] arr = new byte[count];
                stream.Seek(0, SeekOrigin.Begin);
                // copy stream contents in byte array
                stream.Read(arr, 0, count);

                UTF8Encoding utf8 = new UTF8Encoding();
                return utf8.GetString(arr).Trim();
            }
            catch (System.Exception e)
            {
                System.Console.WriteLine(e.StackTrace.ToString());
                return null;
            }
            finally
            {
                if (stream != null) stream.Close();
                if (writer != null) writer.Close();
            }
        }

        /**
         * This function gives the file name based on the renewal and key escrow flags
         */
        public static String getFileName(bool isRenew, bool isKeyescrow)
        {
            if (isKeyescrow)
            {
                if (isRenew)
                {
                    return SampleParameters.sampleOutputPath + SampleParameters.kmsSignRenewCertFileName;
                }
                else
                {
                    return SampleParameters.sampleOutputPath + SampleParameters.kmsSignCertFileName;
                }
            }
            else
            {
                if (isRenew)
                {
                    return SampleParameters.sampleOutputPath + SampleParameters.renewCertFileName;
                }
                else
                {
                    return SampleParameters.sampleOutputPath + SampleParameters.certFileName;
                }
            }
        }

        /*
         * This function base64 decodes the string and save it in a file. It also removes any existing file.
         */
        public static void base64decodeAndSavetoFile(String certFileName, String blob)
        {
            if (File.Exists(certFileName))
            {
                File.Delete(certFileName);
            }

            if (null != blob)
            {
                FileStream fs = new FileStream(certFileName, FileMode.Create);
                BinaryWriter binaryWriter = new BinaryWriter(fs);
                binaryWriter.Write(Convert.FromBase64String(blob));
                binaryWriter.Close();
                Console.WriteLine("\tCert Response saved in '{0}' file.", certFileName);
            }
        }

        /*
         * This function save string in a file. It also removes any existing file.
         */
        public static void saveToTextFile(String fileName, String blob)
        {
            if (File.Exists(fileName))
            {
                File.Delete(fileName);
            }
            TextWriter textWriter = new StreamWriter(fileName, true);
            textWriter.WriteLine(blob);
            textWriter.Close();
        }

        /*
         * This function parses a base64 string and retures the end entiry certificate from it.
         */
        public static X509Certificate2 getCertFromPKCS7(String base64PKCS7)
        {
            String blob = base64PKCS7;
            //Remove the Leading and trailing header entries
            if (blob.StartsWith("-----BEGIN PKCS7-----"))
            {
                blob = blob.Substring(21);
                blob = blob.Substring(0, blob.IndexOf("---"));
            }
            blob = blob.Replace("\r\n", "\n");
            blob = blob.Trim();

            SignedCms p7b = new SignedCms();
            p7b.Decode(Convert.FromBase64String(blob));

            //Loop through the certificates in the response
            foreach (X509Certificate2 cert in p7b.Certificates)
            {
                //Loop through the extensions to find the End Entity Certificate
                foreach (X509Extension ext in cert.Extensions)
                {
                    X509BasicConstraintsExtension basicConstrainExt = ext as X509BasicConstraintsExtension;
                    if (null != basicConstrainExt)
                    {
                        if (basicConstrainExt.CertificateAuthority)
                        {
//                            Console.WriteLine("\tIgnoring the CA Certificate.");
                        }
                        else
                        {
                            return cert;
                        }
                    }
                }
            }
            return null;
        }

        /*
         * This function returns the endpoint based on the Profile selected
         * */
        public static bool isVeriSignWebServiceEndPoint(String policyName)
        {
            if (
            (0 == policyName.CompareTo("ManagedPKI_KeyEscrow_SingleKey")) ||
            (0 == policyName.CompareTo("ManagedPKI_KeyEscrow_DualKey_Encryption")) ||
            (0 == policyName.CompareTo("ManagedPKI_PIV_EndUser_Encryption")))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public static bool setServiceAuthentication(bool isVeriSignURL, ref SoapHttpClientProtocol stub)
        {
            if (isVeriSignURL)
            {
                //prepare for SSL mutual authentication between the sample application PKI Web service
                if (false == Utils.SetClientAuth(ref stub, SampleParameters.RACertificateDN))
                {
                    return false; //Error
                }
            }
            else
            {
                //prepare for SSL mutual authentication between the sample application PKI Web service
                if (false == Utils.setpEnterpriseServiceAuthentication(ref stub, SampleParameters.enterpriseServerUserID, SampleParameters.enterpriseServerUserPasswd))
                {
                    return false; //Error
                }
            }
            return true;
        }

    }

    /*
    * This class derives out of the Stub created by the WSDL tool and overrides GetWebRequest method to set the Keep alive
    * flag to false. Failing to do that results in an exception from the server, stating "Server closed the underlying conection."
    */
    public class veriSignCertIssuingServiceVS : veriSignCertIssuingService
    {
        protected override WebRequest GetWebRequest(Uri uri)
        {
            HttpWebRequest webRequest = (HttpWebRequest)base.GetWebRequest(uri);

            webRequest.KeepAlive = false;
            return webRequest;
        }
    }
}

namespace VeriSign.Cert.Mangment
{
    /*
    * This class derives out of the Stub created by the WSDL tool and overrides GetWebRequest method to set the Keep alive
    * flag to false. Failing to do that results in an exception from the server, stating "Server closed the underlying conection."
    */
    public class certificateManagementServiceVS : certificateManagementService
    {
        protected override WebRequest GetWebRequest(Uri uri)
        {
            HttpWebRequest webRequest = (HttpWebRequest)base.GetWebRequest(uri);

            webRequest.KeepAlive = false;
            return webRequest;
        }
    }

}

