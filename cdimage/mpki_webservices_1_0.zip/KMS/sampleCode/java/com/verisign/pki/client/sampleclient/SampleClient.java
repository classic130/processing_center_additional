package com.verisign.pki.client.sampleclient;

import java.rmi.RemoteException;

import java.security.cert.X509Certificate;

import org.apache.axis2.AxisFault;
import org.apache.axis2.databinding.ADBException;

import com.sun.org.apache.xerces.internal.util.URI.MalformedURIException;

/**
 * This class use SamplePolicyServiceClient, SampleEnrollmentServiceClient and SampleCertMgmtClient
 * to demonstrate how to get enrollment policy, enroll, renew, suspend,resume and revoke a certificate. 
 * It also demonstrate how to get a keyescrow certificate.
 * @author VeriSign Inc.
 *
 */
public class SampleClient {

	public static void main(String[] args) {
		try {

			//Step 1: get a SamplePolicyServiceClient. Note: SamplePolicyServiceClient is a singleton class and you only get policy once
			System.out.println("SampleClient:Create SamplePolicyServiceClient");
			SamplePolicyServiceClient samplePolicyServiceClient = SamplePolicyServiceClient.getInstance();
			

			//Step 2: get enrollment policies with an oid default name from SamplePolicyServiceClient
			//        An oid prefix defines the purpose of the certificate.
			//        for supported prefixes, see SamplePolicyServiceClient. 
			//		  You should have this profile if your account is enabled for Key Management Server
			PolicyServiceStub.CertificateEnrollmentPolicy [] enrollmentPolicies = samplePolicyServiceClient.getEnrollmentPoliciesByDefaultName(SampleParameters.enrollCertProfileOIDDefaultName);
				
			if(enrollmentPolicies.length > 0) {
				
			//Step 3: Enroll for a certificate. Note, here we are enrolling for a short term certificate so we can demo the certificate renewal because certificate can only be renewed if it is in renewal window.
				System.out.println("SampleClient: Enroll for a certificate");	
				String resultCerPKCS7B64 = null;
				//use the first enrollmentPolicy in enrollmentPoliciesWithPrefix to enroll for a certificate. 
				PolicyServiceStub.CertificateEnrollmentPolicy enrollmentPolicy = enrollmentPolicies [0];
				//check if certificateValididt can be override
				if(enrollmentPolicy.getAttributes().getCertificateOverrideValidity()== null || enrollmentPolicy.getAttributes().getCertificateOverrideValidity().getOverrideFlag()) {
					//get renewal window from certificateValidity policy
					int renewalPeriodDays = 0;
					if(enrollmentPolicy.getAttributes().getCertificateValidity() != null) {
						renewalPeriodDays = enrollmentPolicy.getAttributes().getCertificateValidity().getRenewalPeriodDays().intValue();
					}
					//create enrollment client
					SampleEnrollmentServiceClient sampleEnrollmentServiceClient = new SampleEnrollmentServiceClient(enrollmentPolicy,samplePolicyServiceClient.getOIDByReferenceID(enrollmentPolicy.getPolicyOIDReference()).getValue(),SampleParameters.sampleOutputPath + "/" + SampleParameters.signcertFileName);
					
					//enroll for a certificate. 
					//use renewalPeriodDays as the overrideValidityDays for the certificate so we can renew right away for demonstration purpose.

					VeriSignCertIssuingServiceStub.RequestSecurityTokenResponse response = sampleEnrollmentServiceClient.enrollForCertificate(SampleEnrollmentServiceClient.REQUEST_TYPE_ISSUE.getValue(), null, renewalPeriodDays);
					//process result
					resultCerPKCS7B64 = sampleEnrollmentServiceClient.processRequestSecurityTokenResponse(response);
				}
			
			//Step 4: Renew the certificate
				System.out.println("SampleClient:Renew the certificate");
				String certRenew = null;
				if(resultCerPKCS7B64 != null){
					//create enrollment client
					SampleEnrollmentServiceClient renewalEnrollmentServiceClient = new SampleEnrollmentServiceClient(enrollmentPolicy,samplePolicyServiceClient.getOIDByReferenceID(enrollmentPolicy.getPolicyOIDReference()).getValue(),SampleParameters.sampleOutputPath + "/" + SampleParameters.renewCertFileName);

					//renew the certificate, this time, do not specify the overrideValidity
					VeriSignCertIssuingServiceStub.RequestSecurityTokenResponse responseRenew = renewalEnrollmentServiceClient.enrollForCertificate(SampleEnrollmentServiceClient.REQUEST_TYPE_RENEW.getValue(), resultCerPKCS7B64, 0);
					//save the certificate
					certRenew = renewalEnrollmentServiceClient.processRequestSecurityTokenResponse(responseRenew);
				}
			
			//Step 5: Suspend the renewed certificate
				System.out.println("SampleClient: Suspend the renewed certificate");
				SampleCertMgmtClient sampleCertMgmtClient = new SampleCertMgmtClient();
				int suspendResult = sampleCertMgmtClient.suspendCertificate(Utils.getCertSerial(certRenew), Utils.getCertIssuer(resultCerPKCS7B64));
				if(suspendResult != 0) {
					System.out.println("ERROR: Certificate is not suspended\n");
				}
			
			//Step 6: Resume the renewed certificate
				System.out.println("SampleClient: Step 6: Resume the renewed certificate");
				int resumeResult = sampleCertMgmtClient.resumeCertificate(Utils.getCertSerial(certRenew), Utils.getCertIssuer(resultCerPKCS7B64));
				if(resumeResult != 0) {
					System.out.println("ERROR: Certificate is not resumeded\n");
				}			
			//Step 7: Revoke the renewed certificate
				System.out.println("SampleClient: Step 7: Revoke the renewed certificate");
				int revokeResult = sampleCertMgmtClient.revokeCertificate(Utils.getCertSerial(certRenew),CertificateManagementServiceStub.RevokeReasonCodeEnum.KeyCompromise, Utils.getCertIssuer(resultCerPKCS7B64));		
				if(revokeResult != 0) {
					System.out.println("ERROR: Certificate is not revokeded\n");
				}				
			}

			//Step 8: enroll for a keyescrow certificate 
			System.out.println("SampleClient: Enroll for a keyescrow certificate");
			//search for the enrollment policy with keyescrow feature.You should have this profile if your account is enabled for Key Management Server.
			PolicyServiceStub.CertificateEnrollmentPolicy [] kmsEncryptionCertEnrollmentPolicies = samplePolicyServiceClient.getEnrollmentPoliciesByDefaultName(SampleParameters.kmsCertProfileOIDDefaultName);
			if(kmsEncryptionCertEnrollmentPolicies.length > 0) {
				//use the first policy to enroll for a certificate.		
				PolicyServiceStub.CertificateEnrollmentPolicy kmsPolicy = kmsEncryptionCertEnrollmentPolicies[0];
				
				//create enrollment client
				SampleEnrollmentServiceClient kmsEnrollmentServiceClient = new SampleEnrollmentServiceClient(kmsPolicy,samplePolicyServiceClient.getOIDByReferenceID(kmsPolicy.getPolicyOIDReference()).getValue(),SampleParameters.sampleOutputPath + "/" + SampleParameters.kmsEncryptionCertFileName);
				VeriSignCertIssuingServiceStub.RequestSecurityTokenResponse kmsEncryptionRequestSecurutyTokenResponse = kmsEnrollmentServiceClient.enrollForCertificate(SampleEnrollmentServiceClient.REQUEST_TYPE_ISSUE.getValue(),null,0);
	            String p12 = kmsEnrollmentServiceClient.processRequestSecurityTokenResponse(kmsEncryptionRequestSecurutyTokenResponse);
	            //String certSerial = Utils.getCertSerial(p12);
	        //Step 9: recover the key
	            System.out.println("SampleClient: Recover Key");
	            
	            String passwd = Utils.getPKCS12Passwd(kmsEncryptionRequestSecurutyTokenResponse);	
	            SampleCertMgmtClient sampleCertMgmtClient = new SampleCertMgmtClient();
	            X509Certificate x509Cert = Utils.getCertFromPKCS12(p12, passwd);
	            
	            CertificateManagementServiceStub.RequestKeyRecoveryResponseMessage requestKeyRecoveryResponseMessage = sampleCertMgmtClient.requestKeyRecovery(Utils.getCertSerial(x509Cert), Utils.getCertIssuer(x509Cert), Utils.getX509FromFile(SampleParameters.enterpriseAdminCert),SampleParameters.pKCS12password);
	            boolean requireAdditionalAdminApproval = sampleCertMgmtClient.processKeyRecoveryResponse(requestKeyRecoveryResponseMessage, SampleParameters.sampleOutputPath, SampleParameters.kmsRecoveredCertFileName);
	            //send second request with second admin
	            if (requireAdditionalAdminApproval) {
	            	System.out.println("SampleClient: Additional Admin approval required, sending second request");
	            	CertificateManagementServiceStub.RequestKeyRecoveryResponseMessage requestKeyRecoveryResponseMessage2 = sampleCertMgmtClient.requestKeyRecovery(Utils.getCertSerial(x509Cert), Utils.getCertIssuer(x509Cert), Utils.getX509FromFile(SampleParameters.enterpriseAdminCert2),SampleParameters.pKCS12password);
		            sampleCertMgmtClient.processKeyRecoveryResponse(requestKeyRecoveryResponseMessage2, SampleParameters.sampleOutputPath, SampleParameters.kmsRecoveredCertFileName);
	            }
			}
		} catch (AxisFault a) {
			a.getFaultCode();
			System.out.println("ERROR CODE : " + a.getFaultCode());
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (ADBException e) {
			e.printStackTrace();
		} catch (MalformedURIException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} catch (Throwable e) {
			e.printStackTrace();
		} 

	}
}
