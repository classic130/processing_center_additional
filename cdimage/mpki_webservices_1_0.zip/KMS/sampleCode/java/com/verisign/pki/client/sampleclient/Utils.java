package com.verisign.pki.client.sampleclient;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;

import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import javax.security.auth.x500.X500Principal;
import org.apache.axiom.om.OMElement;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.axis2.transport.http.HttpTransportProperties;
import org.bouncycastle.asn1.x509.X509Name;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.jce.PKCS10CertificationRequest;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.x509.X509V1CertificateGenerator;

/**
 * This is a utility class for the sample application.
 * @author VeriSign Inc.
 *
 */
public class Utils {
	/**
	 * This function prepare the java environment for SSL client authentication
	 * @param keyStore
	 * @param keyStorePwd
	 * @param cAStore
	 * @param cAStorePasswd
	 */
	public static void setupSSLClientAuth(String keyStore,String keyStorePwd, String cAStore,String cAStorePasswd){
		
		//setup client certificate key store and password
		System.setProperty("javax.net.ssl.keyStore",keyStore);
		System.setProperty("javax.net.ssl.keyStorePassword", keyStorePwd);
		
		//setup trusted CA store and password. This should contain the CA for VeriSign Web Service certificate. 
		System.setProperty("javax.net.ssl.trustStore", cAStore);
		System.setProperty("javax.net.ssl.trustStorePassword", cAStorePasswd);
	}

	
	/**
	 * This function prepare the authentication for enterprise server that use user nase and password
	 * @param clientOptions
	 * @param enterpriseServerUserID
	 * @param enterpriseServerUserPasswd
	 */
	public static void setupkeyManagementServerAuthentication(org.apache.axis2.client.Options clientOptions,String enterpriseServerUserID,String enterpriseServerUserPasswd){
		//client auth information		
		HttpTransportProperties.Authenticator authenticator = new HttpTransportProperties.Authenticator ();
		authenticator.setUsername (enterpriseServerUserID);
		authenticator.setPassword (enterpriseServerUserPasswd);  
		authenticator.setPreemptiveAuthentication (true);    
		clientOptions.setProperty (HTTPConstants.AUTHENTICATE, authenticator);
	}

	/**
	 * this function simply dump a string to a file
	 * @param fileName
	 * @param response
	 * @throws IOException
	 */
	public static void saveTextToFile(String fileName, String text) throws IOException{
		FileOutputStream  out = new FileOutputStream (fileName);
		out.write(text.getBytes());		
		out.close();
	}
	/**
	 * this function base64 decode the string before save it to a file
	 * @param fileName
	 * @param text
	 * @throws IOException
	 */
	public static void base64decodeAndSaveTextToFile(String fileName, String text) throws IOException{
		FileOutputStream  out = new FileOutputStream (fileName);
		out.write(Base64.decode(text.getBytes()));		
		out.close();
	}
	/**
	 * This function returns a hex encoded certificate serial number
	 * @param String
	 * @return hex encoded certificate serial number
	 * @throws CertificateException
	 * @throws NoSuchProviderException
	 */
	public static String getCertSerial(String x509Cert  ) throws CertificateException, NoSuchProviderException{
		
		CertificateFactory certificateFactory = CertificateFactory.getInstance("X509", "BC"); 
		X509Certificate certificate = (X509Certificate) certificateFactory.generateCertificate(new ByteArrayInputStream(Base64.decode(x509Cert.getBytes())));
		return getCertSerial( certificate);
	}
	/**
	 * 
	 * @param String
	 * @return
	 * @throws CertificateException
	 * @throws NoSuchProviderException
	 */
	public static String getCertIssuer(String x509Cert ) throws CertificateException, NoSuchProviderException{
		CertificateFactory certificateFactory = CertificateFactory.getInstance("X509", "BC"); 
		X509Certificate certificate = (X509Certificate) certificateFactory.generateCertificate(new ByteArrayInputStream(Base64.decode(x509Cert.getBytes())));
		return getCertIssuer( certificate);
	}
	/**
	 * 
	 * @param certificate
	 * @return
	 */
	public static String getCertIssuer(X509Certificate certificate){
		return certificate.getIssuerX500Principal().getName();
	}
	/**
	 * 
	 * @param certificate
	 * @return
	 * @throws CertificateException
	 * @throws NoSuchProviderException
	 */
	public static String getCertSerial(X509Certificate certificate) throws CertificateException, NoSuchProviderException{
		int hexRadix = 16; //base for hex encoding
		String certSerial = certificate.getSerialNumber().toString(hexRadix);
		//add lead "0" if trimmed
		while (certSerial.length()%hexRadix !=0) {
			certSerial = "0" + certSerial;
		}
		return certSerial;
		
	}
	/**
	 * this function get the end entity cert from pkcs12
	 * @param pKCS12
	 * @param passwd
	 * @return X509Certificate 
	 * @throws KeyStoreException
	 * @throws NoSuchProviderException
	 * @throws NoSuchAlgorithmException
	 * @throws CertificateException
	 * @throws IOException
	 */
	public static X509Certificate getCertFromPKCS12(String pKCS12, String passwd) throws KeyStoreException, NoSuchProviderException, NoSuchAlgorithmException, CertificateException, IOException {
		X509Certificate certificate = null;
		KeyStore pkcs12KeyStore = KeyStore.getInstance("PKCS12");
		pkcs12KeyStore.load( new ByteArrayInputStream(Base64.decode(pKCS12.getBytes())),passwd.toCharArray());
		Enumeration <String> aliases =pkcs12KeyStore.aliases();
		while (aliases.hasMoreElements()){
			certificate = (X509Certificate)pkcs12KeyStore.getCertificate(aliases.nextElement());
			boolean keyUsage[] = certificate.getKeyUsage();
			if(!keyUsage[5]) return certificate;  //keyUsage[5] is cert sign. If this is not, meaning this is an end entity cert.
		}
		return certificate;
	}
	/**
	 * Check  certificate is in renewal window
	 * @param x509B64
	 * @param certRenewalOverlap
	 * @param canRenewExpiredCerts boolean, is expired cert allowed to be renewed
	 * @return
	 * @throws CertificateException
	 * @throws NoSuchProviderException
	 */
	public static boolean isCertificateInRenewalWindow(String x509B64,int certRenewalOverlap, boolean canRenewExpiredCerts) throws CertificateException, NoSuchProviderException{
		CertificateFactory certificateFactory = CertificateFactory.getInstance("X509", "BC"); 
		X509Certificate certificate = (X509Certificate) certificateFactory.generateCertificate(new ByteArrayInputStream(Base64.decode(x509B64.getBytes())));
		//check if the certificate is expired
		if(certificate.getNotAfter().before(new Date()) && canRenewExpiredCerts){
			return false;
		}
		//check overlap period
		Calendar overlapDate = Calendar.getInstance();
		overlapDate.setTime(certificate.getNotAfter());
		overlapDate.add(Calendar.DATE, -certRenewalOverlap);
		
		if(overlapDate.before(Calendar.getInstance())){
			return false;
		}		
		return true;
	}
	/**
	 * Check  certificate is in renewal window, don't care if certificate is expired
	 * @param renewX509B64
	 * @param certRenewalOverlap
	 * @return
	 * @throws CertificateException
	 * @throws NoSuchProviderException
	 */
	public static boolean isCertificateInRenewalWindow(String renewX509B64,int certRenewalOverlap) throws CertificateException, NoSuchProviderException{
		return isCertificateInRenewalWindow(renewX509B64,certRenewalOverlap, true);
	}
	/**
	 * This function remove the dollar sign. We are assuming that all required input are prefixed with dollar sign.
	 * @param string String
	 * @return String
	 * @throws Exception
	 */
	public static String trimDollarSign(String string)throws Exception{
		//TODO: we are always assuming string always start with $ sign. Will add dollar sign check
		return string.substring(1,string.length());
	}
	/**
	 * This function generate a simple CSR with public key information only using Bouncy Castle
	 * It also saves the private key in a PKCS 12 together with a self signed cert. This pkcs12 will be used later to install the 
	 * real certificate from web services.
	 * 
	 * @param keySize
	 * @return String csr
	 * @throws GeneralSecurityException 
	 * @throws IOException 
	 */
	public static String generateCSRWithPublicKeyOnly(int keySize, String pKCS12FileName, String pKCS12Passwd ,String alias) throws GeneralSecurityException, IOException {
		Provider provider = new BouncyCastleProvider();
		java.security.Security.addProvider(provider);
		KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA", "BC");
		kpg.initialize(keySize);
		KeyPair kp = kpg.generateKeyPair();
		//generate a empty subjectName with cn only
		X509Name subject = new X509Name("cn=");
		PKCS10CertificationRequest certRequest= new  PKCS10CertificationRequest("sha1withrsa",subject,kp.getPublic(),null,kp.getPrivate());
		byte [] requestDer= certRequest.getDEREncoded();
		X509Certificate selfSignedCert = createSelfSignedCert(kp);
		Certificate certificates[] = {selfSignedCert};
		KeyStore pkcs12KeyStore = KeyStore.getInstance("PKCS12");
		//for a new store load null
		pkcs12KeyStore.load(null);
		pkcs12KeyStore.setKeyEntry(alias, kp.getPrivate(),pKCS12Passwd.toCharArray(), certificates);
		FileOutputStream pKCS12File = new FileOutputStream(pKCS12FileName);
		pkcs12KeyStore.store(pKCS12File,pKCS12Passwd.toCharArray());
		pKCS12File.close();
		return new String(Base64.encode(requestDer));	
	}	

	/**
	 * this function base64 decode text before save it to a file
	 * @param fileName
	 * @param tokenElement
	 * @return
	 * @throws IOException
	 * @throws CMSException
	 */
	public static String base64DecodeAndSaveElementToFile(String fileName,OMElement tokenElement) throws IOException, CMSException {
		
		String cert = tokenElement.getText();
		if(cert != null && !cert.equals("")){
			byte[] binaryCert = Base64.decode(cert);
			FileOutputStream  out = new FileOutputStream (fileName);
			out.write(binaryCert);
			out.close();
		}
		return cert;
		
	}
	/**
	 * this function derive pkcs12 password from enrollment response
	 * @param requestSecurutyTokenResponse
	 * @return
	 * @throws IOException
	 * @throws CMSException
	 */
	public static String getPKCS12Passwd(VeriSignCertIssuingServiceStub.RequestSecurityTokenResponse requestSecurutyTokenResponse) throws IOException, CMSException {
		OMElement[] tokenElements = requestSecurutyTokenResponse.getRequestSecurityTokenResponse().getExtraElement();
		return findElementValue(tokenElements, "pKCS12Password");
	}	
	/**
	 * this function returns the security token string from OMElement
	 * @param elements
	 * @param elementName TODO
	 * @return
	 */
	public static String findElementValue(OMElement []elements, String elementName){
		if (elements == null)
			return null;
		for( OMElement el : elements )
		{
			OMElement t = findElement(el, elementName);
			if (t != null)
			{
				return t.getText();
			}
		}
		return null;
	}
	/**
	 * this function search an OMElement.
	 * @param root
	 * @param node_name
	 * @return
	 */
	public static OMElement findElement(OMElement root, String node_name)
	{
		if (root.getQName().getLocalPart().equals(node_name))
		{
			return root;
		}
		java.util.Iterator<OMElement> iter = root.getChildElements();
		OMElement el;
		while (iter.hasNext())
		{
			el = iter.next();
			OMElement p = findElement(el, node_name);
			if (p != null)
			{
				return p;
			}
		}
		return null;
	}
	/**
	 * This function get X509Certificate from a cer file
	 * @param file
	 * @return
	 * @throws CertificateException
	 * @throws NoSuchProviderException
	 * @throws IOException
	 */
	public static String getX509FromFile(String file) throws CertificateException, NoSuchProviderException, IOException{
		CertificateFactory certificateFactory = CertificateFactory.getInstance("X509"); 
		FileInputStream inputFile = new FileInputStream(file);
		X509Certificate certificate = (X509Certificate) certificateFactory.generateCertificate(inputFile);
		inputFile.close();
		return new String(Base64.encode(certificate.getEncoded()));		
	}
	/**
	 * this function create a self signed certificate
	 * @param keyPair
	 * @return
	 * @throws GeneralSecurityException
	 */
	public static X509Certificate createSelfSignedCert(KeyPair keyPair ) throws GeneralSecurityException{
		Calendar calendar = Calendar.getInstance();
		Date startDate = calendar.getTime();
		calendar.add(Calendar.DATE, +1);
		Date expiryDate = calendar.getTime();		
		BigInteger serialNumber = new BigInteger(String.valueOf(System.currentTimeMillis()));
		return createSelfSignedCert(startDate, expiryDate, serialNumber, keyPair );
	
	}
	/**
	 * this function create a self signed certificate
	 * @param startDate
	 * @param expiryDate
	 * @param serialNumber
	 * @param keyPair
	 * @return
	 * @throws GeneralSecurityException
	 */
	public static X509Certificate createSelfSignedCert(Date startDate, Date expiryDate, BigInteger serialNumber, KeyPair keyPair ) throws GeneralSecurityException {
		X509V1CertificateGenerator certGen = new X509V1CertificateGenerator();
		X500Principal              dnName = new X500Principal("CN=Test CA Certificate");

		certGen.setSerialNumber(serialNumber);
		certGen.setIssuerDN(dnName);
		certGen.setNotBefore(startDate);
		certGen.setNotAfter(expiryDate);
		certGen.setSubjectDN(dnName);                       // note: same as issuer
		certGen.setPublicKey(keyPair.getPublic());
		certGen.setSignatureAlgorithm("SHA1withRSA");

		X509Certificate cert = certGen.generate(keyPair.getPrivate(), "BC");
		return cert;		
	}
	/**
	 * This function sve the certificate to the PKCS12 file created before when generate CSR
	 * @param base64Cert
	 * @param pKCS12FileName
	 * @param passwd
	 * @param alias
	 * @throws GeneralSecurityException
	 * @throws Exception
	 * @throws IOException
	 */
	public static void installCertToPKCS12(String base64Cert,String pKCS12FileName,String passwd, String alias) throws GeneralSecurityException, Exception, IOException{
		Provider provider = new BouncyCastleProvider();
		java.security.Security.addProvider(provider);
		CertificateFactory certificateFactory = CertificateFactory.getInstance("X509","BC"); 
		X509Certificate certificate= (X509Certificate) certificateFactory.generateCertificate(new ByteArrayInputStream(Base64.decode(base64Cert.getBytes())));
		X509Certificate certificates[] = {certificate};
		KeyStore pkcs12KeyStore = KeyStore.getInstance("PKCS12");
		FileInputStream inputStream = new FileInputStream(pKCS12FileName);
		pkcs12KeyStore.load( inputStream,passwd.toCharArray());
		inputStream.close();
		Key privateKey = pkcs12KeyStore.getKey(alias, passwd.toCharArray());
		pkcs12KeyStore.setKeyEntry(alias, privateKey, passwd.toCharArray(), certificates);
		FileOutputStream outputStream = new FileOutputStream(pKCS12FileName);
		pkcs12KeyStore.store(outputStream,passwd.toCharArray());
		outputStream.close();		
	}
}
