package com.verisign.pki.client.sampleclient;

import java.util.HashMap;

/**
 * This class defines the sample parameters used in the sample application. 
 * You need to register for an VeriSIgn PKI account and have prepared RA certificate store before 
 * you modify these parameters to suit your own situation. In case you need to try enterprise service (key management), you 
 * will also need to set up your enterprise service. In particular, you will need to replace information in "<...>"
 * @author VeriSign Inc.
 *
 */
public class SampleParameters {
	//RA key store information
	public static String raKeyStore = "<full path for your ra key store>"; 
	public static String raKeyStorePasswd = "<ra key store password>"; 
	public static String caStore = "<full path of your ca store>"; 
	public static String caStorePasswd = "<ca store password>"; 
	public static String enterpriseAdminCert = "<full path of your enterprise admin certificate>"; 
	public static String enterpriseAdminCert2 = "<full path of your second aenterprise admin certificate (in case of dual control)>"; 
	//Key Management Server user info
	public static String keyManagementServerUser = "<userid of your key management server>";
	public static String keyManagementUserUserPasswd = "<password for the userid of your keymanagement server>";
	
	//service urls. Please refer to Developer's Guide for actual values. 
	public static String policyServiceURL = "https://<host:port for pki web service>/policy/policyService"; 
	public static String enrollmentURL = "https://<host:port for pki web service>/enrollment/enrollmentService";
	public static String keyManagementServerURL = "https://<host:port for your key management server>/enrollment/enrollmentService";
	public static String certificateMgmtURL = "https://<host:port for verisign pilot or production pki web service>/management/certificateManagementService";
	public static String enterpriseCertificateMgmtURL = "https://<host:port for your key management server>/management/certificateManagementService";
	//sample output folder and file names
	public static String sampleOutputPath = "<full path for your sample output>";  
	public static String samplePolicyResponse = "sampleResponse.xml";
	public static String certFileName = "testcert.p7b";
	public static String signcertFileName = "signcert.p7b";
	public static String renewCertFileName = "renew_signcert.p7b";
	public static String kmsEncryptionCertFileName = "kms_encryptioncert.p12";  //This is for enrolling certificate that is enabled for Key Management Server
	public static String kmsRecoveredCertFileName = "kms_recovered_encryptioncert.p12";  //This is for enrolling certificate that is enabled for Key Management Server
	
	//pkcs12 password passed to Key Management Server. Please refer to your Key Management Server guide to set this value properly. 
	public static String pKCS12password = null;

	/**
	 * TODO: change the enrollment policy default name that is applicable to your account. Here is a list of default name that is supported now and documented in integration guide.
	 * 
	 * ManagedPKI_AutoAdmin   - for Automated Administration                                                                    
	 * ManagedPKI_KeyEscrow_SingleKey - for	Key Escrow and Recovery (Single Key)                                             
	 * ManagedPKI_KeyEscrow_DualKey_SigningKey - for Escrow and Recovery (Dual Key - Signing Certificate)           
     * ManagedPKI_KeyEscrow_DualKey_Encryption - for Key Escrow and Recovery (Dual Key - Encryption Certificate)      
     * ManagedPKI_PIV_Authentication - for PIV Authentication Certificate                                                               
     * ManagedPKI_PIV_Account_Signer - for PIV Signing Certificate                                                                           
     * ManagedPKI_PIV_EndUser_Encryption  - for PIV Encryption Certificate                                                                      
     * ManagedPKI_PIV_Card - for  PIV Card Certificate                                                                                
     * ManagedPKI_PIV_EndUser_Signing - for PIV Signer Certificate                                                                             . 
     */
	public static String enrollCertProfileOIDDefaultName = "ManagedPKI_KeyEscrow_DualKey_Signing";
	public static String kmsCertProfileOIDDefaultName = "ManagedPKI_KeyEscrow_DualKey_Encryption"; //TODO: this is the profile oid default name for certificate that is enabled for Key Management Server

	//API Versions
	public static String policyAPIVersion = "1.0"; 
	public static String enrollmentAPIVersion = "1.0"; 
	public static String certMgmtAPIVersion = "1.0"; 

	//preferred language
	public static String preferredLanguage = "en-us";
	
	/**
	 * These are the sample NVPs required by enrollment policy for certificate enrollment. 
	 */
	public static HashMap <String,String> sampleInput = new HashMap<String,String>();
	static { 
		sampleInput.put("common_name", "J. Doe" + System.currentTimeMillis());  
		sampleInput.put("mail_stop", "23");  
		sampleInput.put("jobTitle", "engineer");  
		sampleInput.put("mail_email", "jdoe@acme.com"); 
		sampleInput.put("org_unit", "qa");  
		sampleInput.put("corp_company", "J. Doe"); 
		sampleInput.put("locality", "MV");  
		sampleInput.put("publish_flag", "yes"); 
		sampleInput.put("cert_extension1","cert_extension1");
		sampleInput.put("private_extension1_field1", "1234567");
		sampleInput.put("additional_field4","additional_field4");
	}
	//Sample certSerial for revoke purpose
	public static String sampleCertSerial = "<serial number for certificate you want to revoke, e.g. 79f7d1e175e78684731fef1683ea8002>";
	public static String sampleCertIssuer = "<issuer for certificate you want to revoke, e.g. CN=...,OU=...>";
}


