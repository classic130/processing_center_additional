package com.verisign.pki.client.sampleclient;

import java.io.IOException;
import java.rmi.RemoteException;
import java.util.ArrayList;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axis2.databinding.ADBException;

import com.verisign.pki.client.sampleclient.PolicyServiceStub.GetPolicies;
import com.verisign.pki.client.sampleclient.PolicyServiceStub.VersionType;


/**
 * This class demonstrate how to get enrollment policies from VeriSign PKI web service.
 * The service stub PolicyServiceStub is generated using AXIS2 tool. It also generated supporting classes that
 * prefixed with PolicyServiceStub in this example
 * <p>
 * <AXIS_HOME>/bin/wsdl2java.sh -uri <url_for wsdl>/CertificateEnrollmentPolicy.wsdl -p com.verisign.pki.client.sampleclient -d adb -s -o <path_for_generated_source_code> 
 * @throws RemoteException
 * @author VeriSign Inc.
 */
public class SamplePolicyServiceClient {

	/**
	 * make the default construct private so we can make the class singleton
	 */
	private SamplePolicyServiceClient() {		
	}
	/**
	 * oids reference
	 */
	public PolicyServiceStub.OID [] oids;
	/**
	 * enrollmentPolicies from policyService
	 */
	public PolicyServiceStub.CertificateEnrollmentPolicy [] enrollmentPolices;
	/**
	 * response from policyService
	 */
	public PolicyServiceStub.GetPoliciesResponse getPoliciesResponse;
	/**
	 * This function returns the class that contains the enrollment policy from policy service
	 * @return SamplePolicyServiceClient
	 * @throws IOException 
	 * @throws ADBException 
	 */
	public static SamplePolicyServiceClient getInstance() throws ADBException, IOException{
		if(samplePolicyServiceClient == null) {
			samplePolicyServiceClient = new SamplePolicyServiceClient();
			samplePolicyServiceClient.getPoliciesResponse = samplePolicyServiceClient.requestEnrollmentPolicy();
			samplePolicyServiceClient.oids = samplePolicyServiceClient.getPoliciesResponse.getOIDs().getOID();
			samplePolicyServiceClient.enrollmentPolices = samplePolicyServiceClient.getPoliciesResponse.getResponse().getPolicies().getPolicy();
		}
		return samplePolicyServiceClient;
	}
	/**
	 * 
	 * singleton instance of this class 
	 */
    private static SamplePolicyServiceClient samplePolicyServiceClient;
    /**
     * This function demonstrate how to get a enrollment policy from EnrollmentPolicyService
     * @return
     * @throws IOException 
     * @throws ADBException 
     */
	private  PolicyServiceStub.GetPoliciesResponse requestEnrollmentPolicy() throws ADBException, IOException{		
				
		System.out.println("SamplePolicyServiceClient: Getting Enrollment Policy using VeriSign's PKI Web Service");	

		System.out.println("SamplePolicyServiceClient: Prepare Request");
		
		//Step 1: construct GetPolicies object that contains the information for policy request to PKI Web Service
		PolicyServiceStub.GetPolicies getPolicies = new GetPolicies();		

		
		//Step 2: setup API version
		PolicyServiceStub.VersionType versionType = new VersionType();
		versionType.setVersionType(SampleParameters.policyAPIVersion);
		getPolicies.setVersion(versionType);

		
		//Step 3: prepare for SSL mutual authentication between the sample application PKI Web service
		Utils.setupSSLClientAuth(SampleParameters.raKeyStore, SampleParameters.raKeyStorePasswd, SampleParameters.caStore, SampleParameters.caStorePasswd);

		//Step 4: create PolicyServiceStub 
		PolicyServiceStub requestPoliciesServiceStub = new PolicyServiceStub(SampleParameters.policyServiceURL);
		
		//Step 5: Send the request to PKI web service to get enrollment policies	
		System.out.println("SamplePolicyServiceClient: Sending Request");
		PolicyServiceStub.GetPoliciesResponse getPoliciesResponse = requestPoliciesServiceStub.requestPolicies(getPolicies);
		System.out.println("SamplePolicyServiceClient: Successfully got the response");
		dumpEnrollmentPolicyResponse(SampleParameters.sampleOutputPath+"/"+SampleParameters.samplePolicyResponse, getPoliciesResponse);

		return getPoliciesResponse;
	}	
	/**
	 * This function perform a request to get the enrollment policy and store the response to a file
	 * @param args
	 */
	public static void main(String[] args) {
		
		try {
			SamplePolicyServiceClient samplePolicyServiceClient = SamplePolicyServiceClient.getInstance();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ADBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * This is function search a policy based on policy oid default name.
	 * @param defaultName
	 * @return
	 */
	public PolicyServiceStub.CertificateEnrollmentPolicy [] getEnrollmentPoliciesByDefaultName(String defaultName) {
		ArrayList <PolicyServiceStub.CertificateEnrollmentPolicy>  enrollmentPolicyArray = new ArrayList <PolicyServiceStub.CertificateEnrollmentPolicy>();
		//find oid that match the prefix
		for (PolicyServiceStub.OID oid : oids){
			if(oid.getDefaultName() != null && !oid.getDefaultName().equals("") && oid.getDefaultName().equals(defaultName)) {
				//find the policy with oid
				for(PolicyServiceStub.CertificateEnrollmentPolicy policy : enrollmentPolices ){
					if(policy.getPolicyOIDReference() == oid.getOIDReferenceID()){
						 enrollmentPolicyArray.add(policy);
						 break;
					}
				}
			}
		}
		PolicyServiceStub.CertificateEnrollmentPolicy [] enrollmentPolicis = new PolicyServiceStub.CertificateEnrollmentPolicy [enrollmentPolicyArray.size()];
		return enrollmentPolicyArray.toArray(enrollmentPolicis);
	}	
	/**
	 * This is a help function to get an OID by refereceID
	 * @param oids
	 * @param referenceID
	 * @return PoliciesServiceStub.OID oid
	 * @throws Exception
	 */
	public PolicyServiceStub.OID getOIDByReferenceID( int referenceID) throws Exception{
		for(PolicyServiceStub.OID oid : oids) {
			if (oid.getOIDReferenceID() == referenceID) return oid;
		} 
		throw new Exception("OID not found"); 
	}	
	/**
	 * This function dump the policyResponse to a file.
	 * @param fileName
	 * @param policyResponse
	 * @throws ADBException
	 * @throws IOException
	 */
	public static void dumpEnrollmentPolicyResponse(String fileName,PolicyServiceStub.GetPoliciesResponse policyResponse) throws ADBException, IOException{
		OMElement reponseElement = policyResponse.getOMElement(new javax.xml.namespace.QName("http://www.verisign.com/2009/07/certificateIssuingService","GetPoliciesResponse"),OMAbstractFactory.getOMFactory());
		Utils.saveTextToFile(fileName,reponseElement.toString());
	}
}
