CREATE TABLE KeyRecovery(
    WebPin                        VARCHAR2(50)    PRIMARY KEY,
    SubScriberName                NVARCHAR2(255),
    Status                        VARCHAR2(20)    NOT NULL,
    EventTime                     VARCHAR2(100)   NOT NULL,
    Mask                          VARCHAR2(80)    NOT NULL,
    IV                            VARCHAR2(60)    NOT NULL,
    P12Pwd                        VARCHAR2(100)   NULL,
    EPKey                         VARCHAR2(4000)  NOT NULL,
    Cert                          VARCHAR2(4000)  NULL
);

