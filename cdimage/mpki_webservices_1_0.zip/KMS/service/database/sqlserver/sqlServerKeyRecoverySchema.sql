CREATE TABLE dbo.KeyRecovery (
	WebPin         	       varchar (50)  NOT NULL PRIMARY KEY,
	SubScriberName         varchar (255) NULL ,
	Status                 varchar (20)  NOT NULL ,
	EventTime              varchar (100) NOT NULL ,
	Mask                   varchar (80)  NOT NULL ,
	IV                     varchar (60)  NOT NULL ,
	P12Pwd                 varchar (100) NULL ,
	EPKey                  text          NOT NULL ,
	Cert                   text          NULL ,
)
GO

CREATE INDEX KeyRecoveryWebPinIdx ON dbo.KeyRecovery(WebPin)
GO

