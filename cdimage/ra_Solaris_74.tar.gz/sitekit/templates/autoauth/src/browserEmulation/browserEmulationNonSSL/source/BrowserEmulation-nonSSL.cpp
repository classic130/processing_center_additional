/*
 * $Revision: 1.3.74.1 $
 * $Header: /cvsroot/mpki/vsaakm/browserEmulation/browserEmulationNonSSL/source/BrowserEmulation-nonSSL.cpp,v 1.3.74.1 2014/06/03 06:45:58 cnalkara Exp $
 */

/*--------------------------------------------------------------------\
| Copyright (C) Symantec Corporation created 2014. All rights reserved.|
| This is an unpublished work protected as such under copyright law.   |
| This work contains proprietary, confidential, and trade secret       |
| information of Symantec Corporation. Use, disclosure or reproduction |
| without the expressed written authorization of Symantec Corporation  |
| is prohibited.                                                       |
\---------------------------------------------------------------------*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#ifndef WIN32
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <signal.h>
#include <unistd.h>
#include <ctype.h>
#define SOCK_ERROR_CODE (-1)
extern int errno;
#else
#include <windows.h>
#define SOCK_ERROR_CODE (SOCKET_ERROR)
#endif

#define HTTP_PORT 80
#define HTTPS_PORT 443
#define LOCAL_PORT 9999
#define BUF_INCREMENT 1024

static void StripMimeHeaders(unsigned char **buffer, unsigned int *len) ;
int ConnectSock(int *sock, const char *hostname, unsigned int timeout,
                unsigned int nProxyPort);
int WriteSock(int sock, const char *request_method, const char* cginame, 
              const unsigned char* pbBuf, const unsigned int len);
int ReadSock(int sock, unsigned char** buffer, unsigned int *len);

////////////////////////////////////////////////////////////////////////
int main(int argc, char *argv[])
////////////////////////////////////////////////////////////////////////
{
  char *query = NULL, *serverName = NULL, *serverPortString = NULL;
  unsigned int serverPort;
  
  int status=0, sock = 0, i=0;
  unsigned char* buffer = NULL;
  time_t timer = 120;
  unsigned int   buflen;
  FILE           *fp = NULL;
  
  char s[10000];
  char name[100];
  char value[10000];
  
  do{
    fp = fopen("./browserEmulation.cfg", "r");
    if (fp == NULL){
      printf("unable to open ./browserEmulation.cfg\n");
      status = -1;
      break;
    }
    
    while (fgets(s, sizeof(s), fp))
    {
      if (s[0] != '#') /* skip comments */
      {
        name[0] = value[0] = '\0';
        sscanf(s, "%s %s", name, value);
        if (!strcmp("host", name))  serverName = strdup(value);
        if (!strcmp("port", name))  serverPortString = strdup(value);
        if (!strcmp("query", name))  query = strdup(value);
      }
    }
    fclose(fp);
    fp = NULL;
    
    if ( query == NULL || serverName == NULL || serverPortString == NULL ) {
      printf("query or serverName or serverPortString is NULL.\n");
      status = -1;
      break;
    }
    
    serverPort = atoi(serverPortString);
    if ( serverPort == 0 ) {
      printf("Server port is not a valid number.\n");
      status = -1;
      break;
    }
    
    status = ConnectSock(&sock, serverName, timer, serverPort);
    status = WriteSock(sock, "POST", "/cgi-bin/sophialite.exe", (const unsigned char *)query, strlen(query)+1);
    if (status) {
      return -1;
    }
    status = ReadSock(sock, &buffer, &buflen);
    if (status) {
      break;
    } else {
      printf("\n\n******************\n\nresult length = %d\n result = %s\n", buflen, buffer);
    }
  } while (0);
  
  if ( sock != 0 ) closesocket(sock);
  if ( fp != NULL ) fclose(fp);
  if ( serverName != NULL ) free(serverName);
  if ( serverPortString != NULL ) free(serverPortString);
  if ( query != NULL ) free(query);
  if ( buffer != NULL ) free(buffer);
  
  
  return status;
}

static void dump(const char *msg, const unsigned char *buf, int len)
{
  int i;
  time_t clock = time(NULL);
  
  fprintf(stdout, "%s %s: ", asctime(localtime(&clock)), msg);
  
  for (i=0; i<len; i++)
  {
    if (isprint(buf[i]) && isascii(buf[i]))
      fprintf(stdout, "%c", buf[i]);
    else
      fprintf(stdout, "[x%02X]", buf[i]);
  }
  fprintf(stdout, "\n");
}

void timeout_handler(int sig)
{
  return;
}

int ConnectSock(int *sock, const char *hostname, unsigned int timeout,
                unsigned int nProxyPort)
{
  struct hostent *hp;
  struct sockaddr_in dest;
  int status =0;
  
  do {
#ifdef WIN32
    WORD wVersionRequired ;
    WSADATA wsaData ;
    wVersionRequired = MAKEWORD(2,0) ;
    if( WSAStartup(wVersionRequired, &wsaData) != 0 )
    {
      status = -1 ;
      break ;
    }
#endif
    if ( !(hp = gethostbyname(hostname)) ) {
		    status = -1 ;
        break;
    }
    *sock = socket(AF_INET, SOCK_STREAM, 0);
    if (*sock<0) {
      status = -1;
      break;
    }
#ifdef WIN32
    {
      unsigned nTimeout = timeout * 1000; // 120 seconds
      setsockopt(*sock, SOL_SOCKET, SO_RCVTIMEO, (char *)&nTimeout,
        sizeof(int));
      setsockopt(*sock, SOL_SOCKET, SO_SNDTIMEO, (char *)&nTimeout,
        sizeof(int));
      
    }
#endif
    
    dest.sin_family = AF_INET;
    dest.sin_port = htons(nProxyPort) ;
    memcpy(&dest.sin_addr, hp->h_addr, hp->h_length);
    
#ifndef WIN32
    signal(SIGALRM, timeout_handler);
    alarm(timeout);
#endif
    if (connect(*sock, (struct sockaddr *)&dest, sizeof(dest)) <0) {
      status = -1;
      break;
    }
#ifdef WIN32__
    status = 0 ;
    if( ioctlsocket(*sock, FIONBIO, (unsigned long *)&status) != 0 )
    {
      status = WSAGetLastError() ;
      break ;
    }
#endif
  } while (0);
  

  fprintf(stdout, "Socket: host %s, port %d, status %d\n", hostname, nProxyPort, status);
  return status ;
}


int WriteSock(int sock, const char *request_method, const char* cginame, 
              const unsigned char* pbBuf, const unsigned int len)
{
  unsigned int length=0, bufferLen=0, status=0;
  char * buffer = NULL, slen[10]="";
  unsigned int nbHeader ;
  
  do {
    bufferLen += strlen(request_method)+1;
    bufferLen += strlen(cginame);
    bufferLen += strlen(" HTTP/1.0") + 2;
    bufferLen += strlen("User-Agent: Browser Emulation\r\n") + 2;
    
    bufferLen += strlen("Content-Type: application/x-www-form-urlencoded\r\n") + 2;
    sprintf(slen, "%d", len);
    bufferLen += strlen("Content-Length: ") + strlen(slen) +4;
    bufferLen += len + 2;
    
    buffer = (char*) malloc(bufferLen+1);
    if (!buffer) {
      status = -1;
      fprintf(stdout, "Socket Error: cannot allocate %d bytes\n", bufferLen+1);
      break;
    }
    
    strcpy(buffer, request_method);
    strcat(buffer, " ");
    strcat(buffer, cginame);
    strcat(buffer, " HTTP/1.0\r\n");
    strcat(buffer, "User-Agent: Browser Emulation\r\n");
    strcat(buffer, "Content-Type: application/x-www-form-urlencoded\r\n");
    strcat(buffer, "Content-Length: ");
    strcat(buffer, slen);
    strcat(buffer, "\r\n\r\n");
    nbHeader = strlen(buffer) ;
    memcpy(buffer + nbHeader, pbBuf, len) ;
    
    length = send(sock, buffer, nbHeader + len, 0 );
    dump("Socket send", (unsigned char *)buffer, nbHeader + len);
    if (length != (nbHeader + len)) {
      status = -2;
      fprintf(stdout, "Socket Error: send failed, error = %d\n",
#ifdef WIN32
        WSAGetLastError());
#else
      errno);
#endif
      break;
    }
  } while (0);
  if (buffer)
    free(buffer);
  return 0;
}

int ReadSock(int sock, unsigned char** buffer, unsigned int *len)
{
  int lastIncr ;
  unsigned char *tmpBuf = (unsigned char *)malloc(BUF_INCREMENT) ;
  *len = 0 ;
  *buffer = NULL ;
  time_t clock;
  
  while( (lastIncr = recv(sock, (char *)tmpBuf, BUF_INCREMENT, 0)) > 0 )
  {
    *buffer = (unsigned char *)realloc(*buffer, (*len) + lastIncr) ;
    if( *buffer == NULL ) return -1 ;
    memcpy(*buffer + *len, tmpBuf, lastIncr) ;
    *len += lastIncr  ;
  }
  free(tmpBuf) ;
  if( lastIncr == SOCK_ERROR_CODE )
  {
      clock = time(NULL);
      fprintf(stdout, "%s Socket Error: read failed, error = %d\n",
        asctime(localtime(&clock)),
#ifdef WIN32
        WSAGetLastError());
#else
		    errno);
#endif
    return -1 ;
  }
  dump("Socket recv", *buffer, *len);

  StripMimeHeaders(buffer, len) ;
  return 0;
}

/*
* This function is not generic right now, but it should be made as generic as possible
* to get rid of any possible mime headers the server may send
*/
static void StripMimeHeaders(unsigned char **buffer, unsigned int *len)
{
  unsigned int i ;
  static unsigned char pattern[] = { 0x0D, 0x0A, 0x0D, 0x0A } ;
  
  if( *len < sizeof(pattern) ) return ;
  
  for( i = 0 ; i < (*len  - sizeof(pattern)); i++ )
    if( !memcmp(pattern, *buffer + i, sizeof(pattern)) )
    {
      i += sizeof(pattern) ;
      break ;
    }
    if( i != *len )
    {
      *len -= i ;
      memmove(*buffer, *buffer + i, *len) ;
    }
}
