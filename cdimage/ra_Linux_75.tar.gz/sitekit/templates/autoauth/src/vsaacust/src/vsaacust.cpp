
/*--------------------------------------------------------------------\
| Copyright (C) Symantec Corporation created 2014. All rights reserved.|
| This is an unpublished work protected as such under copyright law.   |
| This work contains proprietary, confidential, and trade secret       |
| information of Symantec Corporation. Use, disclosure or reproduction |
| without the expressed written authorization of Symantec Corporation  |
| is prohibited.                                                       |
\---------------------------------------------------------------------*/

/*--------------------------------------------------------------------\
 This is a data access layer to process an Automated Authentication 
 request with LDAP server. The module supports the following APIs:

 * Initialize()
   This function reads configuration file and initialize proper 
   environment for LDAP server access.

 * VerifyUser()
   The verify operation is invoked to verify (or authenticate) the 
   applicant after the applicant submits the enrollment form. 

 * RegisterUser()
   This function updates the directory with the issued certificate 
   for the request and a time stamp.

 * ErrorUser()
   This function appends the input name-value pairs to a LOG_FILE with
   a time stamp.

 * Finalize()
   This function releases all resource allocated in this module before
   the module is un-loaded.

\--------------------------------------------------------------------*/

/* Standard header files */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

/* Symantec AA header files */

#include "vsaaapi.h"
#include "localvsverify.h"
#include "vsaautil.h"

/* Function implementation */

/* 
    Initialize the module. It can read configuration data specific
    to this module from file pszServiceCfgFileName, and set log 
    file as the given one logFilePtr etc.
*/

#define CUST_PREPICKUP_PROCESS              ("PRE_PICKUP_PROCESS")
#define CUST_PREREVOKE_PROCESS              ("PRE_REVOKE_PROCESS")
#define CUST_PRERENEWAL_PROCESS             ("PRE_RENEWAL_PROCESS")

static VSAA_STATUS DoVerifyUser(const VSAA_NAME userInput[], VSAA_NAME       **augmentedData);
static VSAA_STATUS DoPrePickupProcess(const VSAA_NAME userInput[], VSAA_NAME       **augmentedData);
static VSAA_STATUS DoPreRevokeProcess(const VSAA_NAME userInput[], VSAA_NAME       **augmentedData);
static VSAA_STATUS DoPreRenewProcess(const VSAA_NAME userInput[], VSAA_NAME       **augmentedData);

static VSAA_BOOL             nPrePickupProcess;
static VSAA_BOOL             nPreRevokeProcess;
static VSAA_BOOL             nPreRenewalProcess;

#ifdef __cplusplus
extern "C" {
#endif

VS_STATUS (*VS_Log)(VS_LOG_TYPE level, int line, const char *filename, const char *trans_id, const char *format, ...) = NULL;

VSAA_STATUS 
VSAA_LINK Initialize(
    const VSAA_NAME commonVSAAConfig[],
    const char*     pszServiceCfgFileName, 
    VS_STATUS  (*VSAA_Log)(VS_LOG_TYPE level, int line, const char *filename, const char *trans_id, const char *format, ...)
    )
{
  VS_Log = VSAA_Log;
  nPrePickupProcess =  VSAA_FALSE;
  nPreRevokeProcess =  VSAA_FALSE;
  nPreRenewalProcess = VSAA_FALSE;
  
  return VSAA_SUCCESS;
}
#ifdef __cplusplus
}
#endif

/* 
    Release resources allocated for global data in this module.
*/

VSAA_STATUS 
VSAA_LINK Finalize(void)
{
    return VSAA_SUCCESS;
}

/* 
   Verify whether the given request should be approved to issue a certificate
   The parameter augmentedData will store extra information other than user 
   input from your module to issued certificate 
*/

VSAA_STATUS 
VSAA_LINK VerifyUser(
    const VSAA_NAME userInput[], 
    VSAA_NAME       **augmentedData)
{
  VSAA_STATUS  status = VSAA_SUCCESS;
  const char *operation; 
  const char *t_xid;
  
  operation = FindName(VSAA_OPERATION, strlen(VSAA_OPERATION), userInput);
  t_xid = FindName (VSAA_XID, strlen (VSAA_XID), userInput);
  
  do {
    if ( operation == NULL || strlen(operation) == 0 ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, t_xid, (char *)"Operation is missing in the name value list.");
      status =  VSAA_INTERNAL_ERROR;
    }
    
    if (!strcmp(operation, VSAA_AA_PICKUP) || !strcmp(operation, "PickupPKCS12") ) {
      // doing pre-pickup process
      if ( nPrePickupProcess ) {
        status = DoPrePickupProcess(userInput, augmentedData);
      }
    } else if (!strcmp(operation, VSAA_AA_REVOKE) ) {
      // doing pre-revoke process
      if ( nPreRevokeProcess ) {
        status = DoPreRevokeProcess(userInput, augmentedData);
      }
    } else if (!strcmp(operation, VSAA_AA_RENEWAL) ) {
      // doing pre-renew process
      if ( nPreRenewalProcess ) {
        status = DoPreRenewProcess(userInput, augmentedData);
      }
    } else {
      // always does the verify user for any operation other than pickup, revoke, renewal
      status = DoVerifyUser(userInput, augmentedData);
    }
  } while (0);
  
  return status;
}

/*
    Register user information and issued certificate in the storage
    database used in this module.
*/

VSAA_STATUS 
VSAA_LINK RegisterUser(const VSAA_NAME userInput[])
{
    return VSAA_SUCCESS;
}

/* 
    Record this user in the log file to error debugging.
*/
 
VSAA_STATUS 
VSAA_LINK ErrorUser(const VSAA_NAME userInput[])
{
    return VSAA_SUCCESS;
}

VSAA_STATUS 
VSAA_LINK validateAuthenticationDataSource()
{
    return VSAA_SUCCESS;
}

VSAA_STATUS 
VSAA_LINK validateRegistrationDataSource()
{
    return VSAA_SUCCESS;
}

VSAA_STATUS 
VSAA_LINK validateRecoverDataSource()
{
    return VSAA_SUCCESS;
}

VSAA_STATUS  DoVerifyUser(const VSAA_NAME userInput[],     VSAA_NAME    **augmentedData)
{
    return VSAA_SUCCESS;
}

static VSAA_STATUS DoPrePickupProcess(const VSAA_NAME userInput[], VSAA_NAME  **augmentedData)
{
  VSAA_STATUS  status = VSAA_SUCCESS;

  // When you customize this code, you can replace the DoVerifyUser with another function
  status = DoVerifyUser(userInput, augmentedData);

  return status;
}

static VSAA_STATUS DoPreRevokeProcess(const VSAA_NAME userInput[], VSAA_NAME  **augmentedData)
{
  VSAA_STATUS  status = VSAA_SUCCESS;

  // When you customize this code, you can replace the DoVerifyUser with another function
  status = DoVerifyUser(userInput, augmentedData);

  return status;
}

static VSAA_STATUS DoPreRenewProcess(const VSAA_NAME userInput[], VSAA_NAME   **augmentedData)
{
  VSAA_STATUS  status = VSAA_SUCCESS;

  // When you customize this code, you can replace the DoVerifyUser with another function
  status = DoVerifyUser(userInput, augmentedData);

  return status;
}

