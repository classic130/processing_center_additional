/*
 * $Revision: 1.2.206.1 $
 * $Header: /cvsroot/mpki/vsaakm/vsaasrv/include/vsobject.h,v 1.2.206.1 2014/06/03 06:46:10 cnalkara Exp $
 */

/*--------------------------------------------------------------------\
| Copyright (C) Symantec Corporation created 2014. All rights reserved.|
| This is an unpublished work protected as such under copyright law.   |
| This work contains proprietary, confidential, and trade secret       |
| information of Symantec Corporation. Use, disclosure or reproduction |
| without the expressed written authorization of Symantec Corporation  |
| is prohibited.                                                       |
\---------------------------------------------------------------------*/

#ifndef _VSOBJECT_H_
#define _VSOBJECT_H_


/*
 * This class is part of the ECAS Messaging API.
 * 
 * VSObject is the base of all ECAS objects. Right now it does
 * nothing, but serves as a placeholder where we can put
 * global behavior later.
 *
 * REV HISTORY
 * Date          Author     Desc
 * ----          ------     ----
 * Mar 14, 1997   rick       Created.
 */


class VSObject
{
public:
          VSObject (void);
  virtual ~VSObject (void);
};


#endif /* _VSOBJECT_H_ */
  
