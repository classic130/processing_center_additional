/*
 * $Revision: 1.2.152.2.16.1 $
 * $Header: /cvsroot/mpki/vsaakm/vsaautil/include/vsaabase64.h,v 1.2.152.2.16.1 2014/06/03 06:46:10 cnalkara Exp $
 */

/*--------------------------------------------------------------------\
| Copyright (C) Symantec Corporation created 2014. All rights reserved.|
| This is an unpublished work protected as such under copyright law.   |
| This work contains proprietary, confidential, and trade secret       |
| information of Symantec Corporation. Use, disclosure or reproduction |
| without the expressed written authorization of Symantec Corporation  |
| is prohibited.                                                       |
\---------------------------------------------------------------------*/


#ifndef _ENCODE_H_
#define _ENCODE_H_

static char *_encode_H = (char *) "$Id: vsaabase64.h,v 1.2.152.2.16.1 2014/06/03 06:46:10 cnalkara Exp $";

#ifdef  __cplusplus
extern "C" {
#endif

  /* Stolen from CVS/common/include/convfield.h */

#if  defined(CRYPTOC_ITEM_TYPEDEF_DONE) || defined(_ITEM_)
#else
#ifndef CRYPTOC_ITEM_TYPEDEF_DONE
#define CRYPTOC_ITEM_TYPEDEF_DONE 1
#endif
#ifndef  _ITEM_
#define _ITEM_ 1
#endif
  typedef struct {
    unsigned char *data;
    unsigned int len;
  } ITEM;
#endif

/* Base64Alloc 
 *	Encodes binary data into base64 format.
 */
int Base64Alloc (
    ITEM *,
    ITEM
    );

/* UnBase64Alloc 
 *	Decodes data in base64 format into binary format.
 */
int UnBase64Alloc (
    ITEM *,
    ITEM
    );

/* Bin2HascAlloc 
 *	Converts binary data to half ASCII characters.
 */
int Bin2HascAlloc (
    char **hasc,
    ITEM *bin
    );

/* Hasc2BinAlloc 
 *	Converts half ASCII characters to binary data.
 */
int Hasc2BinAlloc (
    ITEM *bin,
    char *hasc
    );

/* UudecodeAlloc 
 *	Takes uuencoded data and returns decoded data.
 */
int UudecodeAlloc ( 
    ITEM *uudecodedBuffer,
    ITEM uuencodedBuffer
    );

#ifdef  __cplusplus
}
#endif

#endif	/* _ENCODE_H_ */

