-- $Revision: 1.4 $
-- $Header: /cvsroot/mpki/vsaakm/sample/odbc/oracle/create_keymanager_schema.sql,v 1.4 2006/08/22 22:42:39 tlee Exp $
--

-- Table to hold info about each key
CREATE TABLE KeyRecovery(
    WebPin                        VARCHAR2(50)    PRIMARY KEY,
    SubScriberName                VARCHAR2(255),
    Status                        VARCHAR2(20)    NOT NULL,
    EventTime                     VARCHAR2(100)   NOT NULL,
    Mask                          VARCHAR2(80)    NOT NULL,
    IV                            VARCHAR2(60)    NOT NULL,
    P12Pwd                        VARCHAR2(100)   NULL,
    EPKey                         VARCHAR2(2000)  NOT NULL,
    Cert                          VARCHAR2(4000)  NULL
);
