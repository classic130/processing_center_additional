
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

#include "vsutil.h"
#include "vsaautil.h"
#include "vsaaapi.h"
#include "vsaaldap.h"

static FILE*        gLogFilePtr = NULL;
static unsigned int gLogLevel = VSAA_LOG_LEVEL_SIMPLE;
static VSAA_NAME    anInput[200];
static VSAA_NAME    *augData = NULL;
static int          anInputCount;
    
void        PrintUsage(void);
void        LoadInputData(const char *fileName);
void        CleanUpInput(void);
char*       URLEncodeAlloc(const unsigned char* buffer, int n);
int         URLDecodeAlloc(const char *pszBuf, unsigned char **pbOutputBuf, int *pnOutputBufLen);
VSAA_STATUS Test_Initialize(const char* cfgFileName);    
VS_STATUS  (*VS_Log)(VS_LOG_TYPE level, int line, const char *filename, const char *trans_id,	char *format, ...) = NULL;

int main(int argc, char** argv)
{    
    VSAA_STATUS status = VSAA_SUCCESS;
	char        *cfgFileName = (char *) "vsaasrv.cfg";
    int         inputFileIndex = 1;
    int         doVerify = VSAA_TRUE;

    if(argc == 1) {
        PrintUsage();
        exit(1);
    } else {
        inputFileIndex = 1;
        if(!strcmp("-c", argv[1])) {
            if(argc > 3) {
                cfgFileName = argv[2];
                inputFileIndex = 3;
            } else {
                PrintUsage();
                exit(1);
            }
        } else if(!strcmp("-nov", argv[1])) {
            doVerify = VSAA_FALSE;
            inputFileIndex = 2;
            if(!strcmp("-c", argv[2])) {
                if(argc > 4) {
                    cfgFileName = argv[3];
                    inputFileIndex = 4;
                } else {
                    PrintUsage();
                    exit(1);
                }        
            }
        }
    }
    
    gLogFilePtr = fopen("vsaaldap_test.log", "w");
    VS_SetLogFile(gLogFilePtr);

    VS_Log = VSAA_Log;

    status = Test_Initialize(cfgFileName);
    if(status != VSAA_SUCCESS) {
        fprintf(stderr, "Initialization test failed\n");
        if(gLogFilePtr) fclose(gLogFilePtr);
        exit(1);
    } else {
        Finalize();
    }
    
    status = Initialize(NULL, cfgFileName, VS_Log);
    
    if(status == VSAA_SUCCESS) {
        for(int i = inputFileIndex; i<argc; i++) { 
            LoadInputData(argv[i]); 

            /* test VerifyUser() */ 
            
            Dump(gLogFilePtr, "Input Data", anInput);
            
            if(doVerify) {
                status = VerifyUser(anInput, &augData);
                Dump(gLogFilePtr, "Augmented Data", augData);
                if (augData) Release(&augData);
                VS_Log(VS_LOG_INFO, __LINE__, __FILE__, NULL, (char *) "Result: Input data file=%s, VerifyUser() status=0x%x\n", argv[i], status);
            }
                
            /* test RegisterUser() */

            if(status == VSAA_SUCCESS) {
                if (VSAAUTIL_FindUserInputValue(VSAA_ORIG_OP, strlen(VSAA_ORIG_OP), anInput))                    
                {
                    status = RegisterUser(anInput);
                    VS_Log(VS_LOG_INFO, __LINE__, __FILE__, NULL, (char *) "Result: Input data file=%s, RegisterUser() status=0x%x\n", argv[i], status);
                }                   
            }

            CleanUpInput();
        }
    }
    
    if(gLogFilePtr) fclose(gLogFilePtr);

    Finalize();

    return status;
}

/*
 Test cases:
   Case 1: empty line
   Case 2: only one word in a line
   Case 3: multiple space in the beginning, middle and end of lines
   Case 4: non-ascii characters in a line
   Case 5: long lines with more than MAX_LINE characters
   Case 6: Underscore character in name and value string
   Case 7: space in value string
 Goal: 
   1) non-crash or coredump
   2) errors are caught
   3) no memory leak
 */

VSAA_STATUS Test_Initialize(const char* cfgFileName)
{
    char* tmpCfgFileName = (char *) "tmpldap.cfg";
    FILE* fp = fopen(tmpCfgFileName, "w");

    if(fp) {
        /* make up test case configuration data */

        fprintf(fp, "#Test LDAP configuration file\n");
        fprintf(fp, "    \n");
        fprintf(fp, "NameOnly\n");
        fprintf(fp, "Nonalpha_Name RealValue\n");
        fprintf(fp, "    HeadingSpace    MiddleSpace    \n");
        fprintf(fp, "ThreeFields FirstValue SecondValue\n");
        fprintf(fp, "LongLine 123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890\n");
        fprintf(fp, "NonAsciiChars ��.�E\n");
       
        /* append given configuration file data */

        FILE* fp2 = fopen(cfgFileName, "r");
        if(fp2) {
            char buf[1024];
            while(fgets(buf, 1024, fp2))
                fprintf(fp, "%s", buf);
            fclose(fp2);
        }

        fclose(fp);
    } else
        return VSAA_LDAP_ERR_CFG;

    VSAA_STATUS status = Initialize(NULL, tmpCfgFileName, VS_Log);

    remove(tmpCfgFileName);

    return status;
}

void PrintUsage(void)
{
    fprintf(stderr,"Usage: vsaaldap_test [-nov] [-c <vsaasrv.cfg>] <inputFileName> ...\n");
}

void LoadInputData(const char *fileName)
{
    FILE *fp = fopen(fileName, "r");
    char s[2000];
    int i;
    unsigned char *pszValue ;
    int len ;
    
    if (fp == NULL)
    {
        fprintf(stderr, "Cannot open file %s\n", fileName);
        exit(1);
    }
    
    memset(s, 0, sizeof(s));
    anInputCount = 0;
    while (fgets(s, sizeof(s), fp))
    {
        if (s[strlen(s) - 1] == '\n')
            s[strlen(s) - 1] = '\0';
        for (i=0; s[i] && (s[i] != ' '); i++)
            ;
        s[i] = '\0';
        if (s[0] == '\0')
            continue;
        anInput[anInputCount].pszName = strdup(s);
        URLDecodeAlloc(&s[i+1], &pszValue, &len) ;
        anInput[anInputCount].pszValue = (char *)pszValue ;
        anInput[anInputCount].pszValue[len] = '\0' ;
        anInputCount++;
        memset(s, 0, sizeof(s));
    }
    
    fclose(fp);
}

void CleanUpInput(void)
{
    int i;
    
    for (i=0; i<anInputCount; i++)
    {
        if (anInput[i].pszName)
        {
            free(anInput[i].pszName);
            anInput[i].pszName = NULL;
        }
        if (anInput[i].pszValue)
        {
            free(anInput[i].pszValue);
            anInput[i].pszValue = NULL;
        }
    }
}

char* URLEncodeAlloc(const unsigned char* buffer, int n)
{
    int           length = 0;
    const int	BUFSIZE = 64;
    int           size = BUFSIZE;
    
    char*         escaped;
    char*         hex = (char *) "0123456789ABCDEF";
    const unsigned char *unescaped;
    
    unescaped = buffer;
    escaped   = (char *)calloc(size+1,sizeof(char));
    
    if (!buffer || n==0) return (char *) "";
    
    *escaped = NULL;
    
    while(buffer - unescaped < n) {
        
        if(length+3 > size){
            size+=BUFSIZE;
            escaped = (char *)realloc(escaped, size+1);
        }
        
        if(!escaped)
            return NULL;
        
        if ((*buffer >= 'a' && *buffer <= 'z') ||
            (*buffer >= 'A' && *buffer <= 'Z') ||
            (*buffer >= '0' && *buffer <= '9'))
        {
            escaped[length++] = *buffer;
            
        }
        else
        {
            escaped[length++] = '%';
            escaped[length++] = hex[((unsigned char)*buffer) >> 4];
            escaped[length++] = hex[((unsigned char)*buffer) & 15];
        }
        escaped[length] = NULL;
        ++buffer;
    }
    
    return(escaped);
}

int URLDecodeAlloc(const char *pszBuf, unsigned char **pbOutputBuf, int *pnOutputBufLen)
{
    unsigned char *pbOut ;
    int nbytesIn = strlen(pszBuf) + 1;
    char pszTmp[3] ;
    int nTmp ;
    int i, j ;
    
    pbOut = (unsigned char *)malloc(nbytesIn +1) ; // worst case scenario
    
    for( i = 0, j=0 ; i < nbytesIn ; i++, j++ )
    {
        switch(pszBuf[i] )
        {
        case '+' :
            pbOut[j] = ' ' ;
            break ;
        case '%':
            if( pszBuf[i+1] == '%' )
            {
                i++ ;
                pbOut[j] = pszBuf[i] ;
                break ;
            }
            pszTmp[0] = pszBuf[i+1] ;
            pszTmp[1] = pszBuf[i+2] ;
            pszTmp[2] = '\0' ;
            if( sscanf(pszTmp, "%x", &nTmp) != 1 ) return -1 ;
            pbOut[j] = (unsigned char)nTmp ;
            i += 2 ;
            break ;
        default:
            pbOut[j] = pszBuf[i] ;
            break ;
        }
    }
    
    *pbOutputBuf = pbOut ;
    *pnOutputBufLen = j ;

    return i ;
}
