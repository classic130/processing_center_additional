/* $Id */

/*--------------------------------------------------------------------\
| Copyright (C) VeriSign, Inc. created 1998. All rights reserved.     |
| This is an unpublished work protected as such under copyright law.  |  
| This work contains proprietary, confidential, and trade secret      |
| information of VeriSign, Inc.  Use, disclosure or reproduction      |
| without the expressed written authorization of VeriSign, Inc.       |
| is prohibited.                                                      |
\--------------------------------------------------------------------*/

/*--------------------------------------------------------------------\
 This is a data access layer to process an Automated Authentication 
 request with ODBC database. The module supports the following APIs:

 * Initialize()
   This function reads configuration file and initialize proper 
   environment for database access.

 * VerifyUser()
   The verify operation is invoked to verify (or authenticate) the 
   applicant after the applicant submits the enrollment form. 

 * RegisterUser()
   This function updates the directory with the issued certificate 
   for the request and a time stamp.

 * ErrorUser()
   This function appends the input name-value pairs to a LOG_FILE with
   a time stamp.

 * Finalize()
   This function releases all resource allocated in this module before
   the module is un-loaded.

\--------------------------------------------------------------------*/

/* Standard header files */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

#include "vsaaodbcutil.h"
#include "vsaaapi.h"
#include "vsaanls.h"
#include "vsaautil.h"
#include "vsverify.h"
#include "vsutil.h"
#include "vsaaodbc.h"
#include "vskpi.h"
#include "vsaautil_crypto.h"
#include "vssqlclean.h"

#ifndef WIN32

#include <unistd.h>
#include <signal.h>
#include <pthread.h>

#endif

/* version information */

static const char*  _version_ = "@(#)$RCSfile: vsaaodbc.cpp,v $ $Revision: 1.5.2.5 $";

#define TODECRYPT_LINE "# DECRYPT VALUE ON THE FOLLOWING LINE"
#define BUF_MAX_LEN 2048

/* global variables */

static int	            autoAuthDbId;
static int	            autoAuthDbCursor;
static int	            recoverDbId;
static int	            recoverDbCursor;
static char	            dbErrDesc[300];

#ifdef WIN32
static CRITICAL_SECTION dbLock;
#define LOCKDB          EnterCriticalSection(&dbLock);
#define UNLOCKDB        LeaveCriticalSection(&dbLock);
#else
static pthread_mutex_t  dbLock;
#define LOCKDB          pthread_mutex_lock(&dbLock)
#define UNLOCKDB        pthread_mutex_unlock(&dbLock)
#endif

static ODBCCfg       gODBCCfg;

/* local utility functions */

static char gEmailODBCAttr[ODBC_MAX_DATA_LENGTH] = "";
static VSAA_BOOL gIsEmailODBCAttrQueried = VSAA_FALSE;
static VSAA_BOOL gDataSourceUseUTF8 = VSAA_TRUE;
static VSAA_BOOL    gHasEncryptedLine = VSAA_FALSE;

static void  FindEmailColumnName();
static char* ODBC_FindEmailFromCertDN(const VSAA_NAME userInput[]);
static void VSAAODBC_PrintCfgAttrList( const VSAACfgAttrList *attrListPtr);
static void VSAAODBC_PrintCfgNVPairList(const VSAACfgNVPairList *attrListPtr);
static VSAA_STATUS DoVerifyUser(const VSAA_NAME userInput[], VSAA_NAME       **augmentedData);
static VSAA_STATUS DoPrePickupProcess(const VSAA_NAME userInput[], VSAA_NAME       **augmentedData);
static VSAA_STATUS DoPreRevokeProcess(const VSAA_NAME userInput[], VSAA_NAME       **augmentedData);
static VSAA_STATUS DoPreRenewProcess(const VSAA_NAME userInput[], VSAA_NAME       **augmentedData);

#ifdef __cplusplus
extern "C" {
#endif

VS_STATUS  (*VS_Log)(VS_LOG_TYPE level, int line, const char *filename, const char *trans_id,	char *format, ...);

#ifdef __cplusplus
}
#endif

/* trace macro */

#define ODBC_PREPICKUP_PROCESS              ("PRE_PICKUP_PROCESS")
#define ODBC_PREREVOKE_PROCESS              ("PRE_REVOKE_PROCESS")
#define ODBC_PRERENEWAL_PROCESS             ("PRE_RENEWAL_PROCESS")

#define ODBC_TRACE(x) VSTRACE(x);
    
/*******************************************************************/
/*
 * Initialize the module 
 */
/*******************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

VSAA_STATUS 
VSAA_LINK Initialize(
    const VSAA_NAME commonVSAAConfig[],
    const char*     pszServiceCfgFileName, 
    VS_STATUS  (*VSAA_Log)(VS_LOG_TYPE level, int line, const char *filename, const char* trans_id,	char *format, ...)
    )
{
    VSAA_STATUS status = VSAA_SUCCESS;    

    VS_Log = VSAA_Log;

    /* Determine whether UTF8 data is stored in data source from common configuration */
    if(commonVSAAConfig != NULL) {
        const char* pszDataSourceUserUTF8CfgValue = FindName(
            CFG_DB_USE_UTF8, strlen(CFG_DB_USE_UTF8), commonVSAAConfig);
        if(pszDataSourceUserUTF8CfgValue != NULL && !VSAAUTIL_StrCaseCmp(pszDataSourceUserUTF8CfgValue, "no"))
            gDataSourceUseUTF8 = VSAA_FALSE;
    }
           
    /* Initialize the gODBCCfg to take default values */

    ODBC_SetDefaultCfg(&gODBCCfg);
    
    /* 
     * Read configuration data into gODBCCfg. Unrecognized entries will be
     * tolerated as long as all required fields are given and no confliction
     * are found.
    */

    status = ODBC_ReadConfigFile(pszServiceCfgFileName);

    ODBC_TRACE("Inside ODBC module Initialize()");

    if(status != VSAA_SUCCESS)
        return ODBC_LogError(status, "Invalid configuration file");

    status = ODBC_ValidateCfg(&gODBCCfg);
    if(status != VSAA_SUCCESS) {
        ODBC_FreeCfg(&gODBCCfg);
        return ODBC_LogError(status, "Invalid configuration file");
    }

    if(gIsEmailODBCAttrQueried == VSAA_FALSE)
        FindEmailColumnName();
    
    status = ODBC_InitDb();
    if(status == VSAA_SUCCESS) 
#ifdef WIN32
        InitializeCriticalSection(&dbLock);
#else
        pthread_mutex_init(&dbLock, NULL);
#endif
    ODBC_PrintCfg();

    return status;
}
#ifdef __cplusplus
}
#endif

/*******************************************************************/
/*
/* Release resources allocated for global data in this module 
 */
/*******************************************************************/

VSAA_STATUS 
VSAA_LINK Finalize()
{
    ODBC_CleanUpDb();
    
#ifdef WIN32
    DeleteCriticalSection(&dbLock);
#else
    pthread_mutex_destroy(&dbLock);
#endif

    ODBC_FreeCfg(&gODBCCfg);
    
    return VSAA_SUCCESS;
}

VSAA_STATUS 
VerifyUser(
    const VSAA_NAME userInput[], 
    VSAA_NAME       **augmentedData)
{
  VSAA_STATUS  status = VSAA_SUCCESS;
  const char *operation; 
  const char *t_xid;
  
  operation = FindName(VSAA_OPERATION, strlen(VSAA_OPERATION), userInput);
  t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);
  
  do {
    if ( operation == NULL || strlen(operation) == 0 ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, t_xid, (char *)"Operation is missing in the name value list.");
      status =  VSAA_INTERNAL_ERROR;
      break;
    }
    
    if (!strcmp(operation, VSAA_AA_PICKUP) || !strcmp(operation, VSKPI_PICKUP) ) {
      // doing pre-pickup process
      if ( gODBCCfg.nPrePickupProcess ) {
        status = DoPrePickupProcess(userInput, augmentedData);
      }
    } else if (!strcmp(operation, VSAA_AA_REVOKE) ) {
      // doing pre-revoke process
      if ( gODBCCfg.nPreRevokeProcess ) {
        status = DoPreRevokeProcess(userInput, augmentedData);
      }
    } else if (!strcmp(operation, VSAA_AA_RENEWAL) ) {
      // doing pre-renew process
      if ( gODBCCfg.nPreRenewalProcess ) {
        status = DoPreRenewProcess(userInput, augmentedData);
      }
    } else {
      // always does the verify user for any operation other than pickup, revoke, renewal
      status = DoVerifyUser(userInput, augmentedData);
    }
  } while (0);
  
  return status;
}

/*******************************************************************/
/*
 * Store the certificate, the certificate serial number and the name
 * in the database.
 */
/*******************************************************************/

VSAA_STATUS 
RegisterUser(const VSAA_NAME userInput[])
{
	RETCODE     rc = 0;
	VSAA_STATUS status = VSAA_SUCCESS;
    
	const char  *op;
	const char  *certBase64;
	const char  *messageStatus = NULL;
	char        *certStatus = gODBCCfg.certStatusValid;

	char        *pUpdateSQLStatement = NULL;
	char        *pWhereSQLStatement = NULL;
	const char  *t_xid;
		
	ODBC_TRACE("RegisterUser()");
	t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);
        
	do
	{                 
		if (!(op = VSAAUTIL_FindUserInputValue(VSAA_ORIG_OP, strlen(VSAA_ORIG_OP), userInput)))
			break;

		if( !strcmp(op, VSAA_AA_SUBMIT) || /* enrollment */
			!strcmp(op, VSAA_AA_PICKUP) || /* AA pickup  */
			!strcmp(op, "PickupPKCS12") || /* OKM pickup */
			!strcmp(op, VSAA_AA_RENEWAL)   /* renewal    */
          )
		{
            certStatus = gODBCCfg.certStatusValid;

            /* certificate data must be present from user's input */

			if( NULL == (certBase64 = VSAAUTIL_FindUserInputValue(VSAA_CERT_BASE64, strlen(VSAA_CERT_BASE64), userInput)))
			{
				status = VSAA_ERR_CERTIFICATE_NOT_GIVEN;
				break;
			}
 
        
            if(!strcmp(op, VSAA_AA_SUBMIT)) {

                /* construct WHERE SQL portion according to user's input */
                
                status = ODBC_PopulateWhereSQLStatement((char*)ODBC_SQL_UPDATE_WHERE, &pWhereSQLStatement, userInput);
                if(status != VSAA_SUCCESS) {
                    VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, t_xid, (char *) "Failed to construct a valid database query SQL with given configuration.");
                    return status;
                }
  
                status = ODBC_UpdateDatabaseEntry(&pUpdateSQLStatement, userInput, certBase64, certStatus, pWhereSQLStatement, gODBCCfg.updAttrListPtr);
              if ( status != VSAA_SUCCESS ) break;

            } else {
              
              char emailWhereStatement[ODBC_MAX_DATA_LENGTH] = "";
              
              if(gEmailODBCAttr[0] == 0) {
                VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, t_xid, (char *) "Couldn't update without a table column corresponding to %s", KEY_EMAIL);
                status = VSAA_ODBC_ERR_CFG;
                break;
              }
              
              char* email = ODBC_FindEmailFromCertDN(userInput);
              if(!email) {
                status = VSAA_UPDATE_FAILED;
                break;
              }
              
              sprintf(emailWhereStatement, "%s = '%s'", gEmailODBCAttr, email);
              
              status = ODBC_UpdateDatabaseEntry(&pUpdateSQLStatement, userInput, certBase64, certStatus, emailWhereStatement, NULL);
              if ( status != VSAA_SUCCESS ) break;
            }
            
		}
		else if (!strcmp(op, VSAA_AA_REVOKE) )
		{
		    certStatus = gODBCCfg.certStatusRevoked;
	        status = ODBC_RevokeDatabaseEntry(&pUpdateSQLStatement, userInput, certStatus, NULL);
	        if ( status != VSAA_SUCCESS ) {
	          // Dealing with revoke successful, update entry fail case.
	            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "Certificate revoke operation is successful, but entry can not be found in the ODBC database.");
	            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "Possible Reasons:");
	            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "\t1. Certificate has been renewed.");
	            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "\t2. Certificate was not registered in this ODBC database.");
	            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "\t3. Tried to revoke signing certificate in the Key Manager dual key configuration.");
	            status = VSAA_SUCCESS;
	        
	            break;
	        }
		}
		else /* there is no original operation */
		{
			status = VSAA_INTERNAL_ERROR;
			break;
		}
	} while (0);
    
    VSAAUTIL_Free(pWhereSQLStatement);
    VSAAUTIL_Free(pUpdateSQLStatement);
    
    return status;
}

/*******************************************************************/
/*
 * Record this enrollment error in the log file.
 */
/*******************************************************************/

VSAA_STATUS ErrorUser(const VSAA_NAME userInput[])
{
    int i;
    const char *t_xid;
    
    t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);
    VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, t_xid, (char *) "An error occurred with user's input. Decoded message from Backend: ");
    for (i=0; userInput[i].pszName != NULL; i++)
    {
        // Not dumping the original user data
        if ( strcmp(userInput[i].pszName, VSKPI_ORIGINAL_OP) == 0 ) break;
        VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, t_xid, (char*)"    %s=[%s]\n", userInput[i].pszName, userInput[i].pszValue);        
    }

    return VSAA_SUCCESS ;
}

VSAA_STATUS 
KMOperation(const VSAA_NAME subInfo[], const char* operation)
{
  VSAA_STATUS  status = VSAA_INTERNAL_ERROR;

  VS_Log(VS_LOG_INFO, __LINE__, __FILE__, NULL, (char *) "Enter KMOperation to do <%s>", operation);

  if ( strcmp(operation, VSKPI_INSERTNEWROW) == 0 ){
    // insert a new row operation, status is submitted
    status = ODBCKMInsertRow(subInfo);
  } else if ( strcmp(operation, VSKPI_UPDATETOISSUED) == 0 ) {
    // after receiving the cert, update the status to issued
    status = ODBCKMUpdateToIssued(subInfo);
  } else if ( strcmp(operation, VSKPI_UPDATETOPENDING) == 0 ) {
    // after receiving the cert, update the status to issued
    status = ODBCKMUpdateToPending(subInfo);
  } else if ( strcmp(operation, VSKPI_RECOVERKEYANDCERT) == 0 ) {
    // doing the key recovery step
    status = ODBCKMRecoverKeyAndCert(subInfo);
  } else if ( strcmp(operation, VSKPI_RETRIEVEPASSWORD) == 0 ) {
    // doing password retrieval
    status = ODBCKMRetrievePwd(subInfo);
  } else if ( strcmp(operation, VSKPI_UPDATECERTFORPICKUP) == 0 ) {
    // updating the cert and get the common name
    status = ODBCKMUpdateCertForPickup(subInfo);
  } else if ( strcmp(operation, VSKPI_FINDENTRYBYWEBPIN) == 0 ) {
    // looking for entries by webpin
    status = ODBCKMFindEntryByWebPin(subInfo);
  } else if ( strcmp(operation, VSKPI_CHANGE_PICKUP_PASSWORD) == 0 ) {
    // looking for entries by webpin
    status = ODBCKMChangePickupPassword(subInfo);
  } else if ( strcmp(operation, VSKPI_DELETEFAILEDENTRY) == 0 ){
    ODBCKMDeleteFailedEntry(subInfo);
    status = VSAA_SUCCESS;
  }

  return status;
}

VSAA_STATUS 
ODBCKMInsertRow(const VSAA_NAME  subInfo[])
{
  RETCODE      rc = 0;
  VSAA_STATUS  status = VSAA_SUCCESS;
  char         sqlCommand[kDB_SQL_COMMAND_MAX_LENGTH];
  char         *eventTime = NULL;
  char         *fingerPrint = NULL, *subscribername = NULL, *certStatus = NULL;
  char         *mask = NULL, *iv = NULL, *ePriKey = NULL;
  time_t       ltime;

  do {
    
    fingerPrint = (char*) VSAAUTIL_FindUserInputValue(VSAA_FINGER_PRINT, strlen(VSAA_FINGER_PRINT), subInfo);
    if ( fingerPrint == NULL ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "fingerprint is missing from inputList");
      status = VSAA_KM_PARAMETER_MISSING;
      break;
    }

    // KMS main program send in subscribername in UTF-8 format
    subscribername = (char*)VSAAUTIL_FindUserInputValue(VSKPI_COMMONNAME, strlen(VSKPI_COMMONNAME), subInfo);
    if ( subscribername == NULL ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "subscribername is missing from inputList");
      status = VSAA_KM_PARAMETER_MISSING;
      break;
    }

    certStatus = (char*)VSAAUTIL_FindUserInputValue(VSKPI_CERT_STATUS, strlen(VSKPI_CERT_STATUS), subInfo);
    if ( certStatus == NULL ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "certStatus is missing from inputList");
      status = VSAA_KM_PARAMETER_MISSING;
      break;
    }

    mask = (char*)VSAAUTIL_FindUserInputValue(VSKPI_MASK, strlen(VSKPI_MASK), subInfo);
    if ( mask == NULL ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "mask is missing from inputList");
      status = VSAA_KM_PARAMETER_MISSING;
      break;
    }

    iv = (char*)VSAAUTIL_FindUserInputValue(VSKPI_IV, strlen(VSKPI_IV), subInfo);
    if ( iv == NULL ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "iv is missing from inputList");
      status = VSAA_KM_PARAMETER_MISSING;
      break;
    }

    ePriKey = (char*)VSAAUTIL_FindUserInputValue(VSKPI_EPRIKEY, strlen(VSKPI_EPRIKEY), subInfo);
    if ( ePriKey == NULL ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "ePriKey is missing from inputList");
      status = VSAA_KM_PARAMETER_MISSING;
      break;
    }

    time( &ltime );
    eventTime = ctime(&ltime);
    eventTime[strlen(eventTime) - 1] = '\0';
    
    
    sprintf(sqlCommand, "INSERT INTO KeyRecovery (WebPin, SubScriberName, Status, EventTime, Mask, IV, EPKey) \
      VALUES ('%s', ?, '%s', '%s', '%s', '%s', ?)", fingerPrint, certStatus, eventTime, mask, iv);
    
    LOCKDB;    
    rc = ODBCSQLExec(dbErrDesc, recoverDbId, recoverDbCursor, gODBCCfg.recoverDatabase, gODBCCfg.recoverUsername, 
      gODBCCfg.recoverPassword, FT_UPDATE, sqlCommand, COL_VCHAR_LEN(subscribername, strlen(subscribername)), 
      COL_LCHAR_LEN(ePriKey, strlen(ePriKey)), NULL);
    UNLOCKDB; 

    if ( rc != 0 ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "DB operation failed:%s", dbErrDesc);
      status = VSAA_KM_ODBC_ERR_QUERY;
      break;
    }
    
  } while (0);

  return status;

}

VSAA_STATUS 
ODBCKMUpdateToIssued(const VSAA_NAME  subInfo[])
{
  RETCODE      rc = 0;
  VSAA_STATUS  status = VSAA_SUCCESS;
  char         sqlCommand[kDB_SQL_COMMAND_MAX_LENGTH+4000];
  char         *eventTime = NULL;
  char         *fingerPrint = NULL, *certStatus = NULL, *webpin = NULL, *cert = NULL;
  char         *subscribername = NULL;
  time_t       ltime;

  do {
    // retrieve parameters from the input list
    fingerPrint = (char*) VSAAUTIL_FindUserInputValue(VSAA_FINGER_PRINT, strlen(VSAA_FINGER_PRINT), subInfo);
    if ( fingerPrint == NULL ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "fingerprint is missing from inputList");
      status = VSAA_KM_PARAMETER_MISSING;
      break;
    }

    certStatus = (char*)VSAAUTIL_FindUserInputValue(VSKPI_CERT_STATUS, strlen(VSKPI_CERT_STATUS), subInfo);
    if ( certStatus == NULL ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "certstatus is missing from inputList");
      status = VSAA_KM_PARAMETER_MISSING;
      break;
    }

    webpin = (char*)VSAAUTIL_FindUserInputValue(VSKPI_WEBPIN, strlen(VSKPI_WEBPIN), subInfo);
    if ( webpin == NULL ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "webpin is missing from inputList");
      status = VSAA_KM_WEBPIN_MISSING;
      break;
    }

    cert = (char*)VSAAUTIL_FindUserInputValue(VSKPI_CERT_OR_CRL, strlen(VSKPI_CERT_OR_CRL), subInfo);
    if ( cert == NULL ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "cert is missing from inputList");
      status = VSAA_KM_PARAMETER_MISSING;
      break;
    }

    // KMS main program send in subscribername in UTF-8 format
    subscribername = (char*)VSAAUTIL_FindUserInputValue(VSKPI_COMMONNAME, strlen(VSKPI_COMMONNAME), subInfo);
    
    time( &ltime );
    eventTime = ctime(&ltime);
    eventTime[strlen(eventTime) - 1] = '\0';
    
    // build sql command to update the database
    if ( subscribername == NULL ) {
      sprintf(sqlCommand, "UPDATE KeyRecovery SET WebPin = '%s', Status = '%s', EventTime = '%s', \
        Cert = '%s' WHERE WebPin = '%s'", webpin, certStatus, eventTime, cert, fingerPrint);
    } else {
      sprintf(sqlCommand, "UPDATE KeyRecovery SET WebPin = '%s', SubScriberName = ?, Status = '%s', EventTime = '%s', \
        Cert = '%s' WHERE WebPin = '%s'", webpin, certStatus, eventTime, cert, fingerPrint);
    }
    
    LOCKDB;
    if ( subscribername == NULL ) {
      rc = ODBCSQLExec(dbErrDesc, recoverDbId, recoverDbCursor, gODBCCfg.recoverDatabase, gODBCCfg.recoverUsername, 
        gODBCCfg.recoverPassword, FT_UPDATE, sqlCommand, NULL);
    } else {
      rc = ODBCSQLExec(dbErrDesc, recoverDbId, recoverDbCursor, gODBCCfg.recoverDatabase, gODBCCfg.recoverUsername, 
        gODBCCfg.recoverPassword, FT_UPDATE, sqlCommand, COL_VCHAR_LEN(subscribername, strlen(subscribername)), 
        NULL);
    }
    UNLOCKDB; 

    if ( rc != 0 ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "DB operation failed:%s", dbErrDesc);
      status = VSAA_KM_ODBC_ERR_QUERY;
      break;
    }

  } while (0);

  return status;

}

VSAA_STATUS 
ODBCKMChangePickupPassword(const VSAA_NAME  subInfo[])
{
  RETCODE      rc = 0;
  VSAA_STATUS  status = VSAA_SUCCESS;
  char         sqlCommand[kDB_SQL_COMMAND_MAX_LENGTH];
  char         *webpin = NULL, *p12password = NULL;
  

  do {
    webpin = (char*)VSAAUTIL_FindUserInputValue(VSKPI_WEBPIN, strlen(VSKPI_WEBPIN), subInfo);
    if ( webpin == NULL ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "webpin is missing from inputList");
      status = VSAA_KM_WEBPIN_MISSING;
      break;
    }

    p12password = (char*) VSAAUTIL_FindUserInputValue(VSKPI_P12PASSWORD, strlen(VSKPI_P12PASSWORD), subInfo);
    if ( p12password == NULL ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "p12 password is missing from inputList");
      status = VSAA_KM_PARAMETER_MISSING;
      break;
    }

    sprintf(sqlCommand, "UPDATE KeyRecovery SET P12Pwd = '%s' WHERE WebPin = '%s' and ( Status = 'pending' or Status = 'issued' )", p12password, webpin);
    
    LOCKDB;
    rc = ODBCSQLExec(dbErrDesc, recoverDbId, recoverDbCursor, gODBCCfg.recoverDatabase, gODBCCfg.recoverUsername, 
        gODBCCfg.recoverPassword, FT_UPDATE, sqlCommand, NULL);
    UNLOCKDB; 

    if ( rc != 0 ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "DB operation failed:%s", dbErrDesc);
      status = VSAA_KM_ODBC_ERR_QUERY;
      break;
    }

  } while (0);

  return status;

}


VSAA_STATUS 
ODBCKMUpdateToPending(const VSAA_NAME  subInfo[])
{
  RETCODE      rc = 0;
  VSAA_STATUS  status = VSAA_SUCCESS;
  char         sqlCommand[kDB_SQL_COMMAND_MAX_LENGTH];
  char         *eventTime = NULL;
  char         *fingerPrint = NULL, *certStatus = NULL, *webpin = NULL;
  char         *p12password = NULL, *cert = NULL;
  time_t       ltime;
  

  do {
    // retrieve parameters from the input list
    fingerPrint = (char*) VSAAUTIL_FindUserInputValue(VSAA_FINGER_PRINT, strlen(VSAA_FINGER_PRINT), subInfo);
    if ( fingerPrint == NULL ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "fingerprint is missing from inputList");
      status = VSAA_KM_PARAMETER_MISSING;
      break;
    }

    certStatus = (char*) VSAAUTIL_FindUserInputValue(VSKPI_CERT_STATUS, strlen(VSKPI_CERT_STATUS), subInfo);
    if ( certStatus == NULL ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "certstatus is missing from inputList");
      status = VSAA_KM_PARAMETER_MISSING;
      break;
    }

    webpin = (char*) VSAAUTIL_FindUserInputValue(VSKPI_WEBPIN, strlen(VSKPI_WEBPIN), subInfo);
    if ( webpin == NULL ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "webpin is missing from inputList");
      status = VSAA_KM_WEBPIN_MISSING;
      break;
    }

    p12password = (char*) VSAAUTIL_FindUserInputValue(VSKPI_P12PASSWORD, strlen(VSKPI_P12PASSWORD), subInfo);
    if ( p12password == NULL ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "p12 password is missing from inputList");
      status = VSAA_KM_PARAMETER_MISSING;
      break;
    }

    time( &ltime );
    eventTime = ctime(&ltime);
    eventTime[strlen(eventTime) - 1] = '\0';
    
    // build sql command to update the database
    sprintf(sqlCommand, "UPDATE KeyRecovery SET WebPin = '%s', Status = '%s', EventTime = '%s', \
     P12Pwd  = '%s' WHERE WebPin = '%s'", webpin, certStatus, eventTime, p12password, fingerPrint);
    
    LOCKDB;    
    rc = ODBCSQLExec(dbErrDesc, recoverDbId, recoverDbCursor, gODBCCfg.recoverDatabase, gODBCCfg.recoverUsername, 
      gODBCCfg.recoverPassword, FT_UPDATE, sqlCommand, NULL);
    UNLOCKDB; 

    if ( rc != 0 ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "DB operation failed:%s", dbErrDesc);
      status = VSAA_KM_ODBC_ERR_QUERY;
      break;
    }

  } while (0);

  /* free up used memory
  if ( fingerPrint ) 
    free(fingerPrint);
  if ( certStatus ) 
    free(certStatus);
  if ( webpin ) 
    free(webpin);
  if ( p12password )
    free( p12password );
  */
  return status;

}

VSAA_STATUS 
ODBCKMRetrievePwd(const VSAA_NAME  subInfo[])
{
  RETCODE      rc = 0;
  VSAA_STATUS  status = VSAA_SUCCESS;
  char         sqlCommand[kDB_SQL_COMMAND_MAX_LENGTH];
  char         *webpin = NULL;
  char         p12password[kPKCS12_PASSWORD_MAX_LENGTH];
  int          i = 0;
  

  do {
    memset(p12password, 0, kPKCS12_PASSWORD_MAX_LENGTH);

    webpin = (char*) VSAAUTIL_FindUserInputValue(VSKPI_WEBPIN, strlen(VSKPI_WEBPIN), subInfo);
    if ( webpin == NULL ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "webpin is missing from inputList");
      status = VSAA_KM_WEBPIN_MISSING;
      break;
    }

    // build sql command to update the database
    sprintf(sqlCommand, "SELECT P12Pwd FROM KeyRecovery WHERE WebPin = '%s'", webpin);
    
    LOCKDB;    
    rc = ODBCSQLExec(dbErrDesc, recoverDbId, recoverDbCursor, gODBCCfg.recoverDatabase, gODBCCfg.recoverUsername, 
      gODBCCfg.recoverPassword, FT_SELECT, sqlCommand, COL_VCHAR_LEN(p12password, kDB_SQL_COMMAND_MAX_LENGTH), 
      NULL);
    UNLOCKDB; 

    if ( rc != 0 ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "DB operation failed:%s", dbErrDesc);
      status = VSAA_KM_ODBC_ERR_QUERY;
      break;
    }

    for ( i = 0; subInfo[i].pszName != NULL; i++ ){
      if ( strcmp(subInfo[i].pszName, VSKPI_P12PASSWORD) == 0 ){
        if ( p12password == NULL ) {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "p12 password retrieved from recovery data source is empty");
          status = VSAA_KM_PASSWORD_EMPTY;
        } else {
          strcpy(subInfo[i].pszValue, p12password);
        }
        break;
      } 
    }

  } while (0);

  /* free up used memory
  if ( fingerPrint ) 
    free(fingerPrint);
  if ( certStatus ) 
    free(certStatus);
  if ( webpin ) 
    free(webpin);
  if ( p12password )
    free( p12password );
  */
  return status;

}

VSAA_STATUS 
ODBCKMRecoverKeyAndCert(const VSAA_NAME  subInfo[])
{
  RETCODE      rc = 0;
  int          i;
  VSAA_STATUS  status = VSAA_SUCCESS;
  char         sqlCommand[kDB_SQL_COMMAND_MAX_LENGTH];
  char         pcert[kDB_CERTIFICATE_MAX_LENGTH], pmask[kDB_MASK_MAX_LENGTH], piv[kDB_IV_MAX_LENGTH];
  char         peprivkey[kDB_EPRIVKEY_MAX_LENGTH], cname[kDB_COMMONNAME_MAX_LENGTH];
  char         pstatus[kDB_STATUS_MAX_LENGTH];
  char         *webpin = NULL;

  do {
    webpin = (char*)VSAAUTIL_FindUserInputValue(VSKPI_WEBPIN, strlen(VSKPI_WEBPIN), subInfo);
    if ( webpin == NULL ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "webpin is missing from inputList");
      status = VSAA_KM_WEBPIN_MISSING;
      break;
    }

    // Initialize the variable before using it.
    memset(pcert, 0, kDB_CERTIFICATE_MAX_LENGTH);
    memset(pmask, 0, kDB_MASK_MAX_LENGTH);
    memset(piv, 0, kDB_IV_MAX_LENGTH);
    memset(peprivkey, 0, kDB_EPRIVKEY_MAX_LENGTH);
    memset(cname, 0, kDB_COMMONNAME_MAX_LENGTH);
    memset(pstatus, 0, kDB_STATUS_MAX_LENGTH);

    
    // build sql command and do the query
    sprintf(sqlCommand, "SELECT Status, Mask, IV, Cert, EPKey, SubScriberName FROM KeyRecovery WHERE WebPin = '%s'", webpin);

    LOCKDB;    
    rc = ODBCSQLExec(dbErrDesc, recoverDbId, recoverDbCursor, gODBCCfg.recoverDatabase, gODBCCfg.recoverUsername, 
      gODBCCfg.recoverPassword, FT_SELECT, sqlCommand, 
      COL_VCHAR_LEN(pstatus, kDB_STATUS_MAX_LENGTH), 
      COL_VCHAR_LEN(pmask, kDB_MASK_MAX_LENGTH), 
      COL_VCHAR_LEN(piv, kDB_IV_MAX_LENGTH), COL_VCHAR_LEN(pcert, kDB_CERTIFICATE_MAX_LENGTH), 
      COL_VCHAR_LEN(peprivkey, kDB_EPRIVKEY_MAX_LENGTH), COL_VCHAR_LEN(cname, kDB_COMMONNAME_MAX_LENGTH), NULL);
    UNLOCKDB; 
    
    if ( rc != 0 ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "DB operation failed:%s", dbErrDesc);
      status = VSAA_KM_ODBC_ERR_QUERY;
      break;
    }

    if ( (strcmp(pstatus, kDB_STATE_ISSUED) != 0) && (strcmp(pstatus, kDB_STATE_PENDING) != 0)) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "Cert status is not issued, so the certificate can not be recovered");
      status = VSAA_KM_RECOVERINFO_EMPTY;
      break;
    }

    // copy the query result into array
    for ( i = 0; subInfo[i].pszName != NULL; i++ ){
      if ( strcmp(subInfo[i].pszName, VSKPI_CERT_OR_CRL) == 0 ){
        if ( pcert == NULL ) {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "Cert retrieved from recovery data source is empty");
          status = VSAA_KM_RECOVERINFO_EMPTY;
          break;
        }
        strcpy(subInfo[i].pszValue, pcert);
      } else if ( strcmp(subInfo[i].pszName, VSKPI_MASK) == 0 ){
        if ( pmask == NULL ) {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "Mask retrieved from recovery data source is empty");
          status = VSAA_KM_RECOVERINFO_EMPTY;
          break;
        }
        strcpy(subInfo[i].pszValue, pmask);
      } else if ( strcmp(subInfo[i].pszName, VSKPI_IV) == 0 ){
        if ( piv == NULL ) {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "IV retrieved from recovery data source is empty");
          status = VSAA_KM_RECOVERINFO_EMPTY;
          break;
        }
        strcpy(subInfo[i].pszValue, piv);
      } else if ( strcmp(subInfo[i].pszName, VSKPI_EPRIKEY) == 0 ){
        if ( peprivkey == NULL ) {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "Encrypted private key retrieved from recovery data source is empty");
          status = VSAA_KM_RECOVERINFO_EMPTY;
          break;
        }
        strcpy(subInfo[i].pszValue, peprivkey);
      } else if ( strcmp(subInfo[i].pszName, KEY_COMMONNAME) == 0 ){
        if ( cname == NULL ) {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "Common name retrieved from recovery data source is empty");
          status = VSAA_KM_RECOVERINFO_EMPTY;
          break;
        }
        strcpy(subInfo[i].pszValue, cname);
      }
    }

  } while (0);

  /*
  if ( webpin )
    free (webpin);
  */

  return status;
}

VSAA_STATUS 
ODBCKMUpdateCertForPickup(const VSAA_NAME  subInfo[])
{
  RETCODE      rc = 0;
  int          i;
  VSAA_STATUS  status = VSAA_SUCCESS;
  char         sqlCommand[kDB_SQL_COMMAND_MAX_LENGTH+4000];
  char         cname[kDB_COMMONNAME_MAX_LENGTH];
  char         *webpin = NULL, *cert = NULL, *certStatus;
  char         *eventTime = NULL;
  time_t       ltime;
  
  
  do {
    memset(cname, 0, kDB_COMMONNAME_MAX_LENGTH);

    webpin = (char*)VSAAUTIL_FindUserInputValue(VSKPI_WEBPIN, strlen(VSKPI_WEBPIN), subInfo);
    if ( webpin == NULL ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "webpin is missing from inputList");
      status = VSAA_KM_WEBPIN_MISSING;
      break;
    }

    cert = (char*)VSAAUTIL_FindUserInputValue(VSKPI_CERT_OR_CRL, strlen(VSKPI_CERT_OR_CRL), subInfo);
    if ( cert == NULL ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "cert is missing from inputList");
      status = VSAA_KM_PARAMETER_MISSING;
      break;
    }
    
    certStatus = (char*)VSAAUTIL_FindUserInputValue(VSKPI_CERT_STATUS, strlen(VSKPI_CERT_STATUS), subInfo);
    if ( certStatus == NULL ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "certStatus is missing from inputList");
      status = VSAA_KM_PARAMETER_MISSING;
      break;
    }
    
    // get the common name
    sprintf(sqlCommand, "SELECT SubScriberName FROM KeyRecovery WHERE WebPin = '%s'", webpin);

    LOCKDB;    
    rc = ODBCSQLExec(dbErrDesc, recoverDbId, recoverDbCursor, gODBCCfg.recoverDatabase, gODBCCfg.recoverUsername, 
      gODBCCfg.recoverPassword, FT_SELECT, sqlCommand, COL_VCHAR_LEN(cname, kDB_COMMONNAME_MAX_LENGTH), NULL);
    UNLOCKDB; 
    
    if ( rc != 0 ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "DB operation failed:%s", dbErrDesc);
      status = VSAA_KM_ODBC_ERR_QUERY;
      break;
    }

    time( &ltime );
    eventTime = ctime(&ltime);
    eventTime[strlen(eventTime) - 1] = '\0';
    
    // build sql command to update the database
    sprintf(sqlCommand, "Update KeyRecovery SET  P12Pwd = '', Status = '%s', EventTime = '%s', cert = '%s' WHERE WebPin = '%s'", 
      certStatus, eventTime, cert, webpin);

    LOCKDB;    
    rc = ODBCSQLExec(dbErrDesc, recoverDbId, recoverDbCursor, gODBCCfg.recoverDatabase, gODBCCfg.recoverUsername, 
      gODBCCfg.recoverPassword, FT_UPDATE, sqlCommand, NULL);
    UNLOCKDB; 
    
    if ( rc != 0 ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "DB operation failed:%s", dbErrDesc);
      status = VSAA_KM_ODBC_ERR_QUERY;
      break;
    }

    // copy the query result into array
    for ( i = 0; subInfo[i].pszName != NULL; i++ ){
      if ( strcmp(subInfo[i].pszName, KEY_COMMONNAME) == 0 ){
        if ( cname == NULL ) {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "Common name retrieved from recovery data source is empty");
          status = VSAA_KM_RECOVERINFO_EMPTY;
        } else {
          strcpy(subInfo[i].pszValue, cname);
        }
        break;
      }
    }

  } while (0);

  return status;
}

VSAA_STATUS 
ODBCKMFindEntryByWebPin(const VSAA_NAME  subInfo[])
{
  RETCODE      rc = 0;
  int          i;
  int          numEntry;
  VSAA_STATUS  status = VSAA_SUCCESS;
  char         sqlCommand[kDB_SQL_COMMAND_MAX_LENGTH];
  char         cname[kDB_COMMONNAME_MAX_LENGTH];
  char         *webpin = NULL;

  do {
    memset(cname, 0, kDB_COMMONNAME_MAX_LENGTH);
    
    webpin = (char*)VSAAUTIL_FindUserInputValue(VSKPI_WEBPIN, strlen(VSKPI_WEBPIN), subInfo);
    if ( webpin == NULL ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "webpin is missing from inputList");
      status = VSAA_KM_WEBPIN_MISSING;
      break;
    }
    // get the common name
    sprintf(sqlCommand, "SELECT count(*) FROM KeyRecovery WHERE WebPin = '%s'", webpin);

    LOCKDB;    
    rc = ODBCSQLExec(dbErrDesc, recoverDbId, recoverDbCursor, gODBCCfg.recoverDatabase, gODBCCfg.recoverUsername, 
      gODBCCfg.recoverPassword, FT_SELECT, sqlCommand, COL_INTEGER(&numEntry), NULL);
    UNLOCKDB; 
    if ( rc != 0 ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "DB operation failed:%s", dbErrDesc);
      status = VSAA_KM_ODBC_ERR_QUERY;
      break;
    }

    if ( numEntry == 1 ){
      // found entry
      sprintf(sqlCommand, "SELECT SubScriberName FROM KeyRecovery WHERE WebPin = '%s'", webpin);
      
      LOCKDB;    
      rc = ODBCSQLExec(dbErrDesc, recoverDbId, recoverDbCursor, gODBCCfg.recoverDatabase, gODBCCfg.recoverUsername, 
          gODBCCfg.recoverPassword, FT_SELECT, sqlCommand, COL_VCHAR_LEN(cname, kDB_COMMONNAME_MAX_LENGTH), NULL);
      UNLOCKDB; 
      if ( rc != 0 ) {
        VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "DB operation failed:%s", dbErrDesc);
        status = VSAA_KM_ODBC_ERR_QUERY;
        break;
      }

      // copy the query result into array
      for ( i = 0; subInfo[i].pszName != NULL; i++ ){
        if ( strcmp(subInfo[i].pszName, KEY_COMMONNAME) == 0 ){
          strcpy(subInfo[i].pszValue, cname);
        } else if ( strcmp(subInfo[i].pszName, VSKPI_FOUND_ENTRY) == 0 ){
          strcpy(subInfo[i].pszValue, "found");
        } 
      }
    } else if ( numEntry == 0 ) {
      // entry not found
      for ( i = 0; subInfo[i].pszName != NULL; i++ ){
        if ( strcmp(subInfo[i].pszName, VSKPI_FOUND_ENTRY) == 0 ){
          strcpy(subInfo[i].pszValue, "notFound");
        } 
      }
    } else {
      // wrong! duplicate webpin. Need to check integrity of the db
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "duplicate entry in the database, webpin = %s\n", webpin);
      status = VSAA_INTERNAL_ERROR;
      break;
    }
  } while (0);

    return status;
    
}


VSAA_STATUS 
ODBCKMDeleteFailedEntry(const VSAA_NAME  subInfo[])
{
  RETCODE      rc = 0;
  VSAA_STATUS  status = VSAA_SUCCESS;
  char         sqlCommand[kDB_SQL_COMMAND_MAX_LENGTH];
  char         *fingerPrint = NULL;
  
  do {
    fingerPrint = (char*) VSAAUTIL_FindUserInputValue(VSAA_FINGER_PRINT, strlen(VSAA_FINGER_PRINT), subInfo);
    if ( fingerPrint == NULL ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "fingerprint is missing from inputList");
      status = VSAA_KM_PARAMETER_MISSING;
      break;
    }
    sprintf(sqlCommand, "Delete FROM KeyRecovery WHERE WebPin = '%s'", fingerPrint);

    LOCKDB;    
    rc = ODBCSQLExec(dbErrDesc, recoverDbId, recoverDbCursor, gODBCCfg.recoverDatabase, gODBCCfg.recoverUsername, 
      gODBCCfg.recoverPassword, FT_UPDATE, sqlCommand, NULL);
    UNLOCKDB; 

    if ( rc != 0 ){
      VS_Log(VS_LOG_INFO, __LINE__, __FILE__, NULL, (char *) "DB operation failed:%s", dbErrDesc);
      break;
    }
  } while (0);

  status = VSAA_SUCCESS;

  return status;

}


/*******************************************************************/
/*
 * Verify the input. If the input is authorized, build the augmented
 * name-value pairs for signing operation
 */
/*******************************************************************/

static VSAA_STATUS 
DoVerifyUser(
    const VSAA_NAME userInput[], 
    VSAA_NAME       **augmentedData)
{
	RETCODE      rc = 0;
    VSAA_STATUS  status = VSAA_SUCCESS;
    char         *pSelectSQLStatement = NULL;
    char         *pWhereSQLStatement = NULL;
    unsigned int queryResultCnt = 0;

    const char   *pszStatus = VSAA_YES;
    const char   *t_xid;

    ODBC_TRACE("VerifyUser()");
    t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);

    /* construct WHERE SQL portion according to user's input */

    status = ODBC_PopulateWhereSQLStatement((char*)ODBC_SQL_FROM_WHERE, &pWhereSQLStatement, userInput);
    if(status != VSAA_SUCCESS) {
        VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, t_xid, (char *) "Failed to construct a valid database query SQL with given configuration.");
        return status;
    }

    /* 
        Query database 
        One and only one query result is expected.
    */

   /* Start : CR25934 augment user input data from information provided in LDAP server. */
    const char* inputEncoding = VSAAUTIL_FindUserInputValue(VSAA_ENCODING_NAME,
							strlen(VSAA_ENCODING_NAME), userInput);

    status = ODBC_AugmentUserDataWithDatabaseEntry(
                        augmentedData,
                        inputEncoding,
                        pszStatus,
                        pWhereSQLStatement,
                        gODBCCfg.setAttrListPtr,
                        gODBCCfg.getAttrListPtr);
    /* End : CR25934 */

    if(ODBC_QueryDatabase(&queryResultCnt, &pSelectSQLStatement, pWhereSQLStatement)) {
        VSAAUTIL_Free(pWhereSQLStatement);
		return VSAA_VERIFY_FAILED;
    } else if (queryResultCnt == 0) {
        VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, t_xid, (char *) "No entry was found with the query SQL %s", pSelectSQLStatement);
        VSAAUTIL_Free(pWhereSQLStatement);
        VSAAUTIL_Free(pSelectSQLStatement);
		return VSAA_VERIFY_FAILED;
    } else if (queryResultCnt > 1) {
        VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, t_xid, (char *) "Multiple entries were found with the query SQL %s", pSelectSQLStatement);
        VSAAUTIL_Free(pWhereSQLStatement);
        VSAAUTIL_Free(pSelectSQLStatement);
		return VSAA_VERIFY_FAILED;
    }

    /*     
      Determine whether all required match data are satisfied. 
      If not, VSAA_PENDING should be reported for MANUAL_AUTH attributes, 
      and VSAA_NO for AUTH attributes.
    */

    //const char* inputEncoding = VSAAUTIL_FindUserInputValue(VSAA_ENCODING_NAME, strlen(VSAA_ENCODING_NAME), userInput);
    if(VSAA_TRUE != ODBC_IsDatabaseEntryAuthorized(inputEncoding, pWhereSQLStatement, gODBCCfg.authAttrListPtr))
        pszStatus = VSAA_NO;    
    else if(VSAA_TRUE != ODBC_CompareUserInputWithDatabaseEntry(userInput, pWhereSQLStatement, gODBCCfg.manualAuthAttrListPtr))
        pszStatus = VSAA_PENDING;
    
    /* 
       Validation is done, we are ready to augment user input data from
       information provided in LDAP server.
    */
    
    status = ODBC_AugmentUserDataWithDatabaseEntry(
        augmentedData,
        inputEncoding,
        pszStatus,
        pWhereSQLStatement, 
        gODBCCfg.setAttrListPtr,
        gODBCCfg.getAttrListPtr);
    
    VSAAUTIL_Free(pWhereSQLStatement);
    VSAAUTIL_Free(pSelectSQLStatement);

	return status;
}



/*******************************************************************/
/*
 * Support functions 
 */
/*******************************************************************/

VSAA_STATUS
ODBC_QueryDatabase(
    unsigned int *queryResultCnt,
    char         **ppSelectSQLStatement,
    const char   *whereSQLStatement)
{
    VSAA_STATUS status = VSAA_SUCCESS;
   	RETCODE rc = 0;
    char    *pSelectSQLStatement = NULL;
    
    pSelectSQLStatement = (char *) VSAAUTIL_Malloc(100+strlen(gODBCCfg.fromSqlCommand)+strlen(whereSQLStatement));
    if(!pSelectSQLStatement) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,  (char *) "Out of memory");
        return VSAA_OUT_OF_MEMORY;
    }
    
    strcpy(pSelectSQLStatement, "SELECT Count(*) FROM ");
    strcat(pSelectSQLStatement, gODBCCfg.fromSqlCommand);
    strcat(pSelectSQLStatement, " WHERE ");
    strcat(pSelectSQLStatement, whereSQLStatement);
 
    VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *) "ODBC_QueryDatabase(): pSelectSQLStatement is: %s", pSelectSQLStatement);

    LOCKDB;    
    rc = ODBCSQLExec(dbErrDesc, autoAuthDbId, autoAuthDbCursor, gODBCCfg.autoAuthDatabase, gODBCCfg.autoAuthUsername, 
                     gODBCCfg.autoAuthPassword, FT_SELECT, pSelectSQLStatement, COL_INTEGER(queryResultCnt), NULL);   
    UNLOCKDB;

    if(ppSelectSQLStatement) {
        *ppSelectSQLStatement = pSelectSQLStatement;
    } else {
        VSAAUTIL_Free(pSelectSQLStatement);
    }

    if ( rc != 0 ) {
    	VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, dbErrDesc);
      status = VSAA_ODBC_ERR_QUERY;
    }

    return status;
}

VSAA_BOOL
ODBC_IsDatabaseEntryAuthorized(
    const char                     *inputEncoding, 
    const char                     *whereSQLStatement,
    const VSAACfgNVPairList   *authAttrListPtr)
{
    RETCODE     rc = 0;
    char        *pSelectSQLStatement = NULL;
    char        queryResultBuf[ODBC_MAX_DATA_LENGTH];

    while(authAttrListPtr != NULL && authAttrListPtr->pszName != NULL && *authAttrListPtr->pszName) {
        pSelectSQLStatement = (char *) VSAAUTIL_Malloc(100+strlen(gODBCCfg.fromSqlCommand)+strlen(whereSQLStatement)+strlen(authAttrListPtr->pszName));
        if(!pSelectSQLStatement) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,  (char *) "Out of memory");
            return VSAA_OUT_OF_MEMORY;
        }
        
        sprintf(pSelectSQLStatement, "SELECT %s FROM ", authAttrListPtr->pszName);
        strcat(pSelectSQLStatement, gODBCCfg.fromSqlCommand);
        strcat(pSelectSQLStatement, " WHERE ");
        strcat(pSelectSQLStatement, whereSQLStatement);
        
        memset(queryResultBuf, 0, sizeof(queryResultBuf));
        
        LOCKDB;    
        rc = ODBCSQLExec(dbErrDesc, autoAuthDbId, autoAuthDbCursor, gODBCCfg.autoAuthDatabase, gODBCCfg.autoAuthUsername, 
                     gODBCCfg.autoAuthPassword, FT_SELECT, pSelectSQLStatement, COL_VCHAR_LEN(queryResultBuf, sizeof(queryResultBuf)), NULL);   
        UNLOCKDB;
        
        VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL,  (char *) "ODBC_IsDatabaseEntryAuthorized():pSelectSQLStatement is: %s", pSelectSQLStatement);

        VSAAUTIL_Free(pSelectSQLStatement);
        pSelectSQLStatement = NULL;

        /* The value from configuration file is UTF-8 encoded. 
           If the data from database is native, we need to convert. */
        
        char* authValue = authAttrListPtr->pszValue;
        if(gDataSourceUseUTF8 == VSAA_FALSE && inputEncoding != NULL && strlen(inputEncoding) > 0) { // database value is native
            int rc = UTF8ToNative(&authValue, authAttrListPtr->pszValue, inputEncoding);
            if(rc != 0) {
                VS_Log (VS_LOG_WARNING, __LINE__, __FILE__, NULL,   (char *) "Conversion from native to UTF-8 encoding failed on authentication value (%s) with error (%d)", authAttrListPtr->pszValue, rc);
                authValue = authAttrListPtr->pszValue;
            } 
        } else {
            authValue = authAttrListPtr->pszValue; // both are UTF-8
        }
        if(rc != 0 || strcmp(queryResultBuf, authValue)) {
            if(authValue != authAttrListPtr->pszValue && authValue != NULL)
                free(authValue); 
            return VSAA_FALSE;            
        }
        
        if(authValue != authAttrListPtr->pszValue && authValue != NULL)
            free(authValue); 

        authAttrListPtr = authAttrListPtr->next;
    }

    return VSAA_TRUE;
}

VSAA_BOOL
ODBC_CompareUserInputWithDatabaseEntry(
    const VSAA_NAME           userInput[],
    const char                *whereSQLStatement,
    const VSAACfgAttrList     *authAttrListPtr)
{
    RETCODE     rc = 0;
    const char  *pszFDFAttr = NULL;
    const char  *pszUserVal = NULL;    
    char        *pSelectSQLStatement = NULL;
    char        queryResultBuf[ODBC_MAX_DATA_LENGTH];
    const char  *t_xid;

    const char* inputEncoding = VSAAUTIL_FindUserInputValue(VSAA_ENCODING_NAME, strlen(VSAA_ENCODING_NAME), userInput);
    t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);

    while(authAttrListPtr != NULL && authAttrListPtr->pszValue != NULL && *authAttrListPtr->pszValue) {
        pszFDFAttr = (char*)VSAAUTIL_FindFDFAttrName(authAttrListPtr->pszValue, gODBCCfg.mapAttrListPtr);
        if( 
            pszFDFAttr &&
            (pszUserVal = (char*)VSAAUTIL_FindUserInputValue(pszFDFAttr, strlen(pszFDFAttr), userInput))
          ) 
        {
            pSelectSQLStatement = (char *) VSAAUTIL_Malloc(100+strlen(gODBCCfg.fromSqlCommand)+strlen(whereSQLStatement)+strlen(authAttrListPtr->pszValue));
            if(!pSelectSQLStatement) {
                VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "Out of memory");
                return VSAA_OUT_OF_MEMORY;
            }
            
            sprintf(pSelectSQLStatement, "SELECT %s FROM ", authAttrListPtr->pszValue);
            strcat(pSelectSQLStatement, gODBCCfg.fromSqlCommand);
            strcat(pSelectSQLStatement, " WHERE ");
            strcat(pSelectSQLStatement, whereSQLStatement);
            
            memset(queryResultBuf, 0, sizeof(queryResultBuf));

            LOCKDB;    
            rc = ODBCSQLExec(dbErrDesc, autoAuthDbId, autoAuthDbCursor, gODBCCfg.autoAuthDatabase, gODBCCfg.autoAuthUsername, 
                     gODBCCfg.autoAuthPassword, FT_SELECT, pSelectSQLStatement, COL_VCHAR_LEN(queryResultBuf, sizeof(queryResultBuf)), NULL);   
            UNLOCKDB;

            VSAAUTIL_Free(pSelectSQLStatement);
            pSelectSQLStatement = NULL;

            /* pszUserVal is natively encoded. It may need to be
               converted into UTF-8 if database value is so. */
        
            char* pszUserValToCmp = NULL;
            if(gDataSourceUseUTF8 == VSAA_TRUE && inputEncoding != NULL && strlen(inputEncoding) > 0) {
                int rc = NativeToUTF8(&pszUserValToCmp, pszUserVal, inputEncoding);
                if(rc != 0) {
                    VS_Log (VS_LOG_WARNING, __LINE__, __FILE__, t_xid,   (char *) "Conversion from native to UTF-8 encoding failed on manual authentication value (%s) with error (%d)", pszUserVal, rc);
                   pszUserValToCmp = (char*)pszUserVal;
                } 
            } else {
                pszUserValToCmp = (char*)pszUserVal;
            }
            if(rc != 0 || strcmp(pszUserValToCmp, queryResultBuf)) {
                if(pszUserValToCmp != pszUserVal && pszUserValToCmp != NULL)
                    free(pszUserValToCmp);
                return VSAA_FALSE;            
            }

            if(pszUserValToCmp != pszUserVal && pszUserValToCmp != NULL)
                free(pszUserValToCmp);
        } else
            return VSAA_FALSE;

        authAttrListPtr = authAttrListPtr->next;
    }

    return VSAA_TRUE;
}

/* 
 * This function collects user input data or hard set data
 * for certain fields specified in configuration file.
 * The data is stored into an array of VSAA_NAME structure
 * augmentedData. The last element of augmentedData will be
 * always NULL data for caller to determined the size of
 * the allocated array.
 */

VSAA_STATUS
ODBC_AugmentUserDataWithDatabaseEntry(
    VSAA_NAME                 **augmentedData,
    const char                *inputEncoding, 
    const char                *pszAuthValue,
    const char                *whereSqlStatement,
    const VSAACfgNVPairList   *setAttrListPtr,
    const VSAACfgAttrList     *getAttrListPtr)
{
    char         *pszAttr = NULL, *pszValue = NULL;
    char         *pszAttribute = NULL;
    
    VSAA_NAME*   augment;
    unsigned int augmentCapacity = 20;
    unsigned int augmentCapacityIncrement = 10;
    unsigned int augmentCnt = 0, i;
   
    RETCODE      rc = 0;
    char         *pSelectSQLStatement = NULL;
    char         queryResultBuf[ODBC_MAX_DATA_LENGTH];

    ODBC_TRACE("ODBC_AugmentUserDataWithDatabaseEntry()");

    if(!augmentedData) {
        return ODBC_LogError(VSAA_INTERNAL_ERROR, "null parameter was found");
    } 

    augment = (VSAA_NAME *)VSAAUTIL_Malloc(augmentCapacity*sizeof(VSAA_NAME));
    if(!augment) {
        return ODBC_LogError(VSAA_OUT_OF_MEMORY, "Out of memory");
    } else {
        memset(augment, 0, augmentCapacity*sizeof(VSAA_NAME));
        augment[0].pszName  = VSAAUTIL_Strdup(VSAA_AUTHENTICATE);
        augment[0].pszValue = VSAAUTIL_Strdup(pszAuthValue);

        if(!augment[0].pszName || !augment[0].pszValue) {
            if(augment[0].pszName) VSAAUTIL_Free(augment[0].pszName);
            VSAAUTIL_Free(augment);
            return ODBC_LogError(VSAA_OUT_OF_MEMORY, "Out of memory");
        }

        augmentCnt++;
    }

    /* 
        Don't forget to make sure that the augment list 
        isn't overwritten.
        
        Now, populate argment list from hard coded set in configuration file.
    */
        
    while(setAttrListPtr && *setAttrListPtr->pszName) 
    {
        if (augmentCnt >= augmentCapacity - 1) { /* last element of augmentedData must be NULL */
            augment = (VSAA_NAME *)VSAAUTIL_Realloc(augment, (augmentCapacityIncrement+augmentCapacity)*sizeof(VSAA_NAME));
            if(!augment) {
                return ODBC_LogError(VSAA_OUT_OF_MEMORY, "Out of memory");
            } else {
                memset(augment+augmentCapacity*sizeof(VSAA_NAME), 0, augmentCapacityIncrement*sizeof(VSAA_NAME));
                augmentCapacity += augmentCapacityIncrement;            
            }
        }

       /* set attributes are HTML tags, their values are from configuration 
          file which are UNICODE */

        augment[augmentCnt].pszName = VSAAUTIL_Strdup(setAttrListPtr->pszName);

        if(gDataSourceUseUTF8 == VSAA_TRUE && inputEncoding != NULL && strlen(inputEncoding) > 0) {
            pszValue = NULL;
            int rc = UTF8ToNative(&pszValue, setAttrListPtr->pszValue, inputEncoding);
            if(rc != 0) {
                // ignore conversion error which may be un-supported code pages
                VS_Log (VS_LOG_WARNING, __LINE__, __FILE__, NULL,   (char *) "Conversion from UTF8 to native encoding failed for augment attribute (%s) with error (%d)", setAttrListPtr->pszName, rc);
                augment[augmentCnt].pszValue = VSAAUTIL_Strdup(setAttrListPtr->pszValue);
            } else {
                augment[augmentCnt].pszValue = pszValue;
            }
        } else {
            augment[augmentCnt].pszValue = VSAAUTIL_Strdup(setAttrListPtr->pszValue);
        }

        if(!augment[augmentCnt].pszName || !augment[augmentCnt].pszValue) {
            for(i=0; i<=augmentCnt; i++) {
                if(augment[i].pszName) VSAAUTIL_Free(augment[i].pszName);
                if(augment[i].pszValue) VSAAUTIL_Free(augment[i].pszValue);
            }
            VSAAUTIL_Free(augment);            
            return ODBC_LogError(VSAA_OUT_OF_MEMORY, "Out of memory");
        }

        augmentCnt++;
        setAttrListPtr = setAttrListPtr->next;
    }

    /* populate argument list from directory entry via get list */ 

    while(getAttrListPtr && getAttrListPtr->pszValue) {
        pSelectSQLStatement = (char *) VSAAUTIL_Malloc(100+strlen(gODBCCfg.fromSqlCommand)+strlen(whereSqlStatement)+strlen(getAttrListPtr->pszValue));
        if(!pSelectSQLStatement) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,  (char *) "Out of memory");
            return VSAA_OUT_OF_MEMORY;
        }
        sprintf(pSelectSQLStatement, "SELECT %s FROM ", getAttrListPtr->pszValue);
        strcat(pSelectSQLStatement, gODBCCfg.fromSqlCommand);
        strcat(pSelectSQLStatement, " WHERE ");
        strcat(pSelectSQLStatement, whereSqlStatement);
        
        memset(queryResultBuf, 0, sizeof(queryResultBuf));
        
        VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL,  (char *) "ODBC_AugmentUserDataWithDatabaseEntry():pSelectSQLStatement = %s", pSelectSQLStatement);

        LOCKDB;    
        rc = ODBCSQLExec(dbErrDesc, autoAuthDbId, autoAuthDbCursor, gODBCCfg.autoAuthDatabase, gODBCCfg.autoAuthUsername, 
                     gODBCCfg.autoAuthPassword, FT_SELECT, pSelectSQLStatement, COL_VCHAR_LEN(queryResultBuf, sizeof(queryResultBuf)), NULL);   
        UNLOCKDB;

        if(rc != 0) { /* should the routine returns with an error or just continue to get whatever available? */
            VS_Log(VS_LOG_WARNING, __LINE__, __FILE__, NULL,  (char *) "Augmenting data enconuntered ODBC error %d: %s, pSelectSQLStatement = %s", rc, dbErrDesc, pSelectSQLStatement);
            VSAAUTIL_Free(pSelectSQLStatement);
            pSelectSQLStatement = NULL;
        } else {        
            VSAAUTIL_Free(pSelectSQLStatement);
            pSelectSQLStatement = NULL;
            
            pszAttr = (char *) VSAAUTIL_FindFDFAttrName(getAttrListPtr->pszValue, gODBCCfg.mapAttrListPtr);
            if (pszAttr) {
                if (augmentCnt >= augmentCapacity - 1) { /* last element of augmentedData must be NULL */
                    augment = (VSAA_NAME *)VSAAUTIL_Realloc(augment, (augmentCapacityIncrement+augmentCapacity)*sizeof(VSAA_NAME));
                    if(!augment) 
                        return ODBC_LogError(VSAA_OUT_OF_MEMORY, "Out of memory");
                    else {
                        memset(augment+augmentCapacity*sizeof(VSAA_NAME), 0, augmentCapacityIncrement*sizeof(VSAA_NAME));
                        augmentCapacity += augmentCapacityIncrement;            
                    }
                }
                
                augment[augmentCnt].pszName = VSAAUTIL_Strdup(pszAttr);
                if(gDataSourceUseUTF8 == VSAA_TRUE &&
                   inputEncoding != NULL && strlen(inputEncoding) > 0) {
                    pszValue = NULL;
                    int rc = UTF8ToNative(&pszValue, queryResultBuf, inputEncoding);
                    if(rc != 0) {
                        VS_Log (VS_LOG_WARNING, __LINE__, __FILE__, NULL,   (char *) "Conversion from UTF8 to native encoding failed for augment attribute (%s) with error (%d)", pszAttr, rc);
                        augment[augmentCnt].pszValue = VSAAUTIL_Strdup(queryResultBuf);
                    } else {
                        augment[augmentCnt].pszValue = pszValue;
                    }
                } else {
                    augment[augmentCnt].pszValue = VSAAUTIL_Strdup(queryResultBuf); 
                }

                if(!augment[augmentCnt].pszName || !augment[augmentCnt].pszValue) {
                    for(i=0; i<=augmentCnt; i++) {
                        if(augment[i].pszName) VSAAUTIL_Free(augment[i].pszName);
                        if(augment[i].pszValue) VSAAUTIL_Free(augment[i].pszValue);
                    }
                    VSAAUTIL_Free(augment);            
                    return ODBC_LogError(VSAA_INTERNAL_ERROR, "Empty value cannot be augmented.");
                }

                augmentCnt++;
            } else {
                VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "No FDF attribute was mapped to: %s.", getAttrListPtr->pszValue);
                for(i=0; i<augmentCnt; i++) {
                    if(augment[i].pszName) VSAAUTIL_Free(augment[i].pszName);
                    if(augment[i].pszValue) VSAAUTIL_Free(augment[i].pszValue);
                }
                VSAAUTIL_Free(augment);
                return ODBC_LogError(VSAA_ERR_INVALID_DATA, "missing mapping entry for some GET attributes");
            }
        }
                
        getAttrListPtr = getAttrListPtr->next;
    }
    
    
    *augmentedData = augment;

    return VSAA_SUCCESS;
}

/*** ODBC_UpdateDatabaseEntry
 ***
 *** DESCRIPTION
 ***
 *** Update the database entry for Registration
 ***
 *** ARGUMENTS 
 ***   char                   **ppUpdateSQLStatement - IN - Update SQL statement
 ***   const VSAA_NAME        userInput[] - IN - user input name value pair list
 ***   const char             *certBase64 - IN - base64 cert
 ***   const char             *certStatus - IN - cert status
 ***   const char             *whereSQLStatement - IN - WHERE clause of Update statement
 ***   const VSAACfgAttrList  *updAttrListPtr - IN - Update attribute list 
 ***
 *** RETURNS 
 ***   RETCODE - return code
 ***
 ***
 *** REVISION HISTORY
 ***   Date          Author     Desc
 ***   ----          ------     ----
 ***									Oanh	     ?
 ***   Dec 14, 2000   Tom	      Update statment can only update one table.
 ***                            The table name is in gODBCCfg.updTableName.
 ***                          
 ***/
VSAA_STATUS    
ODBC_UpdateDatabaseEntry(
    char                   **ppUpdateSQLStatement,
    const VSAA_NAME        userInput[],
    const char             *certBase64, 
    const char             *certStatus,
    const char             *whereSQLStatement,
    const VSAACfgAttrList  *updAttrListPtr)
{
    VSAA_STATUS  status = VSAA_SUCCESS;
    RETCODE      rc = 0;
    const char   *pszUserVal = NULL;
    char* pszUserValToUpdate = NULL;
    char         *pszSQLEscapedUserValToUpdate = NULL;
    int          sQLEscapedUserValToUpdateLen = 0;
    const char   *pszFDFAttr = NULL;
    const char   *t_xid;
    char         *pUpdateSQLStatement = NULL;
    int          updateSQLStatementLen = 0;
    
    ODBC_TRACE("ODBC_UpdateDatabaseEntry()");
    t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);

    do { 
        if(certBase64 == NULL) {
            status = VSAA_ERR_CERTIFICATE_NOT_GIVEN;
            break;
        }
        
        const char* inputEncoding = VSAAUTIL_FindUserInputValue(VSAA_ENCODING_NAME, strlen(VSAA_ENCODING_NAME), userInput);
        
        updateSQLStatementLen = 200 + 
            strlen(gODBCCfg.updTableName) + 
            strlen(whereSQLStatement) + 
            strlen(gODBCCfg.certStatusAttrName) +
            strlen(certBase64) +
            strlen(gODBCCfg.certAttrName) +
            strlen(gODBCCfg.certSerialAttrName);
        
        if(certStatus) {
            updateSQLStatementLen += strlen(certStatus);
        }
        
        if(gODBCCfg.certSerialAttrName[0]) {
            updateSQLStatementLen += strlen(certBase64);
        }
        
        pUpdateSQLStatement = (char *) VSAAUTIL_Malloc(updateSQLStatementLen);
        if(!pUpdateSQLStatement) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "Out of memory");
            status = VSAA_OUT_OF_MEMORY;
            break;
        }
        
        sprintf(pUpdateSQLStatement, "UPDATE %s SET ", gODBCCfg.updTableName);
        if(gODBCCfg.certStatusAttrName[0]) {
            strcat(pUpdateSQLStatement, gODBCCfg.certStatusAttrName);
            strcat(pUpdateSQLStatement, "= '");
            strcat(pUpdateSQLStatement, certStatus);
            strcat(pUpdateSQLStatement, "', ");
        }
        
        strcat(pUpdateSQLStatement, gODBCCfg.certAttrName);
        strcat(pUpdateSQLStatement, " = '");
        strcat(pUpdateSQLStatement, certBase64);
        strcat(pUpdateSQLStatement, "'");
        
        if(gODBCCfg.certSerialAttrName[0] != 0) {
            const char* certSerial = VSAAUTIL_FindUserInputValue(VSAA_CERT_SERIAL, strlen(VSAA_CERT_SERIAL), userInput);
            if(certSerial) {
                strcat(pUpdateSQLStatement, ", ");
                strcat(pUpdateSQLStatement, gODBCCfg.certSerialAttrName);
                strcat(pUpdateSQLStatement, " = '");
                strcat(pUpdateSQLStatement, certSerial);
                strcat(pUpdateSQLStatement, "'");
            } else {
                VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "Could not find value for attribute: %s", VSAA_CERT_SERIAL);
                VSAAUTIL_Free(pUpdateSQLStatement);
                status = VSAA_ERR_INVALID_DATA;
                break;
            }
        }
        
        while(updAttrListPtr && updAttrListPtr->pszValue) {
            pszFDFAttr = (char*)VSAAUTIL_FindFDFAttrName(updAttrListPtr->pszValue, gODBCCfg.mapAttrListPtr);
            if( 
                pszFDFAttr &&
                (pszUserVal = (char*)VSAAUTIL_FindUserInputValue(pszFDFAttr, strlen(pszFDFAttr), userInput))
                )
            {    
            /* pszUserVal is natively encoded. It may need to 
                be converted into UTF-8 if database value is so. */
                
                if(gDataSourceUseUTF8 == VSAA_TRUE && inputEncoding != NULL && strlen(inputEncoding) > 0) {
                    int rc = NativeToUTF8(&pszUserValToUpdate, pszUserVal, inputEncoding);
                    if(rc != 0) {
                        VS_Log (VS_LOG_WARNING, __LINE__, __FILE__, t_xid,   (char *) "Conversion from native to UTF-8 encoding failed on update value (%s) with error (%d)", pszUserVal, rc);
                        pszUserValToUpdate = (char*)pszUserVal;
                    } 
                } else {
                    pszUserValToUpdate = (char*)pszUserVal;
                }
                
                /* SQL escape single quote character in value, with another single quote character */
                vsSQLEscSingleQuote(pszUserValToUpdate, NULL, &sQLEscapedUserValToUpdateLen);
                if ((pszSQLEscapedUserValToUpdate = (char*)malloc(sQLEscapedUserValToUpdateLen)) == NULL) {
                    VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "Out of memory");
                    status = VSAA_OUT_OF_MEMORY;
                    break;
                }
                vsSQLEscSingleQuote(pszUserValToUpdate, pszSQLEscapedUserValToUpdate, &sQLEscapedUserValToUpdateLen);
                
                updateSQLStatementLen += strlen(updAttrListPtr->pszValue) + strlen(pszSQLEscapedUserValToUpdate) + 5;
                pUpdateSQLStatement = (char *) VSAAUTIL_Realloc(pUpdateSQLStatement, updateSQLStatementLen);
                if(!pUpdateSQLStatement) {
                    VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "Out of memory");
                    status = VSAA_OUT_OF_MEMORY;
                    break;
                }
                
                strcat(pUpdateSQLStatement, ", ");
                strcat(pUpdateSQLStatement, updAttrListPtr->pszValue);
                strcat(pUpdateSQLStatement, " = '");            
                strcat(pUpdateSQLStatement, pszSQLEscapedUserValToUpdate);
                strcat(pUpdateSQLStatement, "'");
                
            }
            
            updAttrListPtr = updAttrListPtr->next;
        }
        if (status != VSAA_SUCCESS) break;
        
        strcat(pUpdateSQLStatement, " WHERE ");
        strcat(pUpdateSQLStatement, whereSQLStatement);
        
        LOCKDB;
        rc = ODBCSQLExec(dbErrDesc, autoAuthDbId, autoAuthDbCursor, gODBCCfg.autoAuthDatabase, gODBCCfg.autoAuthUsername, 
            gODBCCfg.autoAuthPassword, FT_UPDATE, pUpdateSQLStatement, NULL);
        UNLOCKDB;
        
        VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, t_xid,  (char *) "ODBC_UpdateDatabaseEntry():pUpdateSQLStatement is: %s", pUpdateSQLStatement);
        
        if (!ODBC_OK(rc) )
        {
            VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, t_xid, (char *) "Update database failed with error %s by SQL: %s", dbErrDesc, pUpdateSQLStatement?pUpdateSQLStatement:" ");
            status = VSAA_UPDATE_FAILED;
            break;
        }
    } while (0);

    if(ppUpdateSQLStatement) {
        *ppUpdateSQLStatement = pUpdateSQLStatement;
    } else {
        VSAAUTIL_Free(pUpdateSQLStatement);
    }

    if(pszUserValToUpdate != NULL && pszUserValToUpdate != pszUserVal)
                free(pszUserValToUpdate);

    if(pszSQLEscapedUserValToUpdate)
        free(pszSQLEscapedUserValToUpdate);

    return status;
}

void 
FindEmailColumnName()
{
    if(gIsEmailODBCAttrQueried == VSAA_FALSE) {                        
        /* 
          Determine that cert_serial number is available from LDAP
          server in order to identifier the target entry with
          given value of certSerial.
        */
        
        VSAACfgNVPairList *mapAttrListPtr = gODBCCfg.mapAttrListPtr;
        char* pszAttr = NULL;
        
        gIsEmailODBCAttrQueried = VSAA_TRUE;
        
        while(mapAttrListPtr != NULL && *mapAttrListPtr->pszName) 
        {
            if(!strcmp(mapAttrListPtr->pszName, KEY_EMAIL)) {
                strcpy(gEmailODBCAttr, mapAttrListPtr->pszValue);
                break;
            }
            mapAttrListPtr = mapAttrListPtr->next;
        }
    }
}

VSAA_STATUS    
ODBC_RevokeDatabaseEntry(
    char                   **ppRevokeSQLStatement,
    const VSAA_NAME        userInput[],
    const char             *certStatus,
    const char             *whereSQLStatement)
{
    VSAA_STATUS status = VSAA_SUCCESS;
    RETCODE     rc = 0;
    char        *pRevokeSQLStatement = NULL;
    int         revokeSQLStatementLen = 0;
    const char  *pszCertSerialValue = NULL;
    const char  *t_xid;

    ODBC_TRACE("ODBC_RevokeDatabaseEntry()");
    t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);
    
    if(strlen(gODBCCfg.certSerialAttrName) > 0) {
         pszCertSerialValue = VSAAUTIL_FindUserInputValue(VSAA_SERIAL, strlen(VSAA_SERIAL), userInput);
    } else {
        VS_Log(VS_LOG_ALERT, __LINE__, __FILE__, t_xid, (char *) "Certificate status couldn't be recorded during revoke process because value of cert_serial was not in ODBC_ATTR_UPD.");
        return VSAA_NO_SERIAL;
    }

    revokeSQLStatementLen = 100 + 
        strlen(gODBCCfg.updTableName) + 
        strlen(gODBCCfg.certSerialAttrName) + 
        strlen(pszCertSerialValue) +
        strlen(gODBCCfg.certStatusAttrName);
    
    if(certStatus)
        revokeSQLStatementLen += strlen(certStatus);
    
    pRevokeSQLStatement = (char *) VSAAUTIL_Malloc(revokeSQLStatementLen);
    if(!pRevokeSQLStatement) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "Out of memory");
        return VSAA_OUT_OF_MEMORY;
    }
    
    sprintf(pRevokeSQLStatement, "UPDATE %s SET ", gODBCCfg.updTableName);
    if(gODBCCfg.certStatusAttrName[0]) {
        strcat(pRevokeSQLStatement, gODBCCfg.certStatusAttrName);
        strcat(pRevokeSQLStatement, "= '");
        strcat(pRevokeSQLStatement, certStatus);
        strcat(pRevokeSQLStatement, "'");
    
        strcat(pRevokeSQLStatement, " WHERE ");
        strcat(pRevokeSQLStatement, gODBCCfg.certSerialAttrName);
        strcat(pRevokeSQLStatement, "= '");
        strcat(pRevokeSQLStatement, pszCertSerialValue);
        strcat(pRevokeSQLStatement, "'");

        LOCKDB;
        rc = ODBCSQLExec(dbErrDesc, autoAuthDbId, autoAuthDbCursor, gODBCCfg.autoAuthDatabase, gODBCCfg.autoAuthUsername, 
                     gODBCCfg.autoAuthPassword, FT_UPDATE, pRevokeSQLStatement, NULL);
        UNLOCKDB;
    }

    VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, t_xid,  (char *) "ODBC_RevokeDatabaseEntry():pRevokeSQLStatement is: %s", pRevokeSQLStatement);

    if(ppRevokeSQLStatement) {
        *ppRevokeSQLStatement = pRevokeSQLStatement;
    } else {
        VSAAUTIL_Free(pRevokeSQLStatement);
    }
    
    if (!ODBC_OK(rc) )
    {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, t_xid, (char *) "Update database failed with error %s by SQL: %s", dbErrDesc, pRevokeSQLStatement?pRevokeSQLStatement:" ");
      status = VSAA_UPDATE_FAILED;
    }			
    
    return status;
}
			

VSAA_STATUS
ODBC_ParseFromWhereSqlCommand(
    char             *szFromSqlCommand,
    char             *szWhereSqlCommand,
    VSAACfgAttrList  **fromAttrs,
    VSAACfgAttrList  **whereAttrs, 
    char             *sqlcommand)
{
    char     tmpBuf[ODBC_MAX_SQL_LENGTH];
    char     szAttr[ODBC_MAX_SQL_LENGTH];
    char     *tmpStr = NULL;
    unsigned int i;
    unsigned int whereAttrsCnt = 0;
    unsigned int requiredSqlInputAttrsCnt = 0;

    if(!szFromSqlCommand || !szWhereSqlCommand || !fromAttrs || !whereAttrs)
        return VSAA_INTERNAL_ERROR;

    szFromSqlCommand[0] = 0;
    szWhereSqlCommand[0] = 0;
    *whereAttrs = NULL;
    *fromAttrs = NULL;

    if(sqlcommand == NULL || !*sqlcommand)
        return VSAA_SUCCESS;

    /* trim leading space */

    while(isspace(*sqlcommand)) sqlcommand++;
   
    /* 
        SQL should starts with " followed by word FROM
    */

    if(sqlcommand[0] != '"') 
        return VSAA_ODBC_ERR_CFG_SQL;
    else {
        sqlcommand ++;
    }

    if(VSAAUTIL_StrnCaseCmp(sqlcommand, "FROM", strlen("FROM")))
        return VSAA_ODBC_ERR_CFG_SQL;
    else
        sqlcommand += strlen("FROM");

    while(isspace(*sqlcommand)) sqlcommand++;
    
    /*********************/
    /* Find table names  */
    /*********************/
    
    /* sqlcommand now starts with the string after word "FROM" */
    /* To find the word "WHERE" */

    tmpStr = strstr(sqlcommand, "WHERE");    
    if(!tmpStr) tmpStr = strstr(sqlcommand, "where");
    if(!tmpStr) return VSAA_ODBC_ERR_CFG_SQL;
   
    strncpy(szFromSqlCommand, sqlcommand, tmpStr-sqlcommand);
    szFromSqlCommand[tmpStr-sqlcommand] = 0;
    
    strcpy(tmpBuf, szFromSqlCommand);
    
    sqlcommand = tmpStr+strlen("WHERE"); /* move sqlcommand to be after "WHERE" */        
    tmpStr = tmpBuf;

    /* 
        Find all tables names to be scanned which are separated with ',' 
        E.g, ... FROM table1, table2 WHERE ....
    */

    memset(szAttr, 0, sizeof(szAttr));        
    do {
        while(isspace(*tmpStr)) tmpStr++;
        strcpy(szAttr, tmpStr);
        tmpStr = szAttr;
        while(*tmpStr && *tmpStr != ',') tmpStr ++;
        if(*tmpStr) {
            *tmpStr = 0;
            tmpStr ++;
        }
        i = strlen(szAttr)-1;
        while(i>=0 && isspace(szAttr[i])) { szAttr[i] = 0; i--; }
        if(szAttr[0]) VSAAUTIL_AppendCfgAttrEntry(fromAttrs, szAttr);
    } while (*tmpStr);
    
    /************************************/
    /* Find TBD fields in where clause  */
    /************************************/       

    /* 
        The TBD fields are given after "+ in sqlcommand, e.g.,
        ... WHERE attr1='%s' AND attr2='%s'"+attr1fdf+attr2fdf
    */
    
    tmpStr = strstr(sqlcommand, "\"+");
    if(!sqlcommand || !sqlcommand[2] || isspace(sqlcommand[2])) {
        VSAAUTIL_FreeCfgAttrList(*fromAttrs);
        *fromAttrs = NULL;
        return VSAA_ODBC_ERR_CFG_SQL;
    } 
    
    
    strncpy(szWhereSqlCommand, sqlcommand, tmpStr-sqlcommand);
    szWhereSqlCommand[tmpStr-sqlcommand] = 0;        
    
    sqlcommand = tmpStr+2;
    
    memset(tmpBuf, 0, sizeof(tmpBuf));
    strcpy(tmpBuf, sqlcommand);
    tmpStr = tmpBuf;

    whereAttrsCnt = 0;
    memset(szAttr, 0, sizeof(szAttr));
    do {
        while(isspace(*tmpStr)) tmpStr++;
        strcpy(szAttr, tmpStr);
        tmpStr = szAttr;
        while(*tmpStr && *tmpStr != '+') tmpStr ++;
        if(*tmpStr) {
            *tmpStr = 0;
            tmpStr ++;
        }
        i = strlen(szAttr)-1;
        while(i>=0 && isspace(szAttr[i])) { szAttr[i] = 0; i--; }
        if(szAttr[0]) {
            VSAAUTIL_AppendCfgAttrEntry(whereAttrs, szAttr);            
            whereAttrsCnt ++;
        }
    } while (*tmpStr);
    
    requiredSqlInputAttrsCnt = 0;
    tmpStr = szWhereSqlCommand;
    do {
        tmpStr = strstr(tmpStr, "%s");
        if(tmpStr) {
            requiredSqlInputAttrsCnt ++;
            tmpStr += 2;
        }
    } while(tmpStr && *tmpStr);

    if(requiredSqlInputAttrsCnt != whereAttrsCnt) {
        VSAAUTIL_FreeCfgAttrList(*fromAttrs);
        VSAAUTIL_FreeCfgAttrList(*whereAttrs);
        
        *whereAttrs = NULL;
        *fromAttrs = NULL;
        return VSAA_ODBC_ERR_CFG_SQL;
    }

    return VSAA_SUCCESS;
}

VSAA_STATUS 
ODBC_PopulateWhereSQLStatement(
    char            *whereStatementType,
    char            **ppszSql, 
    const VSAA_NAME userInput[])
{
    VSAA_STATUS status = VSAA_SUCCESS;
    const char*  pszUserInputValue = NULL;
    char         *pszSQLEscapedUserInputValue = NULL;
    int          pszSQLEscapedUserInputLen = 0;
    char*        pszFormatString;
    char         szSQLAfterWildChar[ODBC_MAX_SQL_LENGTH]=""; /* part of gODBCCfg.whereSqlCommand */
    char         *sql = NULL;
    VSAACfgAttrList* tmpMatchAttrs;
    const char   *t_xid;

    t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);
    do {
        
        if(!ppszSql) {
            status = VSAA_INTERNAL_ERROR;
            break;
        }
        
        *ppszSql = NULL;
        
        if (!strcmp(whereStatementType, ODBC_SQL_FROM_WHERE)) {
            tmpMatchAttrs = gODBCCfg.whereAttrListPtr;
            sql = (char *)VSAAUTIL_Strdup(gODBCCfg.whereSqlCommand);
        } else if (!strcmp(whereStatementType, ODBC_SQL_UPDATE_WHERE)) {
            tmpMatchAttrs = gODBCCfg.updWhereAttrListPtr;
            sql = (char *)VSAAUTIL_Strdup(gODBCCfg.updWhereSqlCommand);
        } else {
            status = VSAA_ERR_INVALID_DATA;
            break;
        }
        
        if(!sql) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "Out of memory");
            status = VSAA_OUT_OF_MEMORY;
            break;
        }
        
        while(tmpMatchAttrs != NULL) {
            pszUserInputValue = VSAAUTIL_FindUserInputValue(tmpMatchAttrs->pszValue, strlen(tmpMatchAttrs->pszValue), userInput);
            
            /* SQL escape single quote character in value, with another single quote character */
            vsSQLEscSingleQuote(pszUserInputValue, NULL, &pszSQLEscapedUserInputLen);
            if ((pszSQLEscapedUserInputValue = (char*)malloc(pszSQLEscapedUserInputLen)) == NULL) {
                VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "Out of memory");
                status = VSAA_OUT_OF_MEMORY;
                break;
            }
            vsSQLEscSingleQuote(pszUserInputValue, pszSQLEscapedUserInputValue, &pszSQLEscapedUserInputLen);
            
            pszFormatString = strstr(sql, "%s");
            if(pszUserInputValue != NULL && pszFormatString != NULL) {
                strcpy(szSQLAfterWildChar, pszFormatString+2);
                *pszFormatString = 0;
                sql = (char *)VSAAUTIL_Realloc(sql, strlen(sql)+strlen(pszSQLEscapedUserInputValue)+strlen(szSQLAfterWildChar)+1);
                if(!sql) {
                    VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "Out of memory");
                    status = VSAA_OUT_OF_MEMORY;
                    break;
                }
                strcat(sql, pszSQLEscapedUserInputValue);
                strcat(sql, szSQLAfterWildChar);            
            } else {
                status = VSAA_ERR_INVALID_DATA;
                break;
            }
            
            tmpMatchAttrs = tmpMatchAttrs->next;
        }
        
        const char* inputEncoding = VSAAUTIL_FindUserInputValue(VSAA_ENCODING_NAME, strlen(VSAA_ENCODING_NAME), userInput);
        if(gDataSourceUseUTF8 == VSAA_TRUE && inputEncoding != NULL && strlen(inputEncoding) > 0) {
            int rc = NativeToUTF8(ppszSql, sql, inputEncoding);
            if(rc != 0) {
                VS_Log (VS_LOG_WARNING, __LINE__, __FILE__, t_xid,   (char *) "Conversion from native to UTF-8 encoding failed on where statement (%s) with error (%d)", sql, rc);
                *ppszSql = sql;
            } else {
                free(sql);
            }
        } else {
            *ppszSql = sql;
        }
        
        VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, t_xid, (char *) "ODBC_PopulateWhereSQLStatement() returns: %s", *ppszSql);
        
    } while(0);
    
    if (pszSQLEscapedUserInputValue) free(pszSQLEscapedUserInputValue);
    
    return status;
}

/*** ParseUpdateWhereSqlCommand
 ***
 *** DESCRIPTION
 ***
 *** parse the where clause of an UPDATE statement
 ***
 *** ARGUMENTS 
 ***   char  *szWhereSqlCommand	       - OUT - WHERE clause
 ***   VSAACfgAttrList **updWhereAttrs - OUT - Where clause attributes
 ***   char  **sqlcommand              - IN  - the where clause from config file        
 ***
 *** RETURNS 
 ***   RETCODE - the status of executing the SQL query
 ***
 ***
 *** REVISION HISTORY
 ***   Date          Author     Desc
 ***   ----          ------     ----
 ***   Dec 14, 2000   Tom       Create
 ***                          
 ***/
VSAA_STATUS
ODBC_ParseUpdateWhereSqlCommand(
    char             *szWhereSqlCommand,
    VSAACfgAttrList  **updWhereAttrs, 
    char             *sqlcommand)
{
    char     tmpBuf[ODBC_MAX_SQL_LENGTH];
    char     szAttr[ODBC_MAX_SQL_LENGTH];
    char     *tmpStr = NULL;
    unsigned int i;
    unsigned int whereAttrsCnt = 0;
    unsigned int requiredSqlInputAttrsCnt = 0;

    if(!updWhereAttrs)
        return VSAA_INTERNAL_ERROR;

    *updWhereAttrs = NULL;

    if(sqlcommand == NULL || !*sqlcommand)
        return VSAA_SUCCESS;

    /* trim leading space */

    while(isspace(*sqlcommand)) sqlcommand++;
   
    /* 
        SQL should starts with " followed by word FROM
    */

    if(sqlcommand[0] != '"') 
        return VSAA_ODBC_ERR_CFG_SQL;
    else {
        sqlcommand ++;
    }

    if(VSAAUTIL_StrnCaseCmp(sqlcommand, "WHERE", strlen("WHERE")))
        return VSAA_ODBC_ERR_CFG_SQL;
    else
        sqlcommand += strlen("WHERE");

    while(isspace(*sqlcommand)) sqlcommand++;
           
    /************************************/
    /* Find TBD fields in where clause  */
    /************************************/       

    /* 
        The TBD fields are given after "+ in sqlcommand, e.g.,
        ... WHERE attr1='%s' AND attr2='%s'"+attr1fdf+attr2fdf
    */
    
    tmpStr = strstr(sqlcommand, "\"+");
    
    strncpy(szWhereSqlCommand, sqlcommand, tmpStr-sqlcommand);
    szWhereSqlCommand[tmpStr-sqlcommand] = 0;        
    
    sqlcommand = tmpStr+2;
    
    memset(tmpBuf, 0, sizeof(tmpBuf));
    strcpy(tmpBuf, sqlcommand);
    tmpStr = tmpBuf;

    whereAttrsCnt = 0;
    memset(szAttr, 0, sizeof(szAttr));
    do {
        while(isspace(*tmpStr)) tmpStr++;
        strcpy(szAttr, tmpStr);
        tmpStr = szAttr;
        while(*tmpStr && *tmpStr != '+') tmpStr ++;
        if(*tmpStr) {
            *tmpStr = 0;
            tmpStr ++;
        }
        i = strlen(szAttr)-1;
        while(i>=0 && isspace(szAttr[i])) { szAttr[i] = 0; i--; }
        if(szAttr[0]) {
            VSAAUTIL_AppendCfgAttrEntry(updWhereAttrs, szAttr);            
            whereAttrsCnt ++;
        }
    } while (*tmpStr);
    
    requiredSqlInputAttrsCnt = 0;
    tmpStr = szWhereSqlCommand;
    do {
        tmpStr = strstr(tmpStr, "%s");
        if(tmpStr) {
            requiredSqlInputAttrsCnt ++;
            tmpStr += 2;
        }
    } while(tmpStr && *tmpStr);

    if(requiredSqlInputAttrsCnt != whereAttrsCnt) {
        VSAAUTIL_FreeCfgAttrList(*updWhereAttrs);
        
        *updWhereAttrs = NULL;
        return VSAA_ODBC_ERR_CFG_SQL;
    }

    return VSAA_SUCCESS;
}

VSAA_STATUS 
ODBC_LogError(VSAA_STATUS status, const char* msg)
{
    VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "Error 0x%x: %s", status, msg?msg:"Unknown error");

    return status;
}

VSAA_STATUS 
ODBC_PopulateUpdateSQLStatement(
    char            **ppszSql, 
    const VSAA_NAME userInput[])
{
    const char*  pszUserInputValue = NULL;
    char*        pszFormatString;
    char         szSQLAfterWildChar[ODBC_MAX_SQL_LENGTH]=""; /* part of gODBCCfg.whereSqlCommand */
    char         *sql = NULL;
    const char   *t_xid;
    
    VSAACfgAttrList* tmpMatchAttrs = gODBCCfg.updWhereAttrListPtr;
    t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);

    if(!ppszSql) {
        return VSAA_INTERNAL_ERROR;
    }

    *ppszSql = NULL;

    sql = (char *)VSAAUTIL_Strdup(gODBCCfg.whereSqlCommand);
    if(!sql) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "Out of memory");
        return VSAA_OUT_OF_MEMORY;
    }
    
    while(tmpMatchAttrs != NULL) {
        pszUserInputValue = VSAAUTIL_FindUserInputValue(tmpMatchAttrs->pszValue, strlen(tmpMatchAttrs->pszValue), userInput);
        pszFormatString = strstr(sql, "%s");
        if(pszUserInputValue != NULL && pszFormatString != NULL) {
            strcpy(szSQLAfterWildChar, pszFormatString+2);
            *pszFormatString = 0;
            sql = (char *)VSAAUTIL_Realloc(sql, strlen(sql)+strlen(pszUserInputValue)+strlen(szSQLAfterWildChar)+1);
            if(!sql) {
                VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "Out of memory");
                return VSAA_OUT_OF_MEMORY;
            }
            strcat(sql, pszUserInputValue);
            strcat(sql, szSQLAfterWildChar);            
        } else {
            return VSAA_ERR_INVALID_DATA;
        }

        tmpMatchAttrs = tmpMatchAttrs->next;
    }

    *ppszSql = sql;

    VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, t_xid, (char *) "ODBC_PopulateWhereSQLStatement() returns: %s", sql);

    return VSAA_SUCCESS;
}

/* build database connection */

VSAA_STATUS
ODBC_InitDb()
{
  /* dbErrDesc and dbId are global variables, they should be synchronized */
  
  if ( *(gODBCCfg.autoAuthDatabase) ) {
    if (!ODBCOpenConnection(dbErrDesc, &autoAuthDbId, gODBCCfg.autoAuthDatabase, gODBCCfg.autoAuthUsername, gODBCCfg.autoAuthPassword))
    {
      VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "Failed to open an AutoAuth database connection to %s. Verify username and password as specified by %s and %s",
        gODBCCfg.autoAuthDatabase, ODBC_AUTOAUTH_CFG_LOGIN_NAME, ODBC_AUTOAUTH_CFG_LOGIN_PWD);
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, dbErrDesc);
      return VSAA_ODBC_ERR_OPEN_CONNECTION;
    }
    
    if (!ODBCOpenCursor(dbErrDesc, &autoAuthDbCursor, autoAuthDbId))
    {
      VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "Failed to open an AutoAuth database cursor to %s. Verify username and password as specified by %s and %s",
        gODBCCfg.autoAuthDatabase, ODBC_AUTOAUTH_CFG_LOGIN_NAME, ODBC_AUTOAUTH_CFG_LOGIN_PWD);
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, dbErrDesc);
      ODBCCloseConnection(dbErrDesc, &autoAuthDbId);	
      return VSAA_ODBC_ERR_OPEN_CURSOR;
    }
  }

  if ( *(gODBCCfg.recoverDatabase) ) {
    if (!ODBCOpenConnection(dbErrDesc, &recoverDbId, gODBCCfg.recoverDatabase, gODBCCfg.recoverUsername, gODBCCfg.recoverPassword))
    {
      VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "Failed to open the recover database connection to %s. Verify username and password specified by %s and %s",
        gODBCCfg.recoverDatabase, ODBC_RECOVER_CFG_LOGIN_NAME, ODBC_RECOVER_CFG_LOGIN_PWD);
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, dbErrDesc);
      return VSAA_ODBC_ERR_OPEN_CONNECTION;
    }
    
    if (!ODBCOpenCursor(dbErrDesc, &recoverDbCursor, recoverDbId))
    {
      VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "Failed to open a recover database cursor to %s. Verify username and password specified by %s and %s",
        gODBCCfg.recoverDatabase, ODBC_RECOVER_CFG_LOGIN_NAME, ODBC_RECOVER_CFG_LOGIN_PWD);
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, dbErrDesc);
      ODBCCloseConnection(dbErrDesc, &recoverDbId);	
      return VSAA_ODBC_ERR_OPEN_CURSOR;
    }
  }
  
  return VSAA_SUCCESS;
}

/* clean up database connection and cursor */
 
void ODBC_CleanUpDb(void)
{
  if ( autoAuthDbId != 0 ){
    ODBCCloseCursor(dbErrDesc, &autoAuthDbCursor);
    ODBCCloseConnection (dbErrDesc, &autoAuthDbId);	
    autoAuthDbId = 0;
    autoAuthDbCursor = 0;
  }
  
  if ( recoverDbId != 0 ){
    ODBCCloseCursor(dbErrDesc, &recoverDbCursor);
    ODBCCloseConnection (dbErrDesc, &recoverDbId);	
    recoverDbId = 0;
    recoverDbCursor = 0;
  }
}

/* set default field values for a given ODBCCfg structure */

void  ODBC_SetDefaultCfg(ODBCCfg* pODBCCfg)
{
    ODBC_TRACE("ODBC_SetDefaultCfg()");
    
    autoAuthDbId = 0;
    autoAuthDbCursor = 0;
    recoverDbId = 0;
    recoverDbCursor = 0;

    pODBCCfg->autoAuthDatabase[0] = 0;
    pODBCCfg->autoAuthUsername[0] = 0;
    pODBCCfg->autoAuthPassword[0] = 0;
    
    pODBCCfg->recoverDatabase[0] = 0;
    pODBCCfg->recoverUsername[0] = 0;
    pODBCCfg->recoverPassword[0] = 0;
    
    pODBCCfg->disableCleanFromWhereSqlCommand[0] = 0;
    pODBCCfg->disableCleanUpdateWhereSqlCommand[0] = 0;
    
    pODBCCfg->fromWhereSqlCommand[0] = 0;
    pODBCCfg->fromSqlCommand[0] = 0;
    pODBCCfg->whereSqlCommand[0] = 0;
    pODBCCfg->tableNameListPtr = NULL;
    pODBCCfg->whereAttrListPtr = NULL;

    pODBCCfg->updWhereSqlCommand[0] = 0;
    pODBCCfg->updTableName[0] = 0;
    pODBCCfg->updWhereAttrListPtr = NULL;

    pODBCCfg->mapAttrListPtr = NULL;
    pODBCCfg->authAttrListPtr = NULL;
    pODBCCfg->manualAuthAttrListPtr = NULL;
    pODBCCfg->getAttrListPtr = NULL;
    pODBCCfg->setAttrListPtr = NULL;
    pODBCCfg->updAttrListPtr = NULL;	

    pODBCCfg->certAttrName[0] = 0;
    pODBCCfg->certSerialAttrName[0] = 0;
    
    pODBCCfg->certStatusAttrName[0] = 0;
    pODBCCfg->certStatusValid[0] = 0;
    pODBCCfg->certStatusInvalid[0] = 0;
    pODBCCfg->certStatusRevoked[0] = 0;

    pODBCCfg->regAttrListPtr = NULL;
    pODBCCfg->verAttrListPtr = NULL;
    
    pODBCCfg->nLogEnabled = VSAA_FALSE;

    pODBCCfg->nPrePickupProcess = VSAA_FALSE;
    pODBCCfg->nPreRevokeProcess = VSAA_FALSE;
    pODBCCfg->nPreRenewalProcess = VSAA_FALSE;
}

void
ODBC_FreeCfg(ODBCCfg* pODBCCfg)
{
    ODBC_TRACE("ODBC_FreeCfg()");

    if(!pODBCCfg) return;

    VSAAUTIL_FreeCfgNVPairList(pODBCCfg->mapAttrListPtr);
    VSAAUTIL_FreeCfgAttrList(pODBCCfg->verAttrListPtr);
    VSAAUTIL_FreeCfgNVPairList(pODBCCfg->authAttrListPtr);
    VSAAUTIL_FreeCfgAttrList(pODBCCfg->manualAuthAttrListPtr);
    VSAAUTIL_FreeCfgAttrList(pODBCCfg->getAttrListPtr);
    VSAAUTIL_FreeCfgNVPairList(pODBCCfg->setAttrListPtr);
    VSAAUTIL_FreeCfgNVTripleList(pODBCCfg->regAttrListPtr);
    VSAAUTIL_FreeCfgAttrList(pODBCCfg->updAttrListPtr);
    VSAAUTIL_FreeCfgAttrList(pODBCCfg->tableNameListPtr);
    VSAAUTIL_FreeCfgAttrList(pODBCCfg->whereAttrListPtr);

    ODBC_SetDefaultCfg(pODBCCfg);
}

/*** ODBC_ReadConfigFile
 ***
 *** DESCRIPTION
 ***
 *** parse the configuration file 
 ***
 *** ARGUMENTS 
 ***   const char* pszServiceCfgFileName - IN  - configuration file name     
 ***
 *** RETURNS 
 ***   RETCODE - error code (in vsverify.h)
 ***
 ***
 *** REVISION HISTORY
 ***   Date          Author     Desc
 ***   ----          ------     ----
 ***									Oanh	     ?
 ***   Dec 14, 2000   Tom	      read WHERE SQL statement for Update
 ***                          
 ***/
VSAA_STATUS ODBC_ReadConfigFile(const char* pszServiceCfgFileName)
{
    VSAA_STATUS status = VSAA_SUCCESS;
    FILE*       cfgFp;
    char        szLine[MAX_CFG_VALUE_LENGTH];
	char        szOrigLine[MAX_CFG_VALUE_LENGTH];
	char*       pszName = NULL;
	int         i;
    int         toDecryptFlag = VSAA_FALSE;
    char        decryptedString[BUF_MAX_LEN];
    int         decryptedStringLen;
	
    VSAACfgAttrList* valueListPtr = NULL;

    /* open configuration file */

    cfgFp = fopen(pszServiceCfgFileName, "r");
    if (!cfgFp) {
        VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "Could not open file %s to read configuration data.", pszServiceCfgFileName);
        return VSAA_ODBC_ERR_CFG;
    } 

    /* while there are more lines in the config file */


    while((status = VSAAUTIL_ReadEntryLine(szLine, MAX_CFG_VALUE_LENGTH, cfgFp)) == VSAA_SUCCESS && *szLine)
    {
      if (*szLine == CFG_COMMENT_MARK) {
          if ( strstr(szLine, TODECRYPT_LINE) != NULL ) {
            gHasEncryptedLine = VSAA_TRUE;
            toDecryptFlag = VSAA_TRUE;
          }
          continue;
        }


        strcpy(szOrigLine, szLine);        
        
        /* 
            assume each config entry consists of less than MAX_CFG_VALUE_LENGTH 
            characters which might spread several lines.
        */

        i = strlen(szLine);
        if( i == MAX_CFG_VALUE_LENGTH && szLine[i-1] != '\n') {
            status = VSAA_ERR_CFG_FILE_LINE_TOO_LONG;
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,  (char *) "A configuration line was found to be too long (>%ld bytes): %s", MAX_CFG_VALUE_LENGTH, szLine);
            break;
        } else {
            szOrigLine[i-1] = '\0';
        }

        /* 
            the last char will be a newline.  blow it away, and then
            squeeze out the trailing spaces. 
        */

        szLine[i--] = '\0';
        while(isspace(szLine[i])) 
            szLine[i--] = '\0';

        /* find the offset of the first non-space character */
        
        i = 0;		
        while(isspace(szLine[i])) 
            i++;		

        /* allow blank lines in configuration file */

        if(szLine[i] == 0) continue;
        
        /* decrypt the value */
        if ( toDecryptFlag == VSAA_TRUE ) {
          int j = 0;

          /* szLine +i is the beginning of the name
             szLine +i +j is the beginning of the value
            */
          while ( !isspace(szLine[i+j]) ) j++;
          while (  isspace(szLine[i+j]) )  j++;
          memset( decryptedString, 0, BUF_MAX_LEN);
          decryptedStringLen = BUF_MAX_LEN;
          if ( vsaautil_decrypt(szLine + i +j, strlen(szLine + i +j), decryptedString, &decryptedStringLen) != 0 ) {
            VS_Log (VS_LOG_ERROR, __LINE__, __FILE__, NULL,   (char *) "Unable to decrypt line: %s", szOrigLine);
            status = VSAA_LDAP_ERR_CFG;
            break;
          }
          sprintf(szLine +i +j, "%s\n", decryptedString);
          toDecryptFlag = VSAA_FALSE;
        }

        /* split to get name and its value parts */

        pszName = NULL;
        valueListPtr = NULL;
        /* extract from the first non-space character */
        status = VSAAUTIL_ExtractAttrNameValues(&pszName, &valueListPtr, szLine + i);

        if(status != VSAA_SUCCESS) {
            
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "Invalid entry in configuration file:  %s.", szOrigLine);
            break;

        } else if(!pszName) {
            
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "Invalid entry in configuration file:  %s.", szOrigLine);
            if(valueListPtr) VSAAUTIL_FreeCfgAttrList(valueListPtr);
            status = VSAA_ODBC_ERR_CFG;
            break;

        } else {

            /* figure out which name this is */

            i = VSAAUTIL_CountAttr(valueListPtr);

            if(!strcmp(ODBC_AUTOAUTH_CFG_DSN, pszName)) {
                
                if(i == 1)
                    strcpy(gODBCCfg.autoAuthDatabase, valueListPtr->pszValue);                    

            } else if(!strcmp(ODBC_AUTOAUTH_CFG_LOGIN_NAME, pszName)) {
                
                if(i == 1)
                    strcpy(gODBCCfg.autoAuthUsername, valueListPtr->pszValue);

            } else if(!strcmp(ODBC_AUTOAUTH_CFG_LOGIN_PWD, pszName)) {
                
                if(i == 1) 
                    strcpy(gODBCCfg.autoAuthPassword, valueListPtr->pszValue);

            } else if(!strcmp(ODBC_RECOVER_CFG_DSN, pszName)) {
                
                if(i == 1)
                    strcpy(gODBCCfg.recoverDatabase, valueListPtr->pszValue);                    

            } else if(!strcmp(ODBC_RECOVER_CFG_LOGIN_NAME, pszName)) {
                
                if(i == 1)
                    strcpy(gODBCCfg.recoverUsername, valueListPtr->pszValue);

            } else if(!strcmp(ODBC_RECOVER_CFG_LOGIN_PWD, pszName)) {
                
                if(i == 1) 
                    strcpy(gODBCCfg.recoverPassword, valueListPtr->pszValue);

            } else if (!strcmp(ODBC_LOG_LEVEL, pszName)) {

                if(i != 1)                
                    status = VSAA_ODBC_ERR_CFG;                
                else 
                    gODBCCfg.nLogLevel = atoi(valueListPtr->pszValue);             
               

            } else if(!strcmp(ODBC_SQL_FROM_WHERE, pszName)) {
                
                if(i != 1)
                    status = VSAA_ODBC_ERR_CFG;                
                else
                    strcpy(gODBCCfg.fromWhereSqlCommand, valueListPtr->pszValue); 

            } else if(!strcmp(ODBC_DISABLE_CLEAN_SQL_FROM_WHERE, pszName)) {
                
                if(i != 1)
                    strcpy(gODBCCfg.disableCleanFromWhereSqlCommand, "false");
                else
                    strcpy(gODBCCfg.disableCleanFromWhereSqlCommand, valueListPtr->pszValue); 

            } else if(!strcmp(ODBC_SQL_UPDATE_WHERE, pszName)) {
                
                if(i != 1)
                    status = VSAA_ODBC_ERR_CFG;                
                else
                    strcpy(gODBCCfg.updateWhereSqlCommand, valueListPtr->pszValue); 

            } else if(!strcmp(ODBC_DISABLE_CLEAN_SQL_UPDATE_WHERE, pszName)) {
                
                if(i != 1)
                    strcpy(gODBCCfg.disableCleanUpdateWhereSqlCommand, "false");
                else
                    strcpy(gODBCCfg.disableCleanUpdateWhereSqlCommand, valueListPtr->pszValue); 

            }  else if(!strcmp(ODBC_UPDATE_TABLE_NAME, pszName)) {
                
                if(i != 1)
                    status = VSAA_ODBC_ERR_CFG;                
                else
                    strcpy(gODBCCfg.updTableName, valueListPtr->pszValue); 

            }  else if(!strcmp(ODBC_ATTR_CERT_STATUS, pszName)) {
                
                if(i != 1)
                    status = VSAA_ODBC_ERR_CFG;                
                else
                    strcpy(gODBCCfg.certStatusAttrName, valueListPtr->pszValue);                    

            } else if(!strcmp(ODBC_VALUE_CERT_STATUS_VALID, pszName)) {
                
                if(i != 1)
                    status = VSAA_ODBC_ERR_CFG;                
                else
                    strcpy(gODBCCfg.certStatusValid, valueListPtr->pszValue);                    

            } else if(!strcmp(ODBC_VALUE_CERT_STATUS_INVALID, pszName)) {
                
                if(i != 1)
                    status = VSAA_ODBC_ERR_CFG;                
                else
                    strcpy(gODBCCfg.certStatusInvalid, valueListPtr->pszValue);                    

            } else if(!strcmp(ODBC_VALUE_CERT_STATUS_REVOKED, pszName)) {
                
                if(i != 1)
                    status = VSAA_ODBC_ERR_CFG;                
                else
                    strcpy(gODBCCfg.certStatusRevoked, valueListPtr->pszValue);                    

            } else if (!strcmp(ODBC_LOG, pszName)) {
                
                if(i != 1)
                    status = VSAA_ODBC_ERR_CFG;                
                else 
#ifdef WIN32
                    gODBCCfg.nLogEnabled = !strcmp(VSAA_ON, strupr(valueListPtr->pszValue));             
#else
                    gODBCCfg.nLogEnabled = !strcasecmp(VSAA_ON, valueListPtr->pszValue);             
#endif

            } else if (!strcmp(ODBC_ATTR_MAP, pszName)) {
                
                if(i != 2) 
                    status = VSAA_ODBC_ERR_CFG;
                else
                    status = VSAAUTIL_AppendCfgNVPairEntry(&gODBCCfg.mapAttrListPtr, valueListPtr->pszValue, valueListPtr->next->pszValue);

            } else if (!strcmp(ODBC_ATTR_SET, pszName)) {                
                
                if(i != 2) 
                    status = VSAA_ODBC_ERR_CFG;
                else
                    status = VSAAUTIL_AppendCfgNVPairEntry(&gODBCCfg.setAttrListPtr, valueListPtr->pszValue, valueListPtr->next->pszValue);               

            } else if (!strcmp(ODBC_ATTR_VER, pszName)) {                
                
                if(i != 1) 
                    status = VSAA_ODBC_ERR_CFG;
                else
                    status = VSAAUTIL_AppendCfgAttrEntry(&gODBCCfg.verAttrListPtr, valueListPtr->pszValue);                

            } else if (!strcmp(ODBC_ATTR_AUTH, pszName)) {                
                
                if(i != 2) 
                    status = VSAA_ODBC_ERR_CFG;
                else
                    status = VSAAUTIL_AppendCfgNVPairEntry(&gODBCCfg.authAttrListPtr, valueListPtr->pszValue, valueListPtr->next->pszValue);                

            } else if (!strcmp(ODBC_ATTR_MANUAL_AUTH, pszName)) {                
                
                if(i != 1) 
                    status = VSAA_ODBC_ERR_CFG;
                else
                    status = VSAAUTIL_AppendCfgAttrEntry(&gODBCCfg.manualAuthAttrListPtr, valueListPtr->pszValue);

            } else if (!strcmp(ODBC_ATTR_GET, pszName)) {                
                
                if(i != 1) 
                    status = VSAA_ODBC_ERR_CFG;                    
                else
                    status = VSAAUTIL_AppendCfgAttrEntry(&gODBCCfg.getAttrListPtr, valueListPtr->pszValue);                

            } else if (!strcmp(ODBC_PREPICKUP_PROCESS, pszName)) {
                
                if(i != 1)
                    status = VSAA_ODBC_ERR_CFG;                
                else 
#ifdef WIN32
                    gODBCCfg.nPrePickupProcess = !strcmp(VSAA_ON, strupr(valueListPtr->pszValue));             
#else
                    gODBCCfg.nPrePickupProcess = !strcasecmp(VSAA_ON, valueListPtr->pszValue);             
#endif

            } else if (!strcmp(ODBC_PREREVOKE_PROCESS, pszName)) {
                
                if(i != 1)
                    status = VSAA_ODBC_ERR_CFG;                
                else 
#ifdef WIN32
                    gODBCCfg.nPreRevokeProcess = !strcmp(VSAA_ON, strupr(valueListPtr->pszValue));             
#else
                    gODBCCfg.nPreRevokeProcess = !strcasecmp(VSAA_ON, valueListPtr->pszValue);             
#endif

            } else if (!strcmp(ODBC_PRERENEWAL_PROCESS, pszName)) {
                
                if(i != 1)
                    status = VSAA_ODBC_ERR_CFG;                
                else 
#ifdef WIN32
                    gODBCCfg.nPreRenewalProcess = !strcmp(VSAA_ON, strupr(valueListPtr->pszValue));             
#else
                    gODBCCfg.nPreRenewalProcess = !strcasecmp(VSAA_ON, valueListPtr->pszValue);             
#endif

            } else if (!strcmp(ODBC_ATTR_UPD, pszName)) {                
                
                if(i != 1) 
                    status = VSAA_ODBC_ERR_CFG;                    
                else {
                    const char* tmpAttr = VSAAUTIL_FindFDFAttrName(valueListPtr->pszValue, gODBCCfg.mapAttrListPtr);
                    if(tmpAttr && !VSAAUTIL_StrCaseCmp(VSAA_CERT_BASE64, tmpAttr))
                        strcpy(gODBCCfg.certAttrName, valueListPtr->pszValue);
                    else if(tmpAttr && !VSAAUTIL_StrCaseCmp(VSAA_CERT_SERIAL, tmpAttr))
                        strcpy(gODBCCfg.certSerialAttrName, valueListPtr->pszValue);
                    else if(tmpAttr)
                        status = VSAAUTIL_AppendCfgAttrEntry(&gODBCCfg.updAttrListPtr, valueListPtr->pszValue);
                    else {
                        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "Could not find FDF mapping rule for %s", valueListPtr->pszValue);
                        status = VSAA_ODBC_ERR_CFG;
                    }
                }

            } else {                
                
                VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *) "Ignored configuration entry for ODBC setting:  %s", szOrigLine);                

            }            

            if(status != VSAA_SUCCESS) {
                
                VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "Number of fields for configuration entry %s is not correct: %s", pszName, szOrigLine);
            
            }
            
            VSAAUTIL_Free(pszName);
            VSAAUTIL_FreeCfgAttrList(valueListPtr);

            pszName = NULL;
            valueListPtr = NULL;

            if(status != VSAA_SUCCESS) {
                
                break;

            }
        }                       
    }    

    fclose (cfgFp);

    ODBC_TRACE("Called ODBC_ReadConfigFile()");
    
    return status;
}

/*** ODBC_ValidateCfg
 ***
 *** DESCRIPTION
 ***
 *** validate the configuration structure
 ***
 *** ARGUMENTS 
 ***   ODBCCfg* pODBCCfg - IN  - configuration structure after parsing config file       
 ***
 *** RETURNS 
 ***   RETCODE - error code (in vsverify.h)
 ***
 ***
 *** REVISION HISTORY
 ***   Date          Author     Desc
 ***   ----          ------     ----
 ***									Oanh	     ?
 ***   Dec 14, 2000   Tom	      validate Where SQL command for Update
 ***                          
 ***/
VSAA_STATUS 
ODBC_ValidateCfg(ODBCCfg* pODBCCfg)
{
    VSAA_STATUS status = VSAA_SUCCESS;

    ODBC_TRACE("ODBC_ValidateCfg()");

    if(!pODBCCfg) /* should never happen */ 
        return VSAA_SUCCESS;

    if (!*pODBCCfg->autoAuthDatabase && !*pODBCCfg->recoverDatabase) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "Configuration error:  %s and %s were not specified.", 
          ODBC_AUTOAUTH_CFG_DSN, ODBC_RECOVER_CFG_DSN);
        return (ODBC_LogError(VSAA_ODBC_ERR_CFG, "Both AutoAuth and Recovery Database DSN were not specified"));
    }

    if ( *pODBCCfg->autoAuthDatabase ) {
      if(!*pODBCCfg->fromWhereSqlCommand) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "Configuration error:  %s was not specified.", ODBC_SQL_FROM_WHERE);
        return (ODBC_LogError(VSAA_ODBC_ERR_CFG, "SQL was not specified"));    
      } else {

          // Clean SQL clause to protect against SQL injection
          if (VSAAUTIL_StrCaseCmp(pODBCCfg->disableCleanFromWhereSqlCommand, "TRUE") == 0) {
              VS_Log(VS_LOG_WARNING, __LINE__, __FILE__, NULL, (char *) "Configuration warning:  %s = %s", ODBC_DISABLE_CLEAN_SQL_FROM_WHERE, pODBCCfg->disableCleanFromWhereSqlCommand);
          } else {
              int outLen = 0;
              char *cleanFromWhereSqlCommand = NULL;
              if (vsSQLClean(pODBCCfg->fromWhereSqlCommand, NULL, &outLen)) {
                  if ((cleanFromWhereSqlCommand = (char*)malloc(outLen)) == NULL) {
                      status = VSAA_OUT_OF_MEMORY;
                      VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "malloc failed");
                      return (ODBC_LogError(status, "Out of memory"));
                  }
                  vsSQLClean(pODBCCfg->fromWhereSqlCommand, cleanFromWhereSqlCommand, &outLen);
                  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *) "Cleaning %s clause\n[%s] =>\n[%s]", ODBC_SQL_FROM_WHERE, pODBCCfg->fromWhereSqlCommand, cleanFromWhereSqlCommand);
                  strcpy(pODBCCfg->fromWhereSqlCommand, cleanFromWhereSqlCommand);
                  free(cleanFromWhereSqlCommand);
              } else {
                  status = VSAA_ODBC_ERR_CFG_SQL;
                  VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "Invalid SQL configuration %s %s", ODBC_SQL_FROM_WHERE, pODBCCfg->fromWhereSqlCommand);
                  return (ODBC_LogError(status, "Invalid SQL configuration entry"));    
              }
          }

          status = ODBC_ParseFromWhereSqlCommand(
              pODBCCfg->fromSqlCommand,
              pODBCCfg->whereSqlCommand,
              &(pODBCCfg->tableNameListPtr),
              &(pODBCCfg->whereAttrListPtr), 
              pODBCCfg->fromWhereSqlCommand);
          if(status != VSAA_SUCCESS) {
              VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "Invalid SQL configuration %s %s", ODBC_SQL_FROM_WHERE, pODBCCfg->fromWhereSqlCommand);
              return (ODBC_LogError(status, "Invalid SQL configuration entry"));    
          }
      }

      if(!*pODBCCfg->updateWhereSqlCommand) {
          /* warning.  missing ODBC_SQL_UPDATE_WHERE statement for registration */
          VS_Log(VS_LOG_WARNING, __LINE__, __FILE__, NULL, (char *) "Configuration warning:  %s was not specified.", ODBC_SQL_UPDATE_WHERE);
      } else {
          
          // Clean SQL clause to protect against SQL injection
          if (VSAAUTIL_StrCaseCmp(pODBCCfg->disableCleanUpdateWhereSqlCommand, "TRUE") == 0) {
              VS_Log(VS_LOG_WARNING, __LINE__, __FILE__, NULL, (char *) "Configuration warning:  %s = %s", ODBC_DISABLE_CLEAN_SQL_UPDATE_WHERE, pODBCCfg->disableCleanUpdateWhereSqlCommand);
          } else {
              int outLen = 0;
              char *cleanUpdateWhereSqlCommand = NULL;
              if (vsSQLClean(pODBCCfg->updateWhereSqlCommand, NULL, &outLen)) {
                  if ((cleanUpdateWhereSqlCommand = (char*)malloc(outLen)) == NULL) {
                      status = VSAA_OUT_OF_MEMORY;
                      VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "malloc failed");
                      return (ODBC_LogError(status, "Out of memory"));
                  }
                  vsSQLClean(pODBCCfg->updateWhereSqlCommand, cleanUpdateWhereSqlCommand, &outLen);
                  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *) "Cleaning %s clause\n[%s] =>\n[%s]", ODBC_SQL_UPDATE_WHERE, pODBCCfg->updateWhereSqlCommand, cleanUpdateWhereSqlCommand);
                  strcpy(pODBCCfg->updateWhereSqlCommand, cleanUpdateWhereSqlCommand);
                  free(cleanUpdateWhereSqlCommand);
              } else {
                  status = VSAA_ODBC_ERR_CFG_SQL;
                  VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "Invalid SQL configuration %s %s", ODBC_SQL_UPDATE_WHERE, pODBCCfg->updateWhereSqlCommand);
                  return (ODBC_LogError(status, "Invalid SQL configuration entry"));
              }
          }

          status = ODBC_ParseUpdateWhereSqlCommand(
              pODBCCfg->updWhereSqlCommand,						
              &(pODBCCfg->updWhereAttrListPtr), 
              pODBCCfg->updateWhereSqlCommand);
          if(status != VSAA_SUCCESS) {
              VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "Invalid SQL configuration %s %s", ODBC_SQL_UPDATE_WHERE, pODBCCfg->updateWhereSqlCommand);
              return (ODBC_LogError(status, "Invalid SQL configuration entry"));    
          }
      }

      if(!*pODBCCfg->certAttrName) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "Configuration error:  certificate update attribute was not specified.");
        return (ODBC_LogError(VSAA_ODBC_ERR_CFG, "certificate update attribute was not specified."));
      }
      
      if(status == VSAA_SUCCESS) {
        if(!pODBCCfg->mapAttrListPtr) {
          VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL, (char *) "Configuration error:  %s was not specified.", ODBC_ATTR_MAP);
          return (ODBC_LogError(VSAA_ODBC_ERR_CFG, "ODBC MAP rules were not found"));    
        }
        
        /* 
        mapping rules must exist for those table column names specified
        for authentication, update and retrieval
        */
        
        if(
          VSAA_FALSE == ODBC_IsFDFFieldPresent(pODBCCfg->manualAuthAttrListPtr, pODBCCfg->mapAttrListPtr) ||
          VSAA_FALSE == ODBC_IsFDFFieldPresent(pODBCCfg->getAttrListPtr, pODBCCfg->mapAttrListPtr)  ||
          VSAA_FALSE == ODBC_IsFDFFieldPresent(pODBCCfg->updAttrListPtr, pODBCCfg->mapAttrListPtr)
          )
        {
          return (ODBC_LogError(VSAA_ODBC_ERR_CFG, "Mapping entry was missing for specified column names."));            
        }
      }
    }

    return status;
}

VSAA_BOOL
ODBC_IsFDFFieldPresent(
    const VSAACfgAttrList   *attrListPtr, 
    const VSAACfgNVPairList *mapAttrListPtr)
{
    while(attrListPtr != NULL && attrListPtr->pszValue != NULL) {
        if(!VSAAUTIL_FindFDFAttrName(attrListPtr->pszValue, mapAttrListPtr)) {
            VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *)"FDF mapping rule for %s was not found.", attrListPtr->pszValue);
            return VSAA_FALSE;
        }

        attrListPtr = attrListPtr->next;
    }

    return VSAA_TRUE;
}

void
ODBC_PrintCfg()
{
  if ( VS_Log == NULL ) return;
  if ( gHasEncryptedLine ) return;

  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s: %s", ODBC_AUTOAUTH_CFG_DSN, gODBCCfg.autoAuthDatabase);
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s: %s", ODBC_AUTOAUTH_CFG_LOGIN_NAME, gODBCCfg.autoAuthUsername);
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s: %s", ODBC_AUTOAUTH_CFG_LOGIN_PWD, gODBCCfg.autoAuthPassword);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s: %s", ODBC_RECOVER_CFG_DSN, gODBCCfg.recoverDatabase);
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s: %s", ODBC_RECOVER_CFG_LOGIN_NAME, gODBCCfg.recoverUsername);
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s: %s", ODBC_RECOVER_CFG_LOGIN_PWD, gODBCCfg.recoverPassword);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s: %s", ODBC_SQL_FROM_WHERE, gODBCCfg.fromWhereSqlCommand);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s rules: ", ODBC_ATTR_MAP);        
  VSAAODBC_PrintCfgNVPairList(gODBCCfg.mapAttrListPtr);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s rules: ", ODBC_ATTR_AUTH);
  VSAAODBC_PrintCfgNVPairList(gODBCCfg.authAttrListPtr);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s rules: ", ODBC_ATTR_MANUAL_AUTH);
  VSAAODBC_PrintCfgAttrList(gODBCCfg.manualAuthAttrListPtr);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s rules: ", ODBC_ATTR_GET);
  VSAAODBC_PrintCfgAttrList(gODBCCfg.getAttrListPtr);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s rules: ", ODBC_ATTR_SET);
  VSAAODBC_PrintCfgNVPairList(gODBCCfg.setAttrListPtr);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s rules: ", ODBC_ATTR_UPD);
  VSAAODBC_PrintCfgAttrList(gODBCCfg.updAttrListPtr);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s: %s", ODBC_ATTR_CERT_STATUS, gODBCCfg.certStatusAttrName);
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s: %s", ODBC_VALUE_CERT_STATUS_VALID, gODBCCfg.certStatusValid);
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s: %s", ODBC_VALUE_CERT_STATUS_INVALID, gODBCCfg.certStatusInvalid);
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s: %s", ODBC_VALUE_CERT_STATUS_REVOKED, gODBCCfg.certStatusRevoked);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG %s: %s", ODBC_LOG, gODBCCfg.nLogEnabled?"ON":"OFF");
}

char*
ODBC_FindEmailFromCertDN(const VSAA_NAME userInput[])
{
    VSAA_STATUS status = VSAA_SUCCESS;
    char        *pszSrc;
    const char  *emailDefaultDNSearchToken = "Email Address =";
    const char  *pszCertDN;
    char        szEmailAddr[MAX_CFG_VALUE_LENGTH];    
    char        *pszEmailValueEnd = szEmailAddr;
    const char  *t_xid;
    
    ODBC_TRACE("ODBC_FindEmailFromCertDN()");
    t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);

    /* First we need to get the VSAA_CERT_DN from the userInput */

    pszCertDN = VSAAUTIL_FindUserInputValue(VSAA_CERT_DN, strlen(VSAA_CERT_DN), userInput);
    if (NULL == pszCertDN) 
    {		
        /* VSAA_CERT_DN is missing, so return error */

        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "Missing %s.", VSAA_CERT_DN);
        return NULL;
    }

    /* 
        If we get here we have the cert_DN, so parse out the 
        email address.  We are dependent on the following DN format:    
       
            [Organization = SomeCompany <br>Organizational Unit = SomeUnit<br>Common Name = Some Name<br>Email Address = user@foo.bar.com<br>]

    */

    pszSrc = strstr((char*)pszCertDN, (char*)emailDefaultDNSearchToken);
    if (NULL == pszSrc)
    {
        pszSrc = (char *)strstr(pszCertDN, "E=");
        if (NULL == pszSrc) { 
            /* email token is missing */
        
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "Search attribute [%s] or [E=] was not found in certficate DN input: %s.", emailDefaultDNSearchToken, pszCertDN);
            return NULL;
        } else {
            emailDefaultDNSearchToken="E=";
        } 
    }
    pszSrc += strlen(emailDefaultDNSearchToken);
        
    /* 
        Skip the leading space after the token and try to find
        its value. Scan the string for either the end of the line, 
        a '<', or white space.
    */

    while(*pszSrc && isspace(*pszSrc)) pszSrc++;

    memset(szEmailAddr, 0, sizeof(szEmailAddr));
    while(*pszSrc && !isspace(*pszSrc) && *pszSrc != '<' && *pszSrc != ',' )
    {        
        *pszEmailValueEnd++ = *pszSrc++;
    }
    *pszEmailValueEnd = '\0';

    if(szEmailAddr[0] == 0) {
        /* email address is not given from input */        
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid, (char *)  "Value for %s was not valid: %s", emailDefaultDNSearchToken, pszCertDN);
        return NULL;
    }

    return VSAAUTIL_Strdup(szEmailAddr);
}


VSAA_STATUS 
validateAuthenticationDataSource()
{
  RETCODE      rc = 0;
  int          numEntry;
  VSAA_STATUS  status = VSAA_SUCCESS;
  char         sqlCommand[kDB_SQL_COMMAND_MAX_LENGTH];
  
  do {
    if ( (gODBCCfg.autoAuthDatabase)[0] == 0 ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "%s is empty.", ODBC_AUTOAUTH_CFG_DSN);
      status = VSAA_ODBC_ERR_QUERY;
      break;
    }
    // get the common name
    sprintf(sqlCommand, "select count(*) from %s", gODBCCfg.updTableName);
    
    LOCKDB;    
    rc = ODBCSQLExec(dbErrDesc, autoAuthDbId, autoAuthDbCursor, gODBCCfg.autoAuthDatabase, gODBCCfg.autoAuthUsername, 
      gODBCCfg.autoAuthPassword, FT_SELECT, sqlCommand, COL_INTEGER(&numEntry), NULL);
    UNLOCKDB; 
    if ( rc != 0 ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "DB operation failed:%s", dbErrDesc);
      status = VSAA_ODBC_ERR_QUERY;
      break;
    }
  } while (0);
  
  return status; 

}

VSAA_STATUS 
validateRegistrationDataSource()
{
  RETCODE      rc = 0;
  int          numEntry;
  VSAA_STATUS  status = VSAA_SUCCESS;
  char         sqlCommand[kDB_SQL_COMMAND_MAX_LENGTH];
  
  do {
    if ( (gODBCCfg.autoAuthDatabase)[0] == 0 ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "autoAuth DB name is empty.");
      status = VSAA_ODBC_ERR_QUERY;
      break;
    }
    // get the common name
    sprintf(sqlCommand, "select count(*) from %s", gODBCCfg.updTableName);
    
    LOCKDB;    
    rc = ODBCSQLExec(dbErrDesc, autoAuthDbId, autoAuthDbCursor, gODBCCfg.autoAuthDatabase, gODBCCfg.autoAuthUsername, 
      gODBCCfg.autoAuthPassword, FT_SELECT, sqlCommand, COL_INTEGER(&numEntry), NULL);
    UNLOCKDB; 
    if ( rc != 0 ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "DB operation failed:%s", dbErrDesc);
      status = VSAA_ODBC_ERR_QUERY;
      break;
    }
  } while (0);
  
  return status; 

}

VSAA_STATUS 
validateRecoverDataSource()
{
  RETCODE      rc = 0;
  int          numEntry;
  VSAA_STATUS  status = VSAA_SUCCESS;
  char         sqlCommand[kDB_SQL_COMMAND_MAX_LENGTH];
  
  do {
    if ( (gODBCCfg.recoverDatabase)[0] == 0 ){
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "Recover DB name is empty.");
      status = VSAA_KM_ODBC_ERR_QUERY;
      break;
    }
    // get the common name
    sprintf(sqlCommand, "select count(*) from KeyRecovery");
    
    LOCKDB;    
    rc = ODBCSQLExec(dbErrDesc, recoverDbId, recoverDbCursor, gODBCCfg.recoverDatabase, gODBCCfg.recoverUsername, 
      gODBCCfg.recoverPassword, FT_SELECT, sqlCommand, COL_INTEGER(&numEntry), NULL);
    UNLOCKDB; 
    if ( rc != 0 ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "DB operation failed:%s", dbErrDesc);
      status = VSAA_KM_ODBC_ERR_QUERY;
      break;
    }
  } while (0);
  
  return status; 
}

void
VSAAODBC_PrintCfgAttrList( const VSAACfgAttrList *attrListPtr)
{
  int i = 0;
  
  if ( VS_Log == NULL ) return;

  while(attrListPtr && attrListPtr->pszValue) {
    if(i == 0)
      VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG     %s ", attrListPtr->pszValue);
    else
      VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)" %s ", attrListPtr->pszValue);
    
    attrListPtr = attrListPtr->next;
    i++;
  }
}

void
VSAAODBC_PrintCfgNVPairList(const VSAACfgNVPairList *attrListPtr)
{
  if ( VS_Log == NULL ) return;

  while(attrListPtr && attrListPtr->pszName) {
    VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG     %s %s", attrListPtr->pszName, attrListPtr->pszValue);
    attrListPtr = attrListPtr->next;
  }
}

static VSAA_STATUS DoPrePickupProcess(const VSAA_NAME userInput[], VSAA_NAME  **augmentedData)
{
  VSAA_STATUS  status = VSAA_SUCCESS;

  // When you customize this code, you can replace the DoVerifyUser with another function
  status = DoVerifyUser(userInput, augmentedData);

  return status;
}

static VSAA_STATUS DoPreRevokeProcess(const VSAA_NAME userInput[], VSAA_NAME  **augmentedData)
{
  VSAA_STATUS  status = VSAA_SUCCESS;

  // When you customize this code, you can replace the DoVerifyUser with another function
  status = DoVerifyUser(userInput, augmentedData);

  return status;
}

static VSAA_STATUS DoPreRenewProcess(const VSAA_NAME userInput[], VSAA_NAME   **augmentedData)
{
  VSAA_STATUS  status = VSAA_SUCCESS;

  // When you customize this code, you can replace the DoVerifyUser with another function
  status = DoVerifyUser(userInput, augmentedData);

  return status;
}
