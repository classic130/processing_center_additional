/*
 * $Revision: 1.4.2.1 $
 * $Header: /cvsroot/mpki/vsaakm/vsaaodbc/src/vsaaodbcutil.cpp,v 1.4.2.1 2007/08/09 09:40:09 schenna Exp $
 */

/*--------------------------------------------------------------------\
| Copyright (C) VeriSign, Inc. created 1997. All rights reserved.     |
| This is an unpublished work protected as such under copyright law.  |  
| This work contains proprietary, confidential, and trade secret      |
| information of VeriSign, Inc.  Use, disclosure or reproduction      |
| without the expressed written authorization of VeriSign, Inc.       |
| is prohibited.                                                      |
\--------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>

#include "vsaaodbcutil.h"

// the wide char functions used in this file don't actually act on wide char
#ifndef WIN32
#define lstrlen strlen
#define lstrcpy strcpy
#define wsprintf sprintf
#endif

#define MAXPARAMFIELD	64

typedef struct
		{
			HENV 	hEnv;				/* Environment */
			HDBC 	hDbc;				/* Database Connection */
		} DBASETYPE, *DBASEPTR;

typedef struct
		{
			HSTMT		hStmt;			/* SQL Cursor */
			DBASEPTR	DbRec;
			SDWORD		cBId[MAXPARAMFIELD];
		} DCURSORTYPE, *DCURSORPTR;


/*
 *	Macro and structure for FETCHing
 */

static char *szONE 			=	(char*)"1";
static char *szZERO			=	(char*)"0";
static char *szdate			= 	(char*)"%04u/%02u/%02u";
static char *sztime			=	(char*)"%02u:%02u:%02u";
static char *sztimestmp		=	(char*)"%04u/%02u/%02u %02u:%02u:%02u";

typedef struct
		{
			char	 	szColumnName[64];
			char		*szFieldVal;
			SWORD	 	fSqlType;
			UDWORD		precision, dbSize;
			SWORD	 	scale;
			SWORD	 	fNullable;
			SDWORD		cNull;
			int			MaxColWidth;
		}
		DBCOL_TYPE, *DBCOL_PTR;


/*
 * ULIBOdbcError
 *	 Display ODBC Error
 */

static BOOL OdbcError(char *errDesc, HENV henv, HDBC hdbc, HSTMT hstmt, RETCODE ErrCde, char *FuncName)
{
	char  		szSqlState[20];
	RETCODE 	rc;
	SDWORD 		fNativeError;
	SWORD		cbErrorMsg;
	char 		szErrorMsg[SQL_MAX_MESSAGE_LENGTH + 1];

	rc = SQLError(henv, hdbc, hstmt, (UCHAR *) szSqlState, &fNativeError,
					  (UCHAR *) szErrorMsg,
					  SQL_MAX_MESSAGE_LENGTH , &cbErrorMsg);
	if (ODBC_OK(rc))
		wsprintf(errDesc, "Function: %s, Error: %d (%d), State: %s, Desc: %s",
		    FuncName, ErrCde, fNativeError, szSqlState, szErrorMsg);
	else
		wsprintf(errDesc, "Function: %s, Error: %d", FuncName, ErrCde);
	return FALSE;
}

/*
 *  ODBCCloseConnection
 *		Disconnect ODBC Database and free Connection Id in "DbId"
 */

BOOL ODBCCloseConnection (char *errDesc, int *DbId)
{
	DBASEPTR D;

	errDesc[0] = '\0';
	if (*DbId == 0)
		return(TRUE);

	D = (DBASEPTR) *DbId;
	if (D->hDbc)
	{
		SQLDisconnect(D->hDbc);
		SQLFreeConnect(D->hDbc);
	}
	if (D->hEnv)
		SQLFreeEnv(D->hEnv);
	free(D);
	*DbId = 0;
	return(TRUE);
}

/*
 *  ODBCOpenConnection
 *		Connect ODBC Database and return Connection Id in "DbId"
 */

BOOL ODBCOpenConnection (char *errDesc, int *DbId, const char *DBaseName, const char *UserName,
						 const char *PassWord)
{
	RETCODE	 rc;
	DBASEPTR D;
	HENV	 hEnv;
	HDBC	 hDbc;
	UCHAR	 ConnectStr[256];

	errDesc[0] = '\0';
	*DbId = 0;
	D = (DBASEPTR) calloc(sizeof(DBASETYPE), 1);
	if (D == NULL)
	{
		strcpy(errDesc, "Function: ODBCOpenConnection, Error: insufficient memory DBASETYPE");
		return FALSE;
	}
	do
	{
		if ((rc = SQLAllocEnv(&hEnv)) != SQL_SUCCESS)
		{
			OdbcError(errDesc, SQL_NULL_HENV, SQL_NULL_HDBC, SQL_NULL_HSTMT, rc, (char*)"SQLAllocEnv");
			break;
		}
		D->hEnv = hEnv;
		if ((rc = SQLAllocConnect(hEnv, &hDbc)) != SQL_SUCCESS)
		{
			OdbcError(errDesc, hEnv, SQL_NULL_HDBC, SQL_NULL_HSTMT, rc, (char*)"SQLAllocConnect");
			break;
		}
		D->hDbc = hDbc;
		SQLSetConnectOption(hDbc, SQL_LOGIN_TIMEOUT, 5);
		rc = SQLConnect(hDbc, (unsigned char *)DBaseName, SQL_NTS, (unsigned char *)UserName,
			SQL_NTS, (unsigned char *)PassWord, SQL_NTS);
		strcpy((char *)ConnectStr, DBaseName);
		if (!ODBC_OK(rc))
		{
			OdbcError(errDesc, hEnv, hDbc, SQL_NULL_HSTMT, rc, (char*)"SQLConnect");
			break;
		}
		rc = SQL_SUCCESS;
	} while (0);

	*DbId = (int) D;
	if (rc != SQL_SUCCESS)
	{
        char tmpErrDesc[256];
		ODBCCloseConnection (tmpErrDesc, DbId);
		return(FALSE);
	}
	else
		return(TRUE);
}

/*
 *  ODBCCloseCursor
 *		Close a curor to ODBC Database
 */

BOOL ODBCCloseCursor (char *errDesc, int *FdId)
{
	DCURSORPTR C;

	errDesc[0] = '\0';
	if (*FdId)
	{
		C = (DCURSORPTR) *FdId;
 		SQLFreeStmt(C->hStmt, SQL_DROP);
		free(C);
	}
	*FdId = 0;
	return(TRUE);
}

/*
 *  ODBCOpenCursor
 *		Open a curor to ODBC Database and return Cursor Id in "FdId"
 */

BOOL ODBCOpenCursor (char *errDesc, int *FdId, int DbId)
{
	DCURSORPTR	C;
	DBASEPTR	D;
	RETCODE		rc;

	errDesc[0] = '\0';
	*FdId = 0;
	C = (DCURSORPTR) calloc(sizeof(DCURSORTYPE), 1);
	if (C == NULL)
	{
		strcpy(errDesc, "Function: ODBCOpenConnection, Error: insufficient memory DCURSORTYPE");
		return FALSE;
	}
	D = (DBASEPTR) DbId;
	if ((rc = SQLAllocStmt(D->hDbc, &C->hStmt)) != SQL_SUCCESS)
	{
		OdbcError(errDesc, D->hEnv, D->hDbc, SQL_NULL_HSTMT, rc, (char*)"SQLAllocStmt");
		free(C);
		return(FALSE);
	}
	else
	{
		C->DbRec = D;
		*FdId = (int) C;
		return(TRUE);
	}
}

/*
 *
 */

static void ODBCGetFType(SWORD cTyp, SWORD *fTyp, SDWORD *cBId, int Siz)
{
	switch(cTyp)
	{
		case SQL_TINYINT:
		case SQL_SMALLINT:
			*fTyp = SQL_C_USHORT;
			*cBId = 0;
			break;

		case SQL_INTEGER:
		case SQL_BIGINT:
			*fTyp = SQL_C_ULONG;
			*cBId = 0;
			break;

		case SQL_FLOAT:
		case SQL_DOUBLE:
		case SQL_REAL:
			*fTyp = SQL_C_DOUBLE;
			*cBId = 0;
			break;

		case SQL_DATE:
			*fTyp = SQL_C_DATE;
			*cBId = 0;
			break;

		case SQL_TIME:
			*fTyp = SQL_C_TIME;
			*cBId = 0;
			break;

		case SQL_TIMESTAMP:
			*fTyp = SQL_C_TIMESTAMP;
			*cBId = 0;
			break;

		case SQL_BINARY:
		case SQL_VARBINARY:
		case SQL_LONGVARBINARY:
			*fTyp = SQL_C_BINARY;
			*cBId =	Siz;
			break;

		default:
			*fTyp = SQL_C_CHAR;
			*cBId = SQL_NTS;
			break;
	}
}

/*
 *
 */

BOOL ODBCSQLFreeStmt(int FdId)
{
    DCURSORPTR	F = (DCURSORPTR) FdId;

	SQLFreeStmt(F->hStmt, SQL_UNBIND);
	SQLFreeStmt(F->hStmt, SQL_RESET_PARAMS);
	SQLFreeStmt(F->hStmt, SQL_CLOSE);
	return(TRUE);
}

/*** ODBCSQLExec
 ***
 *** DESCRIPTION
 ***
 *** Execute a SQL Command.
 ***
 *** ARGUMENTS 
 ***   char	*errDesc	 - OUT - error description if any  
 ***   int      &DbId		 - IN/OUT - Database id
 ***   int      &DBCursor	 - IN/OUT - Database cursor
 ***   char     *database	 - IN	- database name
 ***   char     *username        - IN - username
 ***   char     *password        - IN - database password
 ***   int	SQLType          - IN - SQL type: select or update
 ***   char     *SQLCommand      - IN - SQL command
 ***
 *** RETURNS 
 ***   RETCODE - the status of executing the SQL query
 ***
 ***
 *** REVISION HISTORY
 ***   Date          Author     Desc
 ***   ----          ------     ----
 ***   ?             Oanh      Created.
 ***   Dec 6, 2000   Tom       if database disconnect, reopen
 ***                           the database connection
 ***/
 
RETCODE ODBCSQLExec(char *errDesc, int &DbId, int &DBCursor, char* database, char *username, 
                    char *password, int SQLType, char *SQLCommand, ...)
{
    int			Siz;
    va_list 	        ap;
    char		*Str, *ColStr;
    SWORD		cTyp, fTyp;
    UWORD		Order;
    RETCODE		rc;
    BOOL		retried = FALSE;

	do {
	        DCURSORPTR F = (DCURSORPTR) DBCursor;

		if (DBCursor == 0)
		{
			rc = -1 ;
			goto ENDDBSQL;
		}

		va_start(ap, SQLCommand);
 
		rc = ODBCSQLFreeStmt(DBCursor);
		if (SQLType == FT_UPDATE)
			rc = SQLPrepare(F->hStmt, (unsigned char *)SQLCommand, SQL_NTS);
		else
			rc = SQLExecDirect(F->hStmt, (unsigned char *)SQLCommand, SQL_NTS);

		if (rc != SQL_SUCCESS)
		{
			OdbcError(errDesc, F->DbRec->hEnv, F->DbRec->hDbc, F->hStmt, rc, (char*)"SQLParse");
			goto ENDDBSQL;
		}    
    				/* Bind all inputs */
		if (SQLType == FT_UPDATE)
		{
			ColStr = SQLCommand;
			Order  = 0;
			while (ODBC_OK(rc) && (ColStr = strchr(ColStr, INPUT_IDENTIFIER)))
			{										/* Search for ? of Input */
				ColStr++;							/* Skip the INPUT_INDENTIFIER */
				Order++;							/* Order Number of INPUT starts from 1 */
				Str  = va_arg(ap, char *);
				Siz  = va_arg(ap, int);   		/* Get the Length */
#ifdef LINUX                    /* short is not supported here in Linux */
                                cTyp = va_arg(ap, int);
#else
				cTyp = va_arg(ap, SWORD);   	/* Get the Field Type */
#endif
				if (Siz == -1 && Str)
					Siz = strlen(Str) + 1;
				ODBCGetFType(cTyp, &fTyp, &F->cBId[Order], Siz);
				if (/* F->cBId[Order] == SQL_NTS && */
					  (Siz == 0 || !Str || !strcmp(Str, NULLDATASTR) || !strcmp(Str, NULLPREFIX)))
				{
					  Siz = 0;
					  Str = NULL;
					  F->cBId[Order] = SQL_NULL_DATA;
				}
				rc = SQLBindParameter(F->hStmt, Order, SQL_PARAM_INPUT, fTyp, cTyp, Siz, 0,
								 				  Str, 0, &F->cBId[Order]);
			}
			if (rc == SQL_SUCCESS)
			{
				rc = SQLExecute(F->hStmt);
				if (rc != SQL_SUCCESS)
					OdbcError(errDesc, F->DbRec->hEnv, F->DbRec->hDbc, F->hStmt, rc, (char*)"SQLExecute");
				else
				{
					SDWORD RowEff;
					SQLRowCount(F->hStmt, &RowEff);
					if (!RowEff)
						rc = SQL_NO_DATA_FOUND;
				}
			}
			else
				OdbcError(errDesc, F->DbRec->hEnv, F->DbRec->hDbc, F->hStmt, rc, (char*)"SQLBindParameter");
		}
    
		else if (SQLType == FT_SELECT)
		{
        			/* Bind all outputs */
   			for (Order = 1, Str = va_arg(ap, char *); Str != NULL && ODBC_OK(rc);
				 Order++,   Str = va_arg(ap, char *))
   			{
				Siz  = va_arg(ap, int);		 	/* Get the Length */
#ifdef LINUX
				cTyp = va_arg(ap, int);   	/* Get the Field Type */
#else
				cTyp = va_arg(ap, SWORD);   	/* Get the Field Type */
#endif
				ODBCGetFType(cTyp, &fTyp, &F->cBId[Order], Siz);
				rc = SQLBindCol(F->hStmt, Order, fTyp, Str, Siz, &F->cBId[Order]);
			}        
			if (rc == SQL_SUCCESS)
			{
				rc = SQLFetch(F->hStmt);
				if (rc != SQL_SUCCESS)
					OdbcError(errDesc, F->DbRec->hEnv, F->DbRec->hDbc, F->hStmt, rc, (char*)"SQLFetch");
			}
			else
				OdbcError(errDesc, F->DbRec->hEnv, F->DbRec->hDbc, F->hStmt, rc, (char*)"SQBindCol");
		}
		else if (SQLType == FT_DIRECT)
		{
			SDWORD *RowEff;

			RowEff  = va_arg(ap, SDWORD *);  	/* Get the Length */
			if (RowEff)
			{
				*RowEff = 0;
				SQLRowCount(F->hStmt, RowEff);
			}
		}
    
ENDDBSQL:    
		va_end(ap);

		if ((rc == SQL_SUCCESS || rc == SQL_NO_DATA_FOUND ||  rc == SQL_NO_DATA)
		    || retried == TRUE)
		  break;

		/* clean up database connection and cursor */
		ODBCCloseCursor(errDesc, &DBCursor);
		ODBCCloseConnection (errDesc, &DbId);	

		/* reopen database connnection */
		if (!(ODBCOpenConnection(errDesc, &DbId, database, username, password)))
			break;
		
		if (!(ODBCOpenCursor(errDesc, &DBCursor, DbId)))
		{
			ODBCCloseConnection(errDesc, &DbId);	
			break;
		}
		retried = TRUE;
	} while (rc != SQL_SUCCESS);

  if (rc == SQL_SUCCESS)
		return(0);
	else
		return(rc);
    
} 

/*
 *  ODBCSQLExecWithLength
 *		Execute a SQL Command.
 */
 
RETCODE ODBCSQLExecWithLength(char *errDesc, int FdId, int SQLType, char *SQLCommand, ...)
{
    int			l;
	SDWORD		*Siz;
    DCURSORPTR	F = (DCURSORPTR) FdId;
    va_list 	ap;
    char		*Str, *ColStr;
	SWORD		cTyp, fTyp;
	UWORD		Order;
	RETCODE		rc;
    
	errDesc[0] = '\0';
    va_start(ap, SQLCommand);
    
	ODBCSQLFreeStmt(FdId);
	if (SQLType == FT_UPDATE)
	    rc = SQLPrepare(F->hStmt, (unsigned char *)SQLCommand, SQL_NTS);
	else
	    rc = SQLExecDirect(F->hStmt, (unsigned char *)SQLCommand, SQL_NTS);

	if (rc != SQL_SUCCESS)
    {
		OdbcError(errDesc, F->DbRec->hEnv, F->DbRec->hDbc, F->hStmt, rc, (char*)"SQLParse");
        goto ENDDBSQL;
    }    
    			/* Bind all inputs */
	if (SQLType == FT_UPDATE)
	{
		ColStr = SQLCommand;
		Order  = 0;
		while (ODBC_OK(rc) && (ColStr = strchr(ColStr, INPUT_IDENTIFIER)))
		{										/* Search for ? of Input */
			ColStr++;							/* Skip the INPUT_INDENTIFIER */
			Order++;							/* Order Number of INPUT starts from 1 */
			Str  = va_arg(ap, char *);
			Siz  = va_arg(ap, SDWORD *);  		/* Get the Length */
			l    = (int) *Siz;
#ifdef LINUX
			cTyp = va_arg(ap, int);   	/* Get the Field Type */
#else
			cTyp = va_arg(ap, SWORD);   	/* Get the Field Type */
#endif
			if (l == -1 && Str)
				l = strlen(Str) + 1;
			ODBCGetFType(cTyp, &fTyp, Siz, l);
			if (/* F->cBId[Order] == SQL_NTS && */
				  (l == 0 ||!Str || !strcmp(Str, NULLDATASTR) || !strcmp(Str, NULLPREFIX)))
			{
				  l    = 0;
				  Str  = NULL;
				  *Siz = SQL_NULL_DATA;
			}
			rc = SQLBindParameter(F->hStmt, Order, SQL_PARAM_INPUT, fTyp, cTyp, l, 0,
								 			  Str, 0, Siz);
		}
		if (ODBC_OK(rc))
		{
			rc = SQLExecute(F->hStmt);
			if (!ODBC_OK(rc))
				OdbcError(errDesc, F->DbRec->hEnv, F->DbRec->hDbc, F->hStmt, rc, (char*)"SQLExecute");
			else
			{
				SDWORD RowEff;
				SQLRowCount(F->hStmt, &RowEff);
				if (!RowEff)
					rc = SQL_NO_DATA_FOUND;
			}
		}
		else
			OdbcError(errDesc, F->DbRec->hEnv, F->DbRec->hDbc, F->hStmt, rc, (char*)"SQLBindParameter");

    }
    
	else if (SQLType == FT_SELECT)
	{
        		/* Bind all outputs */
   		for (Order = 1, Str = va_arg(ap, char *); Str != NULL && ODBC_OK(rc);
			 Order++,   Str = va_arg(ap, char *))
   		{
			Siz  = va_arg(ap, SDWORD *);  	/* Get the Length */
			l    = (int) *Siz;
#ifdef LINUX
			cTyp = va_arg(ap, int);   	/* Get the Field Type */
#else
			cTyp = va_arg(ap, SWORD);   	/* Get the Field Type */
#endif
			ODBCGetFType(cTyp, &fTyp, Siz, l);
			rc = SQLBindCol(F->hStmt, Order, fTyp, Str, l, Siz);
		}        
		if (ODBC_OK(rc))
		{
			rc = SQLFetch(F->hStmt);
			if (rc == SQL_ERROR)
				OdbcError(errDesc, F->DbRec->hEnv, F->DbRec->hDbc, F->hStmt, rc, (char*)"SQLFetch");
		}
		else
			OdbcError(errDesc, F->DbRec->hEnv, F->DbRec->hDbc, F->hStmt, rc, (char*)"SQBindCol");
    }
    
ENDDBSQL:    
    va_end(ap);
    if (ODBC_OK(rc))
		return(0);
	else
		return(rc);
    
} 

/*
 *  ODBCSQLExecWithArgs
 *		Execute a SQL Command.
 */
 
RETCODE ODBCSQLExecWithArgs(char *errDesc, int FdId, int SQLType, char *SQLCommand, ODBCFIELDPTR Tab)
{
    int			Siz, Idx = 0;
    DCURSORPTR	F = (DCURSORPTR) FdId;
    char		*Str, *ColStr;
	SWORD		cTyp, fTyp;
	UWORD		Order;
	RETCODE		rc;
    
	errDesc[0] = '\0';
	ODBCSQLFreeStmt(FdId);
	if (SQLType == FT_UPDATE)
	    rc = SQLPrepare(F->hStmt, (unsigned char *)SQLCommand, SQL_NTS);
	else
	    rc = SQLExecDirect(F->hStmt, (unsigned char *)SQLCommand, SQL_NTS);

	if (rc != SQL_SUCCESS)
    {
		OdbcError(errDesc, F->DbRec->hEnv, F->DbRec->hDbc, F->hStmt, rc, (char*)"SQLParse");
        goto ENDDBSQL;
    }    
    			/* Bind all inputs */
	if (SQLType == FT_UPDATE)
	{
		ColStr = SQLCommand;
		Order  = 0;
		while (ODBC_OK(rc) && (ColStr = strchr(ColStr, INPUT_IDENTIFIER)))
		{										/* Search for ? of Input */
			ColStr++;							/* Skip the INPUT_INDENTIFIER */
			Order++;							/* Order Number of INPUT starts from 1 */
			Str  = Tab[Idx].Str;
			Siz  = Tab[Idx].Siz;	  			/* Get the Length */
			cTyp = Tab[Idx++].cTyp;		  		/* Get the Field Type */
			if (Siz == -1 && Str)
				Siz = strlen(Str) + 1;
			ODBCGetFType(cTyp, &fTyp, &F->cBId[Order], Siz);
			if (/* F->cBId[Order] == SQL_NTS && */
				  (Siz == 0 || !Str || !strcmp(Str, NULLDATASTR) || !strcmp(Str, NULLPREFIX)))
			{
				  Siz = 0;
				  Str = NULL;
				  F->cBId[Order] = SQL_NULL_DATA;
			}
			rc = SQLBindParameter(F->hStmt, Order, SQL_PARAM_INPUT, fTyp, cTyp, Siz, 0,
								 			  Str, 0, &F->cBId[Order]);
		}
		if (ODBC_OK(rc))
		{
			rc = SQLExecute(F->hStmt);
			if (!ODBC_OK(rc))
				OdbcError(errDesc, F->DbRec->hEnv, F->DbRec->hDbc, F->hStmt, rc, (char*)"SQLExecute");
			else
			{
				SDWORD RowEff;
				SQLRowCount(F->hStmt, &RowEff);
				if (!RowEff)
					rc = SQL_NO_DATA_FOUND;
			}
		}
		else
			OdbcError(errDesc, F->DbRec->hEnv, F->DbRec->hDbc, F->hStmt, rc, (char*)"SQLBindParameter");
    }
    
	else if (SQLType == FT_SELECT)
	{
        		/* Bind all outputs */
   		for (Order = 1, Str = Tab[Idx].Str; Str != NULL && ODBC_OK(rc);
			 Order++,   Str = Tab[Idx].Str)
   		{
			Siz  = Tab[Idx].Siz;		 	/* Get the Length */
			cTyp = Tab[Idx++].cTyp;		  	/* Get the Field Type */
			ODBCGetFType(cTyp, &fTyp, &F->cBId[Order], Siz);
			rc = SQLBindCol(F->hStmt, Order, fTyp, Str, Siz, &F->cBId[Order]);
		}        
		if (ODBC_OK(rc))
		{
			rc = SQLFetch(F->hStmt);
			if (rc == SQL_ERROR)
				OdbcError(errDesc, F->DbRec->hEnv, F->DbRec->hDbc, F->hStmt, rc, (char*)"SQLFetch");
		}
		else
			OdbcError(errDesc, F->DbRec->hEnv, F->DbRec->hDbc, F->hStmt, rc, (char*)"SQBindCol");
    }
    
ENDDBSQL:    
    if (ODBC_OK(rc))
		return(0);
	else
		return(rc);
    
} 

/*
 *  ODBCSQLFetch
 *		Fetch a SQL Command.
 */
 
RETCODE ODBCSQLFetch(char *errDesc, int FdId)
{
    DCURSORPTR	F = (DCURSORPTR) FdId;
	RETCODE		rc;

	errDesc[0] = '\0';
	rc = SQLFetch(F->hStmt);
	if (rc == SQL_ERROR)
		OdbcError(errDesc, F->DbRec->hEnv, F->DbRec->hDbc, F->hStmt, rc, (char*)"SQLFetch");
    if (ODBC_OK(rc))
		return(0);
	else
		return(rc);
}

/*
 *  ODBCSetConnectOption
 *		Set Connect Option
 */

RETCODE ODBCSetConnectOption(char *errDesc, int DbId, int Opt, int Val)
{
	DBASEPTR	D;
	RETCODE		rc;
	
	errDesc[0] = '\0';
	D = (DBASEPTR) DbId;
	rc = SQLSetConnectOption(D->hDbc, (UWORD) Opt, (UDWORD) Val);
	if (rc == SQL_ERROR)
		OdbcError(errDesc, D->hEnv, D->hDbc, SQL_NULL_HSTMT, rc, (char*)"SQLSetConnectOption");
    if (ODBC_OK(rc))
		return(0);
	else
		return(rc);
}

/*
 *  ODBCCommit
 */

RETCODE ODBCCommit(char *errDesc, int DbId)
{
	DBASEPTR	D;
	RETCODE		rc;
	
	D = (DBASEPTR) DbId;
	rc = SQLTransact(D->hEnv, D->hDbc, SQL_COMMIT);
	if (rc == SQL_ERROR)
		OdbcError(errDesc, D->hEnv, D->hDbc, SQL_NULL_HSTMT, rc, (char*)"SQLCommit");
    if (ODBC_OK(rc))
		return(0);
	else
		return(rc);
}

/*
 *  ODBCRollback
 */

RETCODE ODBCRollback(char *errDesc, int DbId)
{
	DBASEPTR	D;
	RETCODE		rc;
	
	D = (DBASEPTR) DbId;
	rc = SQLTransact(D->hEnv, D->hDbc, SQL_ROLLBACK);
	if (rc == SQL_ERROR)
		OdbcError(errDesc, D->hEnv, D->hDbc, SQL_NULL_HSTMT, rc, (char*)"SQLRollback");
    if (ODBC_OK(rc))
		return(0);
	else
		return(rc);
}

/*
 *
 */
  
BOOL ODBCError(char *errDesc, int FdId, RETCODE ErrCde, char *FuncName)
{
    DCURSORPTR	F = (DCURSORPTR) FdId;
	return OdbcError(errDesc, F->DbRec->hEnv, F->DbRec->hDbc, F->hStmt, ErrCde, FuncName);
}

/*
 *	ODBCCursor
 */

HSTMT ODBCCursor(int FdId)
{
    DCURSORPTR	F;
    
    F = (DCURSORPTR) FdId;
	return(F->hStmt);
}

//*------------------------------------------------------------------------
//| BinToChar:
//|   Takes a string and converts to its hexidecimal equivalent
//*------------------------------------------------------------------------

static void BinToChar(LPSTR outstr, LPSTR instr, SDWORD count)
{
	UCHAR	uletter;
	LPSTR istr=instr;
	LPSTR ostr=outstr;
	
	while(count--) {
		uletter = (*instr & 0xF0) >> 4;					// High nibble
		if(uletter <= 9)
			*ostr++ = uletter + '0';
		else
			*ostr++ = 'a' + (uletter - 10);
		uletter = *instr++ & 0x0F;
		if(uletter <= 9)
			*ostr++ = uletter + '0';
		else
			*ostr++ = 'a' + (uletter - 10);
		}
	*ostr = '\0';
}

//*------------------------------------------------------------------------
//| CheckDisplayMode:
//|	This function looks through a string for the count specified, then
//|		changes any x"00" to a period so it can be displayed.
//| Parms:
//|	strin			- String coming in
//|	cbin			- Byte count of incoming string
//|	strout		- Output string
//*------------------------------------------------------------------------
static void CheckDisplayMode(LPSTR strin, SDWORD cbin, LPSTR strout)
{
	SDWORD		dex,max=cbin;
	LPSTR		str=strout;

	if(cbin < 0)
		max = lstrlen(strin);
	memcpy(strout, strin, (size_t)max);
	for(dex=0; dex<cbin; dex++, str++) 
		if(!*str)
			*str = '.';
} 	

//*------------------------------------------------------------------------
//| ConvertSqlTypeToChar:
//|	This function will convert the value passed in to it's character equivalent.
//| Parms:
//|	in			rs					  	Pointer to results set
//|	in			inbuff					Input buffer
//|	in			outbuff					Output buffer
//|	in			rtnd				  	Returned bytes from SQLGetData
//| Returns:
//|	Nothing.
//*------------------------------------------------------------------------
void ConvertSqlTypeToChar(DBCOL_PTR rs, LPSTR inbuff, LPSTR outbuff, SDWORD rtnd)
{
	LPSTR					tmpstr;
	SWORD FAR *				tmpsword;
	SDWORD FAR *			tmpsdword;
	SFLOAT FAR * 			tmpsfloat;
	SDOUBLE FAR * 			tmpsdouble;
	DATE_STRUCT FAR * 		tmpdate;
	TIME_STRUCT FAR * 		tmptime;
	TIMESTAMP_STRUCT FAR *	tmptimestmp;

	*outbuff = '\0';
	switch(rs->fSqlType) {
		//
		//	Look for any non-displayable characters and change them to periods
		//
		case SQL_CHAR:
		case SQL_VARCHAR:
		case SQL_LONGVARCHAR:
			CheckDisplayMode((LPSTR)inbuff, rtnd, outbuff);
			tmpstr = outbuff + rtnd;
			*tmpstr = '\0';
			break;

		case SQL_BINARY:
		case SQL_VARBINARY:
		case SQL_LONGVARBINARY:
			lstrcpy(outbuff, "0x");
			BinToChar(outbuff+2, (LPSTR)inbuff, rtnd);
			break;

		case SQL_TINYINT:
		case SQL_SMALLINT:
			tmpsword = (SWORD FAR *)inbuff;
			wsprintf(outbuff, "%d", *tmpsword);
			break;

		case SQL_INTEGER:
		case SQL_BIGINT:
			tmpsdword = (SDWORD FAR *)inbuff;
			wsprintf(outbuff, "%ld", *tmpsdword);
			break;

		case SQL_FLOAT:
		case SQL_DOUBLE:
			tmpsdouble = (SDOUBLE FAR *)inbuff;
			sprintf(outbuff, "%-.0f", *tmpsdouble);
			break;

		case SQL_REAL:
			tmpsfloat = (SFLOAT FAR *)inbuff;
			sprintf(outbuff, "%-.0f", *tmpsfloat);
			break;

		case SQL_BIT:
			tmpsword = (SWORD FAR *)inbuff;
			lstrcpy(outbuff, (*tmpsword) ? (LPSTR)szONE : (LPSTR)szZERO);
			break;

		case SQL_DECIMAL:
		case SQL_NUMERIC:
			lstrcpy(outbuff, inbuff);
			break;

		case SQL_DATE:
			tmpdate = (DATE_STRUCT FAR *)inbuff;
			wsprintf(outbuff, szdate, tmpdate->year, tmpdate->month, tmpdate->day);
			break;

		case SQL_TIME:
			tmptime= (TIME_STRUCT FAR *)inbuff;
			wsprintf(outbuff, sztime, tmptime->hour, tmptime->minute, tmptime->second);
			break;

		case SQL_TIMESTAMP:
			tmptimestmp = (TIMESTAMP_STRUCT FAR *)inbuff;
			wsprintf(outbuff, sztimestmp, tmptimestmp->year, tmptimestmp->month,
				tmptimestmp->day, tmptimestmp->hour, tmptimestmp->minute,
				tmptimestmp->second);
			break;
		}

	return;
}


/*
 *
 */
TIMESTAMP_STRUCT *SQL_SysDate(TIMESTAMP_STRUCT *D)
{
	static TIMESTAMP_STRUCT Date;
	time_t      SysGTime;
	struct tm	*SysTTime;

	if (D == NULL)
		D = &Date;
	SysGTime = time(NULL);
	SysTTime = (struct tm *) localtime(&SysGTime);
	D->year	= SysTTime->tm_year + 1900;
	D->month= SysTTime->tm_mon + 1;
	D->day	= SysTTime->tm_mday;

	D->hour	= SysTTime->tm_hour;
	D->minute	= SysTTime->tm_min;
	D->second	= SysTTime->tm_sec;
	D->fraction = 0;
	return(D);
}

