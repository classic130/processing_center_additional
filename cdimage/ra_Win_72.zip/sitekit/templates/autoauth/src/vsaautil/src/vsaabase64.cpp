/*
 * $Revision: 1.4.2.1 $
 * $Header: /cvsroot/mpki/vsaakm/vsaautil/src/vsaabase64.cpp,v 1.4.2.1 2007/09/21 08:57:44 schenna Exp $
 */

/*-----------------------------------------------------------------------\ 
| Copyright (C) VeriSign, Inc. created 1996, 1997. All rights reserved.  |
| This is an unpublished work protected as such under copyright law.     |
| This work contains proprietary, confidential, and trade secret         |
| information of VeriSign, Inc.  Use, disclosure or reproduction without |
| the expressed written authorization of VeriSign, Inc.  is prohibited.  |
\-----------------------------------------------------------------------*/

static char *_base64_C = (char *) "$Id: vsaabase64.cpp,v 1.4.2.1 2007/09/21 08:57:44 schenna Exp $" ;


#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <malloc.h>
#include <memory.h>
#include <string.h>
#include <sys/types.h>
#include "vsaabase64.h"
#include "vslog.h"

#define eUTIL_BASE64_NOT_ENOUGH_BUFFER_SPACE   -1
#define eUTIL_DECODE_BASE64_INVALID_CHAR	   -2
#define eUTIL_OUT_OF_MEMORY                    -3

#define CR	0x0d	/* \r */
#define LF	0x0a	/* \n */
#define LINELENGTH	64

char table[] =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

static int EncodeBase64(ITEM *output, ITEM input);
static int DecodeBase64(ITEM *output, ITEM input);
void DisplayHex(char *Msg, unsigned char *buffer, int size);

int Base64Alloc (ITEM *base64data, ITEM input)
{
  int status = 0;
  int num;

  num = (input.len / 3 + 1) * 4;
  base64data->len = num + (num / LINELENGTH + 1) * 2 + 3;
  base64data->data = (unsigned char *) malloc(base64data->len+1);
  if(!base64data->data) {
      VSLOGERROR((char *)"Out of memory");
      return eUTIL_OUT_OF_MEMORY;    
  }
  memset(base64data->data, 0, base64data->len+1);
  status = EncodeBase64(base64data, input);
  return(status);
}

static int EncodeBase64(ITEM *output, ITEM input)
{
  unsigned char indices[4];	/* Four byte out stream indices */
  unsigned int fourbyte = 0;	/* Constructed 4 byte integer */
  unsigned char c;
  int i_idx = 0, o_idx = 0;
  int pos3 = 0;		/* current 3 byte position */
  int numchar_line = 0;	/* number chars on current line */
  int i;

  for (; i_idx < (int)input.len; i_idx++) {
    c = input.data[i_idx];

    if (pos3 < 3) {
      pos3++;
      fourbyte <<= 8;
      fourbyte += c;
      continue;
    }

    for (i = 0; i < 4; i++) {
      indices[i] = fourbyte & 0x3f;
      fourbyte >>= 6;
    }

    for (i = 3; i >= 0; i--) {
      output->data[o_idx] = table[indices[i]];
      o_idx++;
    }

    numchar_line += 4;
    fourbyte = c;
    pos3 = 1;

    if (numchar_line >= LINELENGTH) {
      output->data[o_idx] = CR;
      o_idx++;
      output->data[o_idx] = LF;
      o_idx++;
      numchar_line = 0;
    }
  }
  if (pos3 > 0) {
    if (pos3 == 1)
      fourbyte <<= 16;
    else if (pos3 == 2) 
      fourbyte <<= 8;

    for (i = 0; i < 4; i++) {
      indices[i] = fourbyte & 0x3f;
      fourbyte >>= 6;
    }

    if (pos3 == 1)
      indices[0] = indices[1] = 64;
    else if (pos3 == 2)
      indices[0] = 64;

    for (i = 3; i >= 0; i--) {
      output->data[o_idx] = table[indices[i]];
      o_idx++;
    }
  }
  output->data[o_idx] = CR;
  o_idx++;
  output->data[o_idx] = LF;
  o_idx++;

  if (o_idx <= (int)output->len) {
    output->len = o_idx;
  }
  else {  
    VSAA_Log(VS_LOG_CRITICAL, __LINE__, __FILE__,NULL, (char *) "EncodeBase64(): size of encoded data (%d) is larger than buffer allocated (%d)", o_idx, output->len);
    return eUTIL_BASE64_NOT_ENOUGH_BUFFER_SPACE;
  }
  return 0;
}

int UnBase64Alloc (ITEM *data, ITEM base64Block)
{
  int status = 0;

  data->len = (base64Block.len / 4 + 2) * 3 + 3;
  data->data = (unsigned char *) malloc(data->len);
  if(!data->data) {
      VSLOGERROR((char *) "Out of memory");
      return eUTIL_OUT_OF_MEMORY;    
  }
  status = DecodeBase64(data, base64Block);
  return(status);
}

static int DecodeBase64(ITEM *output, ITEM input)
{
  unsigned int threebyte,	/* Constructed 3 byte integer */
	 tmpnum;
  unsigned char decodedbytes[4];
  int i_idx = 0, o_idx = 0;
  int nbyte3;		/* number of bytes (up to 3) to process */
  char *current;	/* current input character position */
  char *cp;
  int len;
  int i;

  len = input.len;
  for (; i_idx < len; i_idx += 4) {
    if ((input.data[i_idx] == CR) && (input.data[i_idx+1] == LF)) {
      if ((i_idx + 2) == len)
	break;
      i_idx += 2;
    }
    if (input.data[i_idx] == CR) {
      if ((i_idx + 1) == len)
	break;
      i_idx += 1;
    }
    if (input.data[i_idx] == LF) {
      if ((i_idx + 1) == len)
	break;
      i_idx += 1;
    }

    threebyte = 0;
    nbyte3 = 3;

    current = (char *) input.data + i_idx;
    if (current[2] == '=')
      nbyte3 = 1;
    else if (current[3] == '=')
      nbyte3 = 2;

    for (i = 0; i <= nbyte3; i++) {
      if ((cp = strchr(table, current[i])) == NULL) {
        VSAA_Log(VS_LOG_CRITICAL, __LINE__, __FILE__,NULL, (char *) "DecodeBase64(): %dth character 0x%x is not a valid base64 encoded character.", i_idx+i, current[i]);
        return(eUTIL_DECODE_BASE64_INVALID_CHAR);
      }
      tmpnum = cp - table;
      tmpnum <<= (3 - i) * 6;
      threebyte += tmpnum;
    }
    for (i = 2; i >= 0; i--) {
      decodedbytes[i] = threebyte & 255;
      threebyte >>= 8;
    }

    for (i = 0; i < nbyte3; i++)
      output->data[o_idx+i] = decodedbytes[i];
    o_idx += nbyte3;

    if (nbyte3 < 3)	/* No more data */
        break;
  }

  if (o_idx <= (int)output->len) {
    output->len = o_idx;
  }
  else {  
    VSAA_Log(VS_LOG_CRITICAL, __LINE__, __FILE__,NULL, (char *) "DecodeBase64(): size of decoded data (%d) is larger than buffer allocated (%d)", o_idx, output->len);
    return eUTIL_BASE64_NOT_ENOUGH_BUFFER_SPACE;
  }
  return 0;
}

void DisplayHex(char *Msg, unsigned char *buffer, int size)
{
    int i;

    fprintf(stdout, "%s (%d) = \n", Msg, size);
    for (i = 0; i < size; i++)
    {
        fprintf(stdout, "%02x", buffer[i]);
        if ((i & 0x1f) == 0x1f)
            printf("\n");
    }
    fprintf(stdout, "\n");
    fflush(stdout);
}
