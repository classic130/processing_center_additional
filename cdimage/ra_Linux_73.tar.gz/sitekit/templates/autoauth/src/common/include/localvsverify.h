/*
 * $Revision: 1.1.2.1 $
 * $Header: /cvsroot/mpki/vsaakm/common/include/Attic/localvsverify.h,v 1.1.2.1 2010/03/05 11:55:28 pchaudhari Exp $
 */

/*--------------------------------------------------------------------\
| Copyright (C) VeriSign, Inc. created 1997. All rights reserved.     |
| This is an unpublished work protected as such under copyright law.  |  
| This work contains proprietary, confidential, and trade secret      |
| information of VeriSign, Inc.  Use, disclosure or reproduction      |
| without the expressed written authorization of VeriSign, Inc.       |
| is prohibited.                                                      |
\--------------------------------------------------------------------*/



#ifndef _LOCALVSVERIFY_H_
#define _LOCALVSVERIFY_H_

#ifndef PACKAGED_SRC
#include "../../vsaasrv/include/vsverify.h"
#else
#include "vsverify.h"
#endif

#endif/*_LOCALVSVERIFY_H_*/
