/*
 * $Revision: 1.2 $
 * $Header: /cvsroot/mpki/vsaakm/vsaaodbc/include/vsaaodbcutil.h,v 1.2 2002/09/25 23:31:29 buildman Exp $
 */

/*--------------------------------------------------------------------\
| Copyright (C) VeriSign, Inc. created 1997. All rights reserved.     |
| This is an unpublished work protected as such under copyright law.  |  
| This work contains proprietary, confidential, and trade secret      |
| information of VeriSign, Inc.  Use, disclosure or reproduction      |
| without the expressed written authorization of VeriSign, Inc.       |
| is prohibited.                                                      |
\--------------------------------------------------------------------*/

#ifndef _VSODBC_H_
#define _VSODBC_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>

#ifdef WIN32
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <io.h>
#endif

#include <time.h>
#include <sqlext.h>

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#define NULL_ERROR_PTR ((ERROR_CTX *) NULL_PTR)
#define NULL_SURRENDER_PTR ((SURRENDER_CTX *) NULL_PTR)
#define NULL_A_SURRENDER_PTR ((A_SURRENDER_CTX *) NULL_PTR)
#define NULL_UINT_PTR ((unsigned int *) NULL_PTR)
#define NULL_UCHAR_PTR ((unsigned char *) NULL_PTR)

#define UPDATESTATUS_MSG(WID, MSG)		SendMessage(hStatWin, SB_SETTEXT, WID, (LPARAM) MSG)
#define MSTATUS(MSG)					SendMessage(hStatWin, SB_SETTEXT, 0, (LPARAM) MSG)

#define ONWAITMSG(MSG)					ULIBSetUpWaitBox(NULL, MSG, NULL)
#define OFFWAITMSG						ULIBCloseWaitBox()

#define CURSORONWAIT		if (!iWaitCur) {hSaveCur = SetCursor(hWaitCur); iWaitCur = 1;}
#define CURSOROFFWAIT		if (iWaitCur)  {SetCursor(hSaveCur), iWaitCur = 0;}

#define MAX_STRINGSIZE			256
#define FATALMESSAGE(MSG)  FatalMessage(hMainWin, MSG)

#define FUNCBREAK(ZZ)   {FunctionError(NULL, Func, ZZ, status); break;}

/*
 *  Definition of file extension
 */

#define XDERFILE		".der"
#define XTXTFILE		".txt"

/* 
 * Macro for Profile Configuration
 */

#define GetCfgStr(Sect, Key, Str) GetPrivateProfileString(Sect, Key, "", Str, sizeof(Str), IniFile)
#define GetCfgInt(Sect, Key, Val) Val = GetPrivateProfileInt(Sect, Key, 0, IniFile)

#define L_RANDOM				0
#define L_UPPERLEFT				1
#define L_UPPERRIGHT			2
#define L_LOWERLEFT				3
#define L_LOWERRIGHT			4
#define L_CENTER				5

/* 
 *  Macro for ODBC Variable Parameter
 */

typedef struct
		{
			char *Str;
			int   Siz;
			SWORD cTyp;
		} ODBCFIELDTYPE, *ODBCFIELDPTR;

#define NULLDATASTR					    "~"
#define NULLPREFIX						"~"

#define COL_CHAR_LEN(Ptr, Len)			Ptr, Len, SQL_CHAR
#define COL_VCHAR_LEN(Ptr, Len)			Ptr, Len, SQL_VARCHAR
#define COL_LCHAR_LEN(Ptr, Len)			Ptr, Len, SQL_LONGVARCHAR

#define COL_CHAR_ITEM(Ptr)				(Ptr).data, (Ptr).len, SQL_CHAR
#define COL_VCHAR_ITEM(Ptr)				(Ptr).data, (Ptr).len, SQL_VARCHAR
#define COL_LCHAR_ITEM(Ptr)				(Ptr).data, (Ptr).len, SQL_LONGVARCHAR


#define COL_CHAR(Ptr)					Ptr, sizeof(Ptr), SQL_CHAR
#define COL_VCHAR(Ptr)					Ptr, sizeof(Ptr), SQL_VARCHAR
#define COL_LCHAR(Ptr)					Ptr, sizeof(Ptr), SQL_LONGVARCHAR

#define COL_ICHAR(Ptr)					Ptr, -1, SQL_CHAR
#define COL_IVCHAR(Ptr)					Ptr, -1, SQL_VARCHAR
#define COL_IVLCHAR(Ptr)  				Ptr, -1, SQL_LONGVARCHAR

#define COL_INTEGER(Ptr)				Ptr, 0, SQL_INTEGER
#define COL_TIMESTAMP(Ptr)				Ptr, 0, SQL_TIMESTAMP

#define COL_BIN_LEN(Ptr, Len)			Ptr, Len, SQL_BINARY
#define COL_VBIN_LEN(Ptr, Len)			Ptr, Len, SQL_VARBINARY
#define COL_LBIN_LEN(Ptr, Len)			Ptr, Len, SQL_LONGVARBINARY

#define COL_BIN_ITEM(Ptr)				(Ptr).data, (Ptr).len, SQL_BINARY
#define COL_VBIN_ITEM(Ptr)				(Ptr).data, (Ptr).len, SQL_VARBINARY
#define COL_LBIN_ITEM(Ptr)				(Ptr).data, (Ptr).len, SQL_LONGVARBINARY


#define MAX_SQL_IDENTIFIER		64
#define INPUT_IDENTIFIER		'?'
#define MAXRSLTSIZE				10240
#define MINRSLTSIZE				32


/* 
 *  Macro for SQL Type in ODBCSQLExec
 */

#define FT_DIRECT				 0
#define FT_UPDATE				 1
#define FT_SELECT				 2
#define ODBC_OK(rc)				 (rc == SQL_SUCCESS || rc == SQL_SUCCESS_WITH_INFO)

extern BOOL				ODBCCloseConnection		(char *errDesc, int *DbId);
extern BOOL				ODBCOpenConnection		(char *errDesc, int *DbId, const char *DBaseName,
												 const char *UserName, const char *PassWord);
extern BOOL				ODBCCloseCursor			(char *errDesc, int *FdId);
extern BOOL				ODBCOpenCursor			(char *errDesc, int *FdId, int DbId);
extern BOOL				ODBCSQLFreeStmt			(int FdId);
extern RETCODE			ODBCSQLExec				(char *errDesc, int &DbId, int &DbCursor, char* database, char *username, 
												 char *password, int SQLType, char *SQLCommand, ...);
extern RETCODE			ODBCSQLExecWithLength	(char *errDesc, int FdId, int SQLType,
												 char *SQLCommand, ...);
extern RETCODE			ODBCSQLExecWithArgs		(char *errDesc, int FdId, int SQLType,
												 char *SQLCommand, ODBCFIELDPTR Tab);
extern RETCODE			ODBCSQLFetch			(char *errDesc, int FdId);
extern RETCODE			ODBCSetConnectOption	(char *errDesc, int DbId, int Opt, int Val);
extern RETCODE			ODBCCommit				(char *errDesc, int DbId);
extern RETCODE			ODBCRollback			(char *errDesc, int DbId);
extern BOOL				ODBCError				(char *errDesc, int FdId, RETCODE ErrCde, char *FuncName);
extern HSTMT			ODBCCursor				(int FdId);
#ifdef ASK_BINH
extern BOOL				ODBCReportFetchSQLDb	(char *errDesc, int FdId, int FieldWinId,
												 int RowWinId, char *SqlStmt, int *MaxCountRow,
												 char *ColName[], int StartOfs);
#endif
extern TIMESTAMP_STRUCT *SQL_SysDate			(TIMESTAMP_STRUCT *D);

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif
