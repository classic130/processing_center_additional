/*
 * $Revision: 1.2.2.1.22.7 $
 * $Header: /cvsroot/mpki/vsaakm/vsaafile/src/vsaafile.cpp,v 1.2.2.1.22.7 2005/04/13 20:34:04 htrinh Exp $
 */

/*--------------------------------------------------------------------\
| Copyright (C) VeriSign, Inc. created 1997. All rights reserved.     |
| This is an unpublished work protected as such under copyright law.  |
| This work contains proprietary, confidential, and trade secret      |
| information of VeriSign, Inc.  Use, disclosure or reproduction      |
| without the expressed written authorization of VeriSign, Inc.       |
| is prohibited.                                                      |
\--------------------------------------------------------------------*/

/*--------------------------------------------------------------------\
 This is a sample data access layer sample to process an Automated
 Authentication request. The module supports three functions:

 * function VerifyUser()
   The verify operation is invoked to verify (or authenticate) the
   applicant after the applicant submits the enrollment form. The
   verify operation scans the APPLICANT_DB file to perform authentication
   and augmentation.

   APPLICANT_DB is a text file of user records that represents a
   database in this example.

   Each user record in APPLICANT_DB is composed of sets of two
   consecutive lines.  The first line contains the name-value pairs
   that will be compared with the name-value pairs submitted by the
   applicant.  These are the values that the applicant must enter
   correctly in order to be authenticated as that person.

   The second line contains the augmented name-value pairs. If the
   applicant submitted correct information, these pairs are merged
   with of the applicant's submitted pairs. The augmented pairs are
   merged in order that the resulting file is in PKCS7 format for
   submission as a request for a certificate. (In subsequent
   operations, the resulting verified/augmented file is sent to the
   signer function, and then sent to VeriSign so that the certificate
   can be generated.)

   Thus, the verify operation follows these steps:

   1) The submittted name-value pairs are compared with each first line
      of each pair in APPLICANT_DB.
   2) If the name of a user record name-value pair identically matches
      the name of a input name-value pair, the value of the user record
	  name-value pair must case-insensitively match with the value of
	  the input name-value pair. If the value of the user record name-
	  value pair does not case-insensitively match the value of the input
      name-value pair, then this user record is no match. At least one
      name-value pair of the user record in APPLICANT_DB must match
      with a name-value pair in the input list.
   3) When a match occurs, the name-value pairs in the second line
      of that two-line set (the augmented name-value pairs) are returned.

 * function RegisterUser()
   This function appends the input name-value pairs to a LOG_FILE with
   a time stamp.

 * function ErrorUser()
   This function appends the input name-value pairs to a LOG_FILE with
   a time stamp.

\--------------------------------------------------------------------*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

/* Verisign AA header files */

#include "vsaaapi.h"
#include "vsaanls.h"
#include "vsverify.h"
#include "vsaautil.h"
#include "vsutil.h"
#include "vskpi.h"

/* version information */

static const char*  _version_ = "@(#)$RCSfile: vsaafile.cpp,v $ $Revision: 1.2.2.1.22.7 $";

/*
 * defined constants
 */
#define APPLICANT_DB	"validuser.txt"
#define LOG_FILE		"registeruser.log"

#define FILE_PREPICKUP_PROCESS              ("PRE_PICKUP_PROCESS")
#define FILE_PREREVOKE_PROCESS              ("PRE_REVOKE_PROCESS")
#define FILE_PRERENEWAL_PROCESS             ("PRE_RENEWAL_PROCESS")
#define kMaxRecLen                          1024
#define kMaxNVP                             50

/*
 * local storage
 */
static char applicantFile[64];
static VSAA_BOOL gDataSourceUseUTF8 = VSAA_TRUE;
/* Start CR#27984 : Identifiers are added.*/
/* extendedInputEncoding holds the value from the AA/KMS config file specifying support for UTF-8 */
static char extendedInputEncoding[128] = {"UTF-8"};
/* CFG_DB_USED_ENCODING stores the name of the name of config parameter specifying support for UTF-8*/
static char CFG_DB_USED_ENCODING[] = {"DATA_SOURCE_USE_UTF8"};
/* End CR#27984 */

/*
 * local function prototype
 */
static VSAA_STATUS Append(VSAA_NAME **panOutput, const char *pszName,
						  size_t nameLen, const char *pszValue,
						  size_t valueLen);
static void Augment(const char *rcd, VSAA_NAME **output);
static void getNVPFromRecord(char *rcd, VSAA_NAME newRec[]);
static int VerifyRecord(const char *rcd, const VSAA_NAME userInput[]);
static VSAA_STATUS DoVerifyUser(const VSAA_NAME userInput[], VSAA_NAME **augmentedData);
static VSAA_STATUS DoPrePickupProcess(const VSAA_NAME userInput[], VSAA_NAME       **augmentedData);
static VSAA_STATUS DoPreRevokeProcess(const VSAA_NAME userInput[], VSAA_NAME       **augmentedData);
static VSAA_STATUS DoPreRenewProcess(const VSAA_NAME userInput[], VSAA_NAME       **augmentedData);
static VSAA_STATUS ReadConfigFile(const char* pszServiceCfgFileName);

#ifdef __cplusplus
extern "C" {
#endif
VS_STATUS (*VS_Log)(VS_LOG_TYPE level, int line, const char *filename,	char *format,	...) = NULL;
#ifdef __cplusplus
}
#endif

VSAA_BOOL             nPrePickupProcess;
VSAA_BOOL             nPreRevokeProcess;
VSAA_BOOL             nPreRenewalProcess;

/*******************************************************************/
/*
* Initialize file names
*/
/*******************************************************************/
#ifdef __cplusplus
extern "C" {
#endif
VSAA_STATUS
VSAA_LINK Initialize(
                     const VSAA_NAME commonVSAAConfig[],
                     const char*     pszServiceCfgFileName,
                     VS_STATUS (*VSAA_Log)(VS_LOG_TYPE level, int line, const char *filename,	char *format,	...))
{
  VSAA_NAME fileDBConfig[] = {
    { (char *)CFG_DB,		       (char *) DB_FILE},
    { NULL,			        NULL }
  };
  VSAA_STATUS status = VSAA_SUCCESS;

  VS_Log = VSAA_Log;

  /* Determine whether UTF8 data is stored in data source from common configuration */
  if(commonVSAAConfig != NULL) {
      const char* pszDataSourceUserUTF8CfgValue = FindName(
          CFG_DB_USE_UTF8, strlen(CFG_DB_USE_UTF8), commonVSAAConfig);
      if(pszDataSourceUserUTF8CfgValue != NULL && !VSAAUTIL_StrCaseCmp(pszDataSourceUserUTF8CfgValue, "no"))
          gDataSourceUseUTF8 = VSAA_FALSE;
  }

  const char* fileDBName = FindName(CFG_DB, strlen(CFG_DB), commonVSAAConfig);

  do {
    if(fileDBName != NULL)
      strcpy(applicantFile, fileDBName);
    else {

      /* read from configuration file */
      if( (status = GetConfig(pszServiceCfgFileName, fileDBConfig)) != VSAA_SUCCESS)
      {

        VS_Log(VS_LOG_ERROR, __LINE__, __FILE__,  (char *)"ERROR: cannot open file %s", pszServiceCfgFileName);
        break;

      } else {

        fileDBName = FindName(CFG_DB, strlen(CFG_DB), fileDBConfig);
        if(fileDBName != NULL)
          strcpy(applicantFile, fileDBName);
        else {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__,
            (char *)"ERROR: cannot file configuration entry for %s", CFG_DB);
          status = VSAA_ERR_CFG_ENTRY_MISSING;
          break;
        }
      }
    }

    nPrePickupProcess = VSAA_FALSE;
    nPreRevokeProcess = VSAA_FALSE;
    nPreRenewalProcess = VSAA_FALSE;

    status = ReadConfigFile(pszServiceCfgFileName);
    if ( status != VSAA_SUCCESS ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__,  (char *)"reading %s failed", pszServiceCfgFileName);
      break;
    }
  } while (0);
  return status;
}
#ifdef __cplusplus
}
#endif

/* Release resources allocated for global data in this module */

VSAA_STATUS
VSAA_LINK Finalize(void)
{
    return VSAA_SUCCESS;
}

VSAA_STATUS
VerifyUser(
    const VSAA_NAME userInput[],
    VSAA_NAME       **augmentedData)
{
  VSAA_STATUS  status = VSAA_SUCCESS;
  const char *operation;

  operation = FindName(VSAA_OPERATION, strlen(VSAA_OPERATION), userInput);

  do {
    if ( operation == NULL || strlen(operation) == 0 ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, (char *)"Operation is missing in the name value list.");
      status =  VSAA_INTERNAL_ERROR;
      break;
    }

    if (!strcmp(operation, VSAA_AA_PICKUP) || !strcmp(operation, VSKPI_PICKUP) ) {
      // doing pre-pickup process
      if ( nPrePickupProcess ) {
        status = DoPrePickupProcess(userInput, augmentedData);
      }
    } else if (!strcmp(operation, VSAA_AA_REVOKE) ) {
      // doing pre-revoke process
      if ( nPreRevokeProcess ) {
        status = DoPreRevokeProcess(userInput, augmentedData);
      }
    } else if (!strcmp(operation, VSAA_AA_RENEWAL) ) {
      // doing pre-renew process
      if ( nPreRenewalProcess ) {
        status = DoPreRenewProcess(userInput, augmentedData);
      }
    } else {
      // always does the verify user for any operation other than pickup, revoke, renewal
      status = DoVerifyUser(userInput, augmentedData);
    }
  } while (0);

  return status;
}


/*******************************************************************/
VSAA_STATUS ErrorUser(const VSAA_NAME userInput[])
/*
 * Record this user in the log file
 */
/*******************************************************************/
{
  int i ;
  time_t tm = time(NULL);

  if ( VS_Log == NULL )
    return VSAA_UPDATE_FAILED;

  VS_Log(VS_LOG_ERROR, __LINE__, __FILE__,  (char *) "ERROR in ErrorUser at %s", ctime(&tm));
  VS_Log(VS_LOG_ERROR, __LINE__, __FILE__,  (char *) "Dumping user name value pairs");
  for (i=0; userInput[i].pszName != NULL ; i++)
  {
    VS_Log(VS_LOG_ERROR, __LINE__, __FILE__,  (char *)"%s=%s", userInput[i].pszName, userInput[i].pszValue);
  }
  return VSAA_SUCCESS ;
}




/*******************************************************************/
VSAA_STATUS RegisterUser(const VSAA_NAME userInput[])
/*
 * Record this user in the log file
 */
/*******************************************************************/
{
	int i ;
	time_t tm = time(NULL);

  if ( VS_Log == NULL )
    return VSAA_UPDATE_FAILED;

	VS_Log(VS_LOG_INFO, __LINE__, __FILE__,  (char *)"REGISTER at %s", ctime(&tm));
	for (i=0; userInput[i].pszName != NULL ; i++)
	{
		VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__,  (char *) "%s=%s", userInput[i].pszName, userInput[i].pszValue);
	}

	return VSAA_SUCCESS ;
}


/*******************************************************************/
static VSAA_STATUS Append(VSAA_NAME **panOutput, const char *pszName,
						  size_t nameLen, const char *pszValue,
						  size_t valueLen)
/*
 * Append this name-value pair to the end of the panOutput list
 */
/*******************************************************************/
{
	size_t i;

	if (*panOutput == NULL)
	{
		*panOutput = (VSAA_NAME *)calloc(2, sizeof(VSAA_NAME));
		if (*panOutput == NULL)
			return VSAA_OUT_OF_MEMORY;
		i = 0;
	}
	else /* existing data */
	{
		VSAA_NAME *newList;

		i = Entries(*panOutput) - 1;
		newList = (VSAA_NAME *)realloc(*panOutput, sizeof(VSAA_NAME) * (i + 2));
		if (newList == NULL)
			return VSAA_OUT_OF_MEMORY;
		*panOutput = newList;
	}

	/* null out the last entry */
	(*panOutput)[i].pszName  = NULL;
	(*panOutput)[i].pszValue = NULL;
	(*panOutput)[i+1].pszName  = NULL;
	(*panOutput)[i+1].pszValue = NULL;

	/* add an entry to the near end of the list */
	(*panOutput)[i].pszName = (char *)calloc(1, nameLen + 1);
	if ((*panOutput)[i].pszName == NULL)
		return VSAA_OUT_OF_MEMORY;
	memcpy((*panOutput)[i].pszName, pszName, nameLen);

	(*panOutput)[i].pszValue = (char *)calloc(1, valueLen + 1);
	if ((*panOutput)[i].pszValue == NULL)
		return VSAA_OUT_OF_MEMORY;
	memcpy((*panOutput)[i].pszValue, pszValue, valueLen);

	return VSAA_SUCCESS;
}


/*******************************************************************/
static void Augment(const char *rcd, VSAA_NAME **output)
/*
 * Augment name-value pairs in this rcd to the output list
 */
/*******************************************************************/
{
  char       rcdDup[kMaxRecLen];
  VSAA_NAME augmentRcd[kMaxNVP];
  int       i;

  if ( rcd == NULL || strlen(rcd) == 0 || strlen(rcd) >= (kMaxRecLen-1) ) {
    VS_Log(VS_LOG_ERROR, __LINE__, __FILE__,
           (char *)"The  record line is either empty or more than %d characters", kMaxRecLen-1);
    return;

  }

  for ( i=0; i<kMaxNVP; i++ ){
    augmentRcd[i].pszName = NULL;
    augmentRcd[i].pszValue = NULL;
  }

  strcpy(rcdDup, rcd);
  getNVPFromRecord( rcdDup, augmentRcd );

  i=0;

  while ( augmentRcd[i].pszName != NULL )
  {
	  Append(output, augmentRcd[i].pszName, strlen(augmentRcd[i].pszName),
           augmentRcd[i].pszValue, strlen(augmentRcd[i].pszValue));
    i++;
  }

}



/*** VerifyRecord
 ***
 *** DESCRIPTION
 ***
 ***  Return TRUE if all the fields in this record matches the input list.
 ***  The format of the records is <name>=<value>[,<name>=<value>...]
 ***  A match is defined as when a name is defined in the record matches a
 ***  name in the input list, the value in the record must match the
 ***  value in the input list.
 ***
 *** ARGUMENTS
 ***   const char *rcd     - IN - authentication data
 ***   VSAA_NAME userInput[] - IN - a list of name/value pairs
 ***
 *** RETURNS
 ***   int - return TRUE or FALSE
 ***
 ***
 *** REVISION HISTORY
 ***   Date          Author     Desc
 ***   ----          ------     ----
 ***   ?             Oanh      Created.
 ***   Oct 20, 2000  Tom       All fields need to be matched to return TRUE.
 ***
 ***   Oct 20, 2000  Tom       Operation doesn't need to be the first name/value pair.
 ***                           Call FindName to find the operation
 ***                           name/value pair from input n/v pair lists.
 ***/
/*******************************************************************/
static int VerifyRecord(const char *rcd, const VSAA_NAME userInput[])
/*******************************************************************/
{
  char       rcdDup[kMaxRecLen];
  VSAA_NAME verifyRcd[kMaxNVP];
  const char *pszInputValue;
  int       i;

  if ( rcd == NULL || strlen(rcd) == 0 || strlen(rcd) >= (kMaxRecLen-1) ) {
    VS_Log(VS_LOG_ERROR, __LINE__, __FILE__,
           (char *)"The  record line is either empty or more than %d characters", kMaxRecLen-1);
    return 0; /* if the field is empty or exceeding the max len, retrun FALSE */
  }

  for ( i=0; i<kMaxNVP; i++ ){
    verifyRcd[i].pszName = NULL;
    verifyRcd[i].pszValue = NULL;
  }

  strcpy(rcdDup, rcd);
  getNVPFromRecord( rcdDup, verifyRcd );

  i=0;
  while ( verifyRcd[i].pszName != NULL )
  {
    pszInputValue = FindName(verifyRcd[i].pszName, strlen(verifyRcd[i].pszName), userInput);
    if (pszInputValue)              /* if this field is given */
    {
      if ( VSAAUTIL_StrCaseCmp(pszInputValue, verifyRcd[i].pszValue) ) {
        VS_Log (VS_LOG_DEBUG, __LINE__, __FILE__,   (char *) "Input value <%s=%s>; Verification value <%s=%s>. No match.",
                verifyRcd[i].pszName, pszInputValue, verifyRcd[i].pszName, verifyRcd[i].pszValue);
        return 0;  /* if the field does not match, return FALSE */
      }
    } else {
      VS_Log (VS_LOG_DEBUG, __LINE__, __FILE__,   (char *) "Verification value <%s=%s> is not in the user input list.",
                verifyRcd[i].pszName, verifyRcd[i].pszValue);
      return 0;    /* if the field is not given, return FALSE */
    }
    i++;
  }

  if ( verifyRcd[0].pszName == NULL ) {
    VS_Log (VS_LOG_DEBUG, __LINE__, __FILE__,   (char *) "No Verification record is found.");
    return 0; /* if no verification field is found, return FALSE */
  }

  return 1;
}

/*** DoVerifyUser
 ***
 *** DESCRIPTION
 ***
 *** Verify the input. If the input is authorized, build the augmented
 *** name-value pairs for signing operation
 ***
 *** ARGUMENTS
 ***   VSAA_NAME userInput[] - IN - a list of name/value pairs
 ***   VSAA_NAME **augmentedData - OUT - agumented name/value pairs
 ***
 *** RETURNS
 ***   VAAA_STATUS - return VSAA_SUCCESS or VSAA_INTERNAL_ERROR
 ***
 ***
 *** REVISION HISTORY
 ***   Date          Author     Desc
 ***   ----          ------     ----
 ***   ?             Oanh      Created.
 ***   Dec 6, 2000   Tom       if no matched data found,
 ***                           default to authenticate=NO
 ***/
/*******************************************************************/
VSAA_STATUS DoVerifyUser(const VSAA_NAME userInput[], VSAA_NAME **augmentedData)
/*******************************************************************/
{
	char authData[1024], *nativeAuthData = NULL;
	char augmentData[1024], *nativeAugmentData = NULL;
	VSAA_STATUS status = VSAA_VERIFY_FAILED;
	FILE *fp;
	//Start: CR#27984 : Identifier initialized.
	//VSAA_NAME *addData = NULL;
	//End: CR#27984
	if (applicantFile[0])
		fp = fopen(applicantFile, "r");
	else
		fp = fopen(APPLICANT_DB, "r");

    const char* inputEncoding = FindName(VSAA_ENCODING_NAME, strlen(VSAA_ENCODING_NAME), userInput);

	if (fp != NULL)
	{
		while (fgets(authData, sizeof(authData), fp) != NULL)
		{
			/* clean the trailing carriage-return */
			if (authData[strlen(authData) - 1] == '\n')
				authData[strlen(authData) - 1] = '\0';

			/* fetch the second line to be used for augmentation */
			augmentData[0] = '\0';
			fgets(augmentData, sizeof(augmentData), fp);
			if (augmentData[strlen(augmentData) - 1] == '\n')
				augmentData[strlen(augmentData) - 1] = '\0';

			/* Start CR#27984 */
			/* If the incoming data is in UTF8 format*/
			if(inputEncoding != NULL && strlen(inputEncoding))
			{
				    /* For each record in the config file, convert from native to UTF8 irrespective */
				    /* of the value specified in the config file of AA/KMS */
					int rc = NativeToUTF8(&nativeAuthData, authData, extendedInputEncoding);
					if(rc != 0) {
						VS_Log (VS_LOG_WARNING, __LINE__, __FILE__,
						(char *) "Conversion from UTF8 to native encoding failed on authentication line (%s) with error (%d)", authData, rc);
						nativeAuthData = (char*)authData;
						VS_Log (VS_LOG_DEBUG, __LINE__, __FILE__,   (char *) " extendedInputEncoding != 0 <%d>", rc);
					}
					rc = NativeToUTF8(&nativeAugmentData, augmentData, extendedInputEncoding);
					VS_Log (VS_LOG_DEBUG, __LINE__, __FILE__,   (char *) " RC ==  <%d>", rc);
					VS_Log (VS_LOG_DEBUG, __LINE__, __FILE__,   (char *) "Applied Encoding <%s> Augment: <%s>, nativeAugmentData is <%s>", extendedInputEncoding, augmentData, nativeAugmentData);
					if(rc != 0) {
						VS_Log (VS_LOG_WARNING, __LINE__, __FILE__,
							(char *) "Conversion from UTF8 to native encoding failed on augmen data line (%s) with error (%d)", augmentData, rc);
						nativeAugmentData = (char*)augmentData;
					}
					if (VerifyRecord(nativeAuthData, userInput))
					{
						/* produce the augmented name-value pairs */
						Augment(nativeAugmentData, augmentedData);
						status = VSAA_SUCCESS;
						break;
					}
			}
			/* If the incoming data is not in UTF8 format*/
			else {
				nativeAuthData = (char*)authData;
				nativeAugmentData = (char*)augmentData;
				VS_Log (VS_LOG_DEBUG, __LINE__, __FILE__,   (char *) "NO Applied Encoding: <%s>, nativeAugmentData is <%s>", authData, nativeAuthData);
			}
            /*if(gDataSourceUseUTF8 == VSAA_TRUE && inputEncoding != NULL && strlen(inputEncoding) > 0) {
                int rc = UTF8ToNative(&nativeAuthData, authData, inputEncoding);
                if(rc != 0) {
                    VS_Log (VS_LOG_WARNING, __LINE__, __FILE__,   (char *) "Conversion from UTF8 to native encoding failed on authentication line (%s) with error (%d)", authData, rc);
                    nativeAuthData = (char*)authData;
                }
                rc = UTF8ToNative(&nativeAugmentData, augmentData, inputEncoding);
                if(rc != 0) {
                    VS_Log (VS_LOG_WARNING, __LINE__, __FILE__,   (char *) "Conversion from UTF8 to native encoding failed on augmen data line (%s) with error (%d)", augmentData, rc);
                    nativeAugmentData = (char*)augmentData;
                }
            } else {
                nativeAuthData = (char*)authData;
                nativeAugmentData = (char*)augmentData;
            }*/
            /* End CR#27984 */

			VS_Log (VS_LOG_DEBUG, __LINE__, __FILE__,   (char *) "Auth data is <%s>, nativeAugmentData is <%s>", authData, nativeAugmentData);

			/* Start : CR25934 Native augmented data needs to be augmented with previous data in case of invalid user. */
                        // Commented during merging.
			//Augment(nativeAugmentData, augmentedData);
			/* End : CR25934 */


			if (VerifyRecord(authData, userInput))
			{
				/* produce the augmented name-value pairs */
				Augment(nativeAugmentData, augmentedData);
				status = VSAA_SUCCESS;
				break;
			}
		}
		/* Start : CR25934 Incorporated review comments given by Salil */
                // Not required as native Auth or augment data is never malloced
		//if(nativeAuthData != (char*)authData && nativeAuthData != NULL) free(nativeAuthData);
        //if(nativeAugmentData != (char*)augmentData && nativeAugmentData != NULL) free(nativeAugmentData);
		/* End : CR25934  */
		fclose(fp);
	}
	else
		status = VSAA_INTERNAL_ERROR;

	return status;
}

VSAA_STATUS
VSAA_LINK validateAuthenticationDataSource()
{
    return VSAA_SUCCESS;
}

VSAA_STATUS
VSAA_LINK validateRegistrationDataSource()
{
    return VSAA_SUCCESS;
}

VSAA_STATUS
VSAA_LINK validateRecoverDataSource()
{
    return VSAA_SUCCESS;
}

VSAA_STATUS
VSAA_LINK KMOperation(const VSAA_NAME subInfo[], const char* operation)
{
    return VSAA_SUCCESS;
}

static VSAA_STATUS ReadConfigFile(const char* pszServiceCfgFileName)
{
  VSAA_STATUS status = VSAA_SUCCESS;
  FILE*       cfgFp;
  char        szLine[MAX_CFG_VALUE_LENGTH];
  char        szOrigLine[MAX_CFG_VALUE_LENGTH];
  char*       pszName = NULL;
  int         i;

  VSAACfgAttrList* valueListPtr = NULL;

  /* open configuration file */

  cfgFp = fopen(pszServiceCfgFileName, "r");
  if (!cfgFp) {
    VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, (char *) "Could not open file %s to read configuration data.", pszServiceCfgFileName);
    return VSAA_INTERNAL_ERROR;
  }

  /* while there are more lines in the config file */


  while((status = VSAAUTIL_ReadEntryLine(szLine, MAX_CFG_VALUE_LENGTH, cfgFp)) == VSAA_SUCCESS && *szLine)
  {
    if (*szLine == CFG_COMMENT_MARK) continue;

    strcpy(szOrigLine, szLine);

    /*
    assume each config entry consists of less than MAX_CFG_VALUE_LENGTH
    characters which might spread several lines.
    */

    i = strlen(szLine);
    if( i == MAX_CFG_VALUE_LENGTH && szLine[i-1] != '\n') {
      status = VSAA_ERR_CFG_FILE_LINE_TOO_LONG;
      VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__,  (char *) "A configuration line was found to be too long (>%ld bytes): %s", MAX_CFG_VALUE_LENGTH, szLine);
      break;
    } else {
      szOrigLine[i-1] = '\0';
    }

    /*
    the last char will be a newline.  blow it away, and then
    squeeze out the trailing spaces.
    */

    szLine[i--] = '\0';
    while(isspace(szLine[i]))
      szLine[i--] = '\0';

    /* eliminate any spaces at the start of the line */

    i = 0;
    while(isspace(szLine[i]))
      i++;

    /* allow blank lines in configuration file */

    if(szLine[i] == 0) continue;

    /* split to get name and its value parts */

    pszName = NULL;
    valueListPtr = NULL;
    status = VSAAUTIL_ExtractAttrNameValues(&pszName, &valueListPtr, szLine);

    if(status != VSAA_SUCCESS) {

      VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, (char *) "Invalid entry in configuration file:  %s.", szOrigLine);
      break;

    } else if(!pszName) {

      VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, (char *) "Invalid entry in configuration file:  %s.", szOrigLine);
      if(valueListPtr) VSAAUTIL_FreeCfgAttrList(valueListPtr);
      status = VSAA_INTERNAL_ERROR;
      break;

    } else {

      /* figure out which name this is */

      i = VSAAUTIL_CountAttr(valueListPtr);
      if (!strcmp(FILE_PREPICKUP_PROCESS, pszName)) {

        if(i != 1)
          status = VSAA_INTERNAL_ERROR;
        else
          nPrePickupProcess = !strcmp(VSAA_ON, valueListPtr->pszValue);

      } else if (!strcmp(FILE_PREREVOKE_PROCESS, pszName)) {

        if(i != 1)
          status = VSAA_INTERNAL_ERROR;
        else
          nPreRevokeProcess = !strcmp(VSAA_ON, valueListPtr->pszValue);

      } else if (!strcmp(FILE_PRERENEWAL_PROCESS, pszName)) {

        if(i != 1)
          status = VSAA_INTERNAL_ERROR;
        else
          nPreRenewalProcess = !strcmp(VSAA_ON, valueListPtr->pszValue);

	  /* Start CR#27984 */
	  /* BEGIN CERTISUR */
	  /* Check the config file for UTF8 support name parameter */
	  } else if (!strcmp(CFG_DB_USED_ENCODING, pszName)) {
		if(i == 1){
		  strcpy(extendedInputEncoding, valueListPtr->pszValue);
 #ifdef SOLARIS
           /* NativeToUTF-8 conversion is not supported for Solaris so this workaround */
                   if (!strcmp(extendedInputEncoding, "yes") ||
                       !strcmp(extendedInputEncoding, "YES") ||
                       !strcmp(extendedInputEncoding, "Yes"))
                   {
                       strcpy(extendedInputEncoding, "UTF-8");
                   }
                   else
                   {
                       strcpy(extendedInputEncoding, "ASCII");
                   }
 #endif

		}
	  /* END CERTISUR */
	  /* End CR#27984 */
      } else {

        VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, (char *) "Ignored configuration entry for file setting:  %s", szOrigLine);

      }

      if(status != VSAA_SUCCESS) {

        VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, (char *) "Number of fields for configuration entry %s is not correct: %s", pszName, szOrigLine);

      }

      VSAAUTIL_Free(pszName);
      VSAAUTIL_FreeCfgAttrList(valueListPtr);

      pszName = NULL;
      valueListPtr = NULL;

      if(status != VSAA_SUCCESS) {

        break;

      }
    }
    }

    fclose (cfgFp);

    VS_Log(VS_LOG_INFO, __LINE__, __FILE__, (char *)"Called ReadConfigFile()");

    return status;
}


static VSAA_STATUS DoPrePickupProcess(const VSAA_NAME userInput[], VSAA_NAME  **augmentedData)
{
  VSAA_STATUS  status = VSAA_SUCCESS;

  // When you customize this code, you can replace the DoVerifyUser with another function
  status = DoVerifyUser(userInput, augmentedData);

  return status;
}

static VSAA_STATUS DoPreRevokeProcess(const VSAA_NAME userInput[], VSAA_NAME  **augmentedData)
{
  VSAA_STATUS  status = VSAA_SUCCESS;

  // When you customize this code, you can replace the DoVerifyUser with another function
  status = DoVerifyUser(userInput, augmentedData);

  return status;
}

static VSAA_STATUS DoPreRenewProcess(const VSAA_NAME userInput[], VSAA_NAME   **augmentedData)
{
  VSAA_STATUS  status = VSAA_SUCCESS;

  // When you customize this code, you can replace the DoVerifyUser with another function
  status = DoVerifyUser(userInput, augmentedData);

  return status;
}

static void getNVPFromRecord(char *rcdDup, VSAA_NAME newRec[])
{
  char       *pszName;
  char       *pszValue;
  char       *pszTemp;
  size_t     nameLen;
  size_t     valueLen;
  int        numFields = 0;

  pszName = rcdDup;
  while ( pszName != NULL )
  {
    pszValue = strstr(pszName, "=");    /* look for the next equal sign */

    if (pszValue)                       /* if there is an equal sign */
    {
      // stripping the preceeding spaces
      while ( *pszName == ' ' || *pszName == '\t' )
        pszName++;

      // leaving the last name value pairs NULL, so the while loop will terminate in the caller
      if ( numFields >= (kMaxNVP-1) ) {
        VS_Log(VS_LOG_ERROR, __LINE__, __FILE__,  
               (char *)"More than %d name value pairs found. Ignore the rest", kMaxNVP-1);
        break;
      }

      nameLen = pszValue - pszName;
      /* taking out trailing spaces and terminated with the string*/
      while ( nameLen > 1 && ( pszName[nameLen-1] == ' ' || pszName[nameLen-1] == '\t') )
        nameLen--;
      pszName[nameLen] = 0;

      /* advance pass the equal sign and removing proceeding spaces */
      pszValue++;                     
      while ( *pszValue == ' ' || *pszValue == '\t' )
        pszValue++; 

      if (*pszValue=='[') {
      	pszTemp = strstr(pszValue, "]");
        if (pszTemp!=NULL) {
          valueLen= (pszTemp)-(++pszValue); //skip '[' and ']'
          while ( valueLen > 1 && (pszValue[valueLen-1] == ' ' || pszValue[valueLen-1] == '\t') ) {
            valueLen--;
	  }
      	  pszTemp = strstr(pszTemp, ",");
	  pszValue[valueLen]= 0;
	} else {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, (char *)"Missing right bracket: %s", pszValue);
	  return;
	}
      } else {
      	/* look for the next comma */
      	pszTemp = strstr(pszValue, ",");

      	/* if there is no comma the remaining of the string is the value */
      	if (pszTemp == NULL)            
        	valueLen = strlen(pszValue);   
      	else
        	valueLen = pszTemp - pszValue;

      	/* taking out trailing spaces and terminated with the string*/
      	while ( valueLen > 1 && (pszValue[valueLen-1] == ' ' || pszValue[valueLen-1] == '\t') )
          valueLen--;
      	pszValue[valueLen] = 0;
      }
      newRec[numFields].pszName = pszName;
      newRec[numFields].pszValue = pszValue;
      numFields++;


      /* there is a comma restart after the comma */
      pszName = pszTemp ;
      if (pszTemp != NULL) {     
        pszName++;             
      }
    }
    else /* no more name-value pair, skip the rest */
      break;
  }
  return;
}
