/*
 * $Revision: 1.2 $
 * $Header: /cvsroot/mpki/vsaakm/vsaasrv/include/vsobject.h,v 1.2 2002/09/25 23:32:56 buildman Exp $
 */

/*--------------------------------------------------------------------\
| Copyright (C) VeriSign, Inc. created 1997. All rights reserved.     |
| This is an unpublished work protected as such under copyright law.  |  
| This work contains proprietary, confidential, and trade secret      |
| information of VeriSign, Inc.  Use, disclosure or reproduction      |
| without the expressed written authorization of VeriSign, Inc.       |
| is prohibited.                                                      |
\--------------------------------------------------------------------*/

#ifndef _VSOBJECT_H_
#define _VSOBJECT_H_


/*
 * This class is part of the ECAS Messaging API.
 * 
 * VSObject is the base of all ECAS objects. Right now it does
 * nothing, but serves as a placeholder where we can put
 * global behavior later.
 *
 * REV HISTORY
 * Date          Author     Desc
 * ----          ------     ----
 * Mar 14, 1997   rick       Created.
 */


class VSObject
{
public:
          VSObject (void);
  virtual ~VSObject (void);
};


#endif /* _VSOBJECT_H_ */
  
