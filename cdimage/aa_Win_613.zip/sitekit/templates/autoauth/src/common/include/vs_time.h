#ifndef VS_TIME_INCLUDED
#define VS_TIME_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


//==============================================================================
// includes
//==============================================================================

#include "vs_platform_defs.h"
#include <time.h>


//==============================================================================
// sleep function
//==============================================================================

VS_PLATFORM_DLL_ENTRY void vs_sleep(unsigned interval); // sleep interval in milliseconds


//==============================================================================
// thread-safe time functions
//==============================================================================

VS_PLATFORM_DLL_ENTRY void vs_ctime(time_t timeVal, char timeStr[VS_TIME_STRING_LEN]);
VS_PLATFORM_DLL_ENTRY void vs_asctime(const struct tm* timeVal, char timeStr[VS_TIME_STRING_LEN]);
VS_PLATFORM_DLL_ENTRY void vs_localtime(time_t timeVal, struct tm* timeBuf);
VS_PLATFORM_DLL_ENTRY void vs_gmtime(time_t timeVal, struct tm* timeBuf);


#ifdef __cplusplus
}
#endif

#endif // VS_TIME_INCLUDED
