function isIEHigherVersion(){

        var browserName=navigator.appName;
        var name = navigator.userAgent;
        if(browserName == "Netscape")
        {
          if(name.indexOf("Trident") > 1)
            return true;
          else
            return false;        
        }
        else
        {
           return false;
        } 
}

function CheckIESupportedVersion1(url)
{
 if (CheckIEValidVersion() == 1)
     {document.write(url)}
 else
 {
  if(url.indexOf("../client") > 1)            
     {document.write("<A HREF='../error/invalidBrowser.html'>")}
  else
     {document.write("<A HREF='error/invalidBrowser.html'>")}
 }
}

function CheckIESupportedVersion2(url)
{
 if (CheckIEValidVersion() == 1)
     { self.location = url;}
 else
 {
  if(url.indexOf("../client") > 1)            
     {self.location = "../error/invalidBrowser.html";}
  else
     {self.location = "error/invalidBrowser.html";}
 }
}

function CheckIEValidVersion()
{
 if (navigator.userAgent.indexOf("NT") >= 0 && parseFloat(/Windows NT ([0-9\.]+)/.exec(navigator.userAgent).pop()) >=6)
 {
	return 1;
 }
 else
 {
      return 0;
 }
}
