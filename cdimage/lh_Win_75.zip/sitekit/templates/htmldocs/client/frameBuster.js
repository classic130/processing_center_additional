function frameKiller(){
	var domainNam = null;
	if (self == top) {
			document.documentElement.style.display = 'block';
		} else {
				try{
					domainNam = top.location.hostname;
					}
					catch (err){
					}
					if(domainNam == null  || domainNam!=document.domain){
						top.location = self.location;
					}		
			}
}