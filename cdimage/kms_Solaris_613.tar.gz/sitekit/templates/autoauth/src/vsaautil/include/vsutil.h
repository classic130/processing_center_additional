/*
 * $Revision: 1.2.2.1.2.1.20.7.2.3 $
 * $Header: /cvsroot/mpki/vsaakm/vsaautil/include/vsutil.h,v 1.2.2.1.2.1.20.7.2.3 2005/11/30 21:34:28 sbirrer Exp $
 */

/*--------------------------------------------------------------------\
| Copyright (C) VeriSign, Inc. created 1997. All rights reserved.     |
| This is an unpublished work protected as such under copyright law.  |  
| This work contains proprietary, confidential, and trade secret      |
| information of VeriSign, Inc.  Use, disclosure or reproduction      |
| without the expressed written authorization of VeriSign, Inc.       |
| is prohibited.                                                      |
\--------------------------------------------------------------------*/

#ifndef _VSUTIL_H_
#define _VSUTIL_H_

#include "vsverify.h"

#ifndef TRUE
#define TRUE	1
#define FALSE	0
#endif

/*
 * Common configuration keyword
 */
#define CFG_HOSTNAME            "HOSTNAME"
#define CFG_PORT                "PORT"
#define CFG_LOG                 "LOGFILE"
#define CFG_LOG_LEVEL           "VSAA_LOG_LEVEL"
#define CFG_LOG_HIDE_ATTR       "LOG_HIDE_ATTR"
#define CFG_FIELD_HIDE_ATTR     "FIELD_HIDE_ATTR"
#define CFG_DB                  "DBFILE"
#define CFG_ODBC                "DATABASE"
#define CFG_USR                 "DBUSERNAME"
#define CFG_PSWD                "DBPASSWORD"
#define CFG_KEY_MGR_SERVICE     "KEY_MGR_SERVICE"
#define CFG_RECOVER_FLAG        "RECOVER_FLAG"
#define CFG_RECOVER_CERT_SERIAL "RECOVER_CERT_SERIAL"
#define CFG_MONITOR_ALERT_CMD   "MONITOR_ALERT_COMMAND"
#define CFG_MONITOR_PERIOD      "MONITOR_RUN_PERIOD"
#define CFG_LUNA_FILE           "LUNA"
#define CFG_KEY                 "KEY"
#define CFG_SSL_FLAG            "SSL_FLAG"
#define CFG_PASSPHRASE          "KEY_PASSWORD"
#define CFG_SSLLOG              "SSL_LOG"
#define CFG_SSLLOG_LEVEL        "SSL_LOG_LEVEL"
#define CFG_AUTHSRV_DLL         "VER_SERVICE_DLL"
#define CFG_REGSRV_DLL          "REG_SERVICE_DLL"
#define CFG_RECOVER_DLL         "RECOVER_SERVICE_DLL"
#define CFG_EXCHANGE_SERVER     "EXCHANGE_SERVER"
#define CFG_EXCHANGE_DOMAIN     "EXCHANGE_DOMAIN"
#define CFG_GSE_WIN_AUTH        "GSE_WIN_AUTH"
#define CFG_CERT_DN_FORMAT      "CERT_DN_FORMAT"
#define CFG_EXCHANGE_SERVERS    "EXCHANGE_SERVERS"
#define CFG_DOMAIN_CONTROLLERS  "DOMAIN_CONTROLLERS"
#define CFG_SIGNER_GLOBAL_INIT  "SIGNER_GLOBAL_INIT"
#define CFG_KEYGEN_GLOBAL_INIT  "KEYGEN_GLOBAL_INIT"
#define CFG_HW_ESCROW_FLAG      "HW_ESCROW_FLAG"
#define CFG_RECOVERED_PW_DELIVERY_PERSON "RECOVERED_PW_DELIVERY_PERSON"
#define CFG_HWKEYGEN_DLL        "HARDWARE_KEYGEN_DLL"
#define CFG_HWKEYGEN_SLOT_ID    "HARDWARE_KEYGEN_SLOT_ID"
#define CFG_HWKEYGEN_MODEL			"HARDWARE_KEYGEN_TOKEN_MODEL"
#define CFG_HWKEYGEN_PARTITION_ID	"HARDWARE_KEYGEN_PARTITION_ID"
#define CFG_SIGN_DLL            "SIGNING_DLL"
#define CFG_P12_PWD_LEN         "PKCS12_PASSWORD_LENGTH"
#define CFG_P12PATH             "PKCS12_FILE_PATH"
#define CFG_P12LIFETIME         "PKCS12_LIFETIME"
#define CFG_CERT_ROOT_PATH      "CLIENT_CERT_ROOT_PATH"
#define CFG_CERT_ROOT_FILE      "CLIENT_CERT_ROOT_FILE"
#define CFG_KEY_SIZE            "KEY_SIZE"
#define CFG_HWKEYGEN_FLAG       "HARDWARE_KEYGEN_FLAG"
#define CFG_LOGLIFETIME         "LOG_LIFETIME"
#define CFG_DB_USE_UTF8         "DATA_SOURCE_USE_UTF8"
#define CFG_REG_SIGNING_CERT    "REGISTER_SIGNING_CERT"

/* Start Add: Feature request to support Dual Control Key recovery */
#define CFG_DUAL_CTRL_FOR_KEYRECOVERY_FLAG "DUAL_CTRL_FOR_KEYRECOVERY_FLAG"
#define CFG_SENDER_MAILID               "SENDER_MAILID"
#define CFG_SMTP_SERVER				 "SMTP_SERVER"
#define CFG_EMAIL_DOMAIN			 "EMAIL_DOMAIN"
/* End Add: Feature request to support Dual Control for Key recovery */

/* Debugging level for Secure Channel */
#define VSSC_NONE_STR           "none"
#define VSSC_ERROR_STR          "error"
#define VSSC_INFO_STR           "info"
#define VSSC_DEBUG_STR          "debug"

#define DEBUG_FILE              "pestub.out"
#define CFG_FILE                "pestub.cfg"
#define DB_FILE                 "validuser.txt"
#define LUNA_CFG_FILE           "vsautoauth.conf"
#define KEY_FILE                "public.key"
#define NO_KEY_FILE             "nokey"
#define VSAASRV_LOG_FILE        "start.log"
#define VSAASRV_PATH            "VSAASRV_PATH"
#define VSAA_ENCODING_NAME      "character_encoding"


#define KEY_ACCT        "AccountNumber"
#define KEY_PIN         "PIN"
#define KEY_FIRST       "mail_firstName"
#define KEY_LAST        "mail_lastName"
#define KEY_USRID		"additional_field5"
#define KEY_EMAIL		"mail_email"
#define KEY_MIDDLE		"mail_middleName"
#define KEY_SSN			"Social_Security_Number"
#define KEY_CHALLENGE	"Challenge_Phrase"
#define KEY_DOB			"usb_dob"
#define KEY_DL			"Driver_License_Number"
#define KEY_WORKPHONE	"additional_field4"
#define KEY_AUTH		"authenticate"
#define KEY_DIRECTORY	"xxx"

/*
 * Common configuration keyword Old key manager files jhuang
 */
#define CFG_CERTFILE    "CERTFILE"
#define CFG_ENCCERT     "ENCCERT"
#define CFG_CACERT      "CACERT"
//#define CFG_P12PATH     "PKCS#12 Storage Location"
//#define CFG_P12LIFETIME "PKCS#12 Lifetime"
//#define CFG_P12_PWD_LEN "PKCS#12 Password Length"
#define CFG_LUNA_SLOT   "LUNA_SLOT"
#define CFG_CRS_HOST		"URL Host"
#define CFG_CRS_URL			"URL File Path"
#define CFG_CRS_PORT    "URL Port"
//#define CFG_KEY_SIZE    "Key Size"
#define CFG_PROXY_HOST  "Proxy Host"
#define CFG_PROXY_PORT  "Proxy Port"
#define CFG_USE_PROXY   "Use Proxy"
#define CFG_MGMT_PORT		"Management Port"
#define DEBUG_FILE		  "pestub.out"
#define CFG_FILE		    "pestub.cfg"
#define DB_FILE			    "validuser.txt"
#define LUNA_CFG_FILE		"vsautoauth.conf"
#define CFG_KEY					"KEY"
#define CFG_KEY_PSWD		"Key Password"
#define CFG_ENABLE_SSL	"Enable SSL"
#define CFG_PRODUCTION_URL	"Production URL"

#define KEY_COMMONNAME  "common_name"

#define KRSP						"\\cfg\\krsp\\"
#define KRSP_PRODUCTION "\\cfg\\krsp.production\\"
#define KRSP_TEST			  "\\cfg\\krsp.test\\"
/*
 * Common configuration keyword Old key manager files jhuang
 */

/*
 * Luna Token Models:
 */
#define LUNA_TOKEN_MODEL_INVALID	0x00000000
#define LUNA_TOKEN_MODEL_RA_2			0x00000001
#define	LUNA_TOKEN_MODEL_SA_PCI		0x00000002
#define	LUNA_TOKEN_MODEL_PCM			0x00000003

// These strings must have length 16
#define LUNA_TOKEN_MODEL_STRING_RA		"LunaRA          "
#define LUNA_TOKEN_MODEL_STRING_SA		"LunaSA          "
#define LUNA_TOKEN_MODEL_STRING_PCI_1	"K3Base          "
#define LUNA_TOKEN_MODEL_STRING_PCI_2 "K3/G3 Device    "
#define LUNA_TOKEN_MODEL_STRING_PCM		"G4Base          "

/*
 * external function prototypes in vsutil.cpp
 */
void        Dump        (FILE *debugFile, const char *msg, const VSAA_NAME list[]);
VSAA_NAME * Duplicate	(const VSAA_NAME list[]);
size_t      Entries     (const VSAA_NAME list[]);
const char *FindName    (const char *pszName, size_t nameLen, const VSAA_NAME userInput[]);
VSAA_STATUS GetConfig   (const char *configFile, VSAA_NAME param[]);
void        Release     (VSAA_NAME **list);
int         FlattenNamesAlloc(VSAA_STATUS status, const VSAA_NAME *anInput, unsigned long *len, unsigned char **buffer);
VSAA_NAME * ResurrectNamesAlloc(unsigned long len, const unsigned char *buffer, VSAA_STATUS *status);
VSAA_STATUS ExtractDn(const VSAA_NAME *input, VSAA_NAME **dn);
// jhuang commented out for onsite50 void        Log(FILE *debugFile, const char *format, ...);
void        StartDebugger(const char *fileName);
VSAA_STATUS VerifyExchangeDll(const VSAA_NAME userInput[], FILE *debugFile);
VSAA_STATUS ChangeValueAlloc (VSAA_NAME userInput[], 
                              const char *name, const char *newValue);
VSAA_STATUS AppendNameValueAlloc (VSAA_NAME **inOutList, 
                                  VSAA_NAME *nameValue);
VSAA_STATUS MungeForVBScriptAlloc (const char *stringToMunge, char **mungedString);
void        LogName(const char *func, const char *name, const VSAA_NAME list[]);
bool        FileEqual (FILE *fp1, FILE *fp2);



/*
 * external function prototypes in vsutil.cpp
 */
#endif

