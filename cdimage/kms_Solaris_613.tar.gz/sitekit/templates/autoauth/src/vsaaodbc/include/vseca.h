
/*--------------------------------------------------------------------\
| Copyright (C) VeriSign, Inc. created 1998. All rights reserved.     |
| This is an unpublished work protected as such under copyright law.  |  
| This work contains proprietary, confidential, and trade secret      |
| information of VeriSign, Inc.  Use, disclosure or reproduction      |
| without the expressed written authorization of VeriSign, Inc.       |
| is prohibited.                                                      |
\--------------------------------------------------------------------*/



#include "global.h"
#include "bsafe.h"
#include "tipem.h"
#include "ecatools.h"
#include "luna.h"
#include "Ckbridge.h"
#include "innerluna.h"
#include "vsaabase64.h"


static int VSECA_Init(POINTER *handle);
static void VSECA_LunaCleanup(POINTER *handle);
static VSAA_STATUS PaddingAlloc(ITEM* out, ITEM *in, int blockSize);
static VSAA_STATUS DropPaddingAlloc(ITEM* out, ITEM *in, int blockSize);
static int VSECA_Encrypt3DESAlloc(ITEM *encryptedData, ITEM Data);
static int VSECA_Decrypt3DESAlloc(ITEM *decryptedData, ITEM encryptedData);
static int Luna3DESEncryptAllocStaticIV
   (ITEM *encryptedData, ITEM *initialVector, ITEM *data, CK_OBJECT_HANDLE des3KeyHandle,
    POINTER handle);
