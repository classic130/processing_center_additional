using System;
using System.Collections.Generic;
using System.Text;
using VeriSign.Cert.Mangment;
using VeriSign.Cert.Enrollment;
using System.Web.Services.Protocols;
using System.Security.Cryptography.X509Certificates;

namespace SampleClient
{
    /**
     * This class demonstrate how to use CertificateManagement API. Complete demonstration of usage is available in SampleClient
     */
    class SampleCertMgmtClient
    {
	    /**
	     * This function is for revoke a certificate
	     */
	    public int revokeCertificate (ref X509Certificate2 cert, RevokeReasonCodeEnum revokeReasonCodeEnum)
        {
		    return updateCertificateStatus(ref cert, revokeReasonCodeEnum, OperationTypeEnum.Revoke); 
	    }

	    /**
	     * This function suspend a certificate
	     */
        public int suspendCertificate(ref X509Certificate2 cert)
        {
            return updateCertificateStatus(ref cert, RevokeReasonCodeEnum.Unspecified, OperationTypeEnum.Suspend); 
	    }

	    /**
	     * This function resume a certificate
	     */
        public int resumeCertificate(ref X509Certificate2 cert)
        {
            return updateCertificateStatus(ref cert, RevokeReasonCodeEnum.Unspecified, OperationTypeEnum.Resume);
	    }	

	    /**
	     * A function to carry out real task of update cert status
	     */
        protected int updateCertificateStatus(ref X509Certificate2 cert, RevokeReasonCodeEnum revokeReasonCodeEnum, OperationTypeEnum operationTypeEnum)
        {
		    //Step 1: create request
		    UpdateCertificateStatusRequestType updateCertificateStatusRequest = new UpdateCertificateStatusRequestType();
    		
		    //Step 2: setup version type
		    updateCertificateStatusRequest.version = certMgmtAPIVersion;
    		
		    //Step 3: set up the cert serial
            updateCertificateStatusRequest.certificateSerialNumber = cert.GetSerialNumberString();
            updateCertificateStatusRequest.certificateIssuer = cert.IssuerName.Name;
    		
		    //Step 4: setup revoke reason code for revoke. null means unspecified.
            if (RevokeReasonCodeEnum.Unspecified != revokeReasonCodeEnum) 
            {
			    updateCertificateStatusRequest.revocationReason = revokeReasonCodeEnum;
		    }
    		
		    //Step 5: setup operation type
		    updateCertificateStatusRequest.operationType = operationTypeEnum;
    		
		    //Step 6 prepare for the request
		    certificateManagementService certificateManagementServiceStub = new certificateManagementService();
    		
		    //Step 7: create stub and send request
            SoapHttpClientProtocol stub = (SoapHttpClientProtocol)certificateManagementServiceStub;
            if (false == Utils.SetClientAuth(ref stub, SampleParameters.RACertificateDN))
            {
                return 0; //Error
            }

            certificateManagementServiceStub.Url = SampleParameters.certificateMgmtURL;
            
            Console.WriteLine("\tMaking Web Service call for Certificate Update.");
            UpdateCertificateStatusResponseType updateCertificateStatusResponse = certificateManagementServiceStub.updateCertificateStatus(updateCertificateStatusRequest);
            return updateCertificateStatusResponse.successCode;
 	    }

	    /**
	     * This function prepare and send the key recovery request to enterprise server
	     */
	    public RequestKeyRecoveryResponseMessageType requestKeyRecovery(ref X509Certificate2 cert, X509Certificate2 adminCert, String pKCS12Passwd)
        {
		    //Step 1: create requestKeyRecoveryMessageType
		    RequestKeyRecoveryMessageType  requestKeyRecoveryMessage = new RequestKeyRecoveryMessageType();
    		
		    //Step 2: setup version type
		    requestKeyRecoveryMessage.version = certMgmtAPIVersion;
    		
		    //Step 3: set up the certificate serial
		    requestKeyRecoveryMessage.certificateSerialNumber = cert.GetSerialNumberString();
            requestKeyRecoveryMessage.certificateIssuer = cert.IssuerName.Name;
    		
		    //Step 4. setup adminID
            requestKeyRecoveryMessage.adminID = Convert.ToBase64String(adminCert.GetRawCertData());
    		
		    //Step 5. setup pkcs12 password (optional component
		    if (null != pKCS12Passwd) 
            {
			    requestKeyRecoveryMessage.pKCS12Password = pKCS12Passwd;
		    }
    		
		    //Step 6: create stub and send request
            certificateManagementServiceVS certificateManagementServiceStub = new certificateManagementServiceVS();
            SoapHttpClientProtocol stub = (SoapHttpClientProtocol)certificateManagementServiceStub;
            if (false == Utils.setpEnterpriseServiceAuthentication(ref stub, SampleParameters.enterpriseServerUserID, SampleParameters.enterpriseServerUserPasswd))
            {
                return null; //Error
            }

            certificateManagementServiceStub.Url = SampleParameters.enterpriseCertificateMgmtURL;

            Console.WriteLine("\tMaking Web Service call for Certificate Recovery.");
		    RequestKeyRecoveryResponseMessageType requestKeyRecoveryResponseMessage = certificateManagementServiceStub.keyRecovery(requestKeyRecoveryMessage);
            return requestKeyRecoveryResponseMessage;
	    }

	    /**
	     * This function saves each p12 to a file and the corresponding password to the file with suffix ".password"
	     */
	    public X509Certificate2 processKeyRecoveryResponse(RequestKeyRecoveryResponseMessageType keyRecoveryResponse, String certFileName, ref bool isDualApprovalRequired)
        {
            X509Certificate2 cert = null;
		    //Step 1: check if need additional admin approval before recovery
		    int pendingAdminApproval = keyRecoveryResponse.adminApprovalPendingCount;
    		
		    //Step 2: return in case that more admin approval is needed
            if (pendingAdminApproval > 0)
            {
                isDualApprovalRequired = true;
                return cert;
            }
            else
            {
                isDualApprovalRequired = false;
            }
    		
		    //Step 3: get security tokens and password and save them to file
		    String pKCSpasswd = keyRecoveryResponse.pKCS12Password;
            foreach (String pKCS12Message in keyRecoveryResponse.pKCS12Message)
            {
                Utils.base64decodeAndSavetoFile(certFileName, pKCS12Message);
                Utils.saveToTextFile(certFileName + ".password", pKCSpasswd);
                cert = new X509Certificate2(certFileName, pKCSpasswd);
                break; //There will only be one cert in the response
		    }
            return cert;
	    }

        /**
        * This function demonstrate how to prepare cert element for renewal
        */
        public BinarySecurityTokenType prepareCertX509(X509Certificate2 cert)
        {
            //create BinaryToken Object
            BinarySecurityTokenType binarySecurityTokenType = new BinarySecurityTokenType();

            // Specify the encoding type for the BinarySecurityTokenType element.
            binarySecurityTokenType.EncodingType = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd#base64binary";

            // Specify the value type of the enrollment request data. In this case, it's a PKCS#10 type.
            binarySecurityTokenType.ValueType = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-x509-token-profile-1.0#X509v3";

            // Provide the base-64 encoded X.509 value.
            binarySecurityTokenType.Value = Convert.ToBase64String(cert.GetRawCertData());

            return binarySecurityTokenType;
        }

        protected static String certMgmtAPIVersion = "1.0";
    }
}
