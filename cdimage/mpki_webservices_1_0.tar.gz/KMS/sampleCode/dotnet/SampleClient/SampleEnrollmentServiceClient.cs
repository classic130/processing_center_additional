﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Xml;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Xml.Serialization;
using System.Web.Services.Protocols;

using VeriSign.Cert.Enrollment;

namespace SampleClient
{
    /**
     * This class demonstrate how to enroll for a certificate from VeriSign PKI Enrollment Web Service
     * <p> The service stub veriSignCertIssuingService and supporting classes are generated using WSDL.exe tool. Please see the readme.txt file for more details.
     */

    class SampleEnrollmentServiceClient
    {
        public SampleEnrollmentServiceClient(CertificateEnrollmentPolicy enrollmentPolicy, String profileOID)
        {
            this.enrollmentPolicy = enrollmentPolicy;
            this.profileOID = profileOID;
            deliveryFormat = enrollmentPolicy.attributes.systemInfo.certificateDeliveryFormat;
        }

        /**
         * This function can enroll for new certificate, renewed certificate and a keyescrow certificate
        */
        public RequestSecurityTokenResponseType enrollForCertificate(RequestTypeEnum requestType, X509Certificate2 enrollCert, ulong validityOverrideDays)
        {
            RequestSecurityTokenResponseType RequestSecurityTokenResponseReturn = null;
            do{
                //map to hold input NVPs            
                Hashtable inputNVPsMap = new Hashtable();

		        //Step 1: prepare request against RAPolicy
		        Console.WriteLine("  Prepare request against RA Policy");
		        if (false == prepareRequestAgainstRAPolicy())
                    break; //Error condition

		        //Step 2: prepare request against ClientPolicy
                Console.WriteLine("  Prepare request against Client Policy");
                if (false == prepareRequestAgainstClientPolicy(requestType, enrollCert))
                    break;//Error condition

                //Step 3: prepare request against certificateValidity policy
                Console.WriteLine("  Prepare request against Certificate Validity Policy");
                if (false == prepareRequestAgainstCertificateValidity(requestType, enrollCert, validityOverrideDays))
                    break;//Error condition
                
                //Step 4: prepare request against certificateOverrideValidity
                Console.WriteLine("  Prepare request against Certificate Override Validity Policy");
                prepareRequestAgainstCertificateOverrideValidity(validityOverrideDays, ref inputNVPsMap);

                //Check policies applicable to Enrollment only
                if (0 == requestType.CompareTo(RequestTypeEnum.httpdocsoasisopenorgwssxwstrust200512Issue))
                {
                    //Step 5: prepare NVPs for subject name using subjectNameInfo policy
                    Console.WriteLine("  Prepare request against Subject Name Info policy");
                    prepareRequestAgainstSubjectNameInfo(ref inputNVPsMap);

                    //Step 6: prepare NVPs for extensions including SAN, public extensions and private extensions using extensions policy
                    Console.WriteLine("  Prepare request against Extensions policy");
                    prepareRequestAgainstExtensions(ref inputNVPsMap);
                }

                //Step 7: prepare NVPs based on systemInfoPolicy
                Console.WriteLine("  Prepare request against System Info policy");
                prepareRequestAgainstSystemInfo(ref inputNVPsMap);

                //Step 8: prepare request using privateKeyAttributes policy for PKCS10 and PKCS7
                PrivateKeyInfo privateKeyInfo = enrollmentPolicy.attributes.privateKeyAttributes;

                //in case of non keyescrow, prepare PKCS10 
                BinarySecurityTokenType binarySecurityTokenPKCS10 = null;
                BinarySecurityTokenType binarySecurityTokenPKCS7 = null;

                if (privateKeyInfo.keyescrow)
                {
                    //For key escrow, set up key size
                    inputNVPsMap.Add("keysize", privateKeyInfo.keysize.ToString()); //TODO: there should be a NVP definition in the schema for this.
                }
                else
                {
                    binarySecurityTokenPKCS10 = preparePKCS10AgainstPrivateKeyInfo();
                }

                if (0 == requestType.CompareTo(RequestTypeEnum.httpdocsoasisopenorgwssxwstrust200512Renew))
                {
                    binarySecurityTokenPKCS7 = prepareCertX509(enrollCert);
                }

                //Step 9: assemble the request

                //Step: 9.a
                //create RequestVSSecurityTokenEnrollment object. This object will contain all request information. 		
                RequestVSSecurityTokenEnrollmentType requestVSSecurityTokenEnrollment = new RequestVSSecurityTokenEnrollmentType();

                //Step: 9.b
                //set version of the request
                requestVSSecurityTokenEnrollment.version = enrollmentAPIVersion;
                Console.WriteLine("\tSetting: version = {0}", enrollmentAPIVersion);

                //Step: 9.c
                //set the profile oid that corresponds to the certificateEnrollmentPolicy oid
                requestVSSecurityTokenEnrollment.certificateProfileID = profileOID;
                Console.WriteLine("\tSetting: certificateProfileID = {0}", profileOID);

                //Step: 9.d
                //set token type to PKCS7
                requestVSSecurityTokenEnrollment.tokenType = TokenType.httpdocsoasisopenorgwss200401oasis200401wssx509tokenprofile10PKCS7;

                //Step: 9.e
                //set request type	
                requestVSSecurityTokenEnrollment.requestType = requestType;

                //Step 9.f
                //set NVPs for Subject DN, SAN, standard extensions and private extension
                requestVSSecurityTokenEnrollment.nameValuePair = mapToNameValueType(inputNVPsMap);

                //Step: 9.g
                // set PKCS10
                if (!privateKeyInfo.keyescrow)
                {
                    if (0 != requestType.CompareTo(RequestTypeEnum.httpdocsoasisopenorgwssxwstrust200512Renew))
                    {
                        requestVSSecurityTokenEnrollment.binarySecurityToken = new BinarySecurityTokenType[1];
                        requestVSSecurityTokenEnrollment.binarySecurityToken[0] = binarySecurityTokenPKCS10;
                        Console.WriteLine("\tAttaching the P10 for the enroll request.");
                    }
                    else
                    {
                        requestVSSecurityTokenEnrollment.binarySecurityToken = new BinarySecurityTokenType[2];
                        requestVSSecurityTokenEnrollment.binarySecurityToken[0] = binarySecurityTokenPKCS10;
                        Console.WriteLine("\tAttaching the P10 for the renewal request.");
                        requestVSSecurityTokenEnrollment.binarySecurityToken[1] = binarySecurityTokenPKCS7;
                        Console.WriteLine("\tAttaching the X509 for the renewal request.");
                    }
                }
                else
                {
                    if (0 == requestType.CompareTo(RequestTypeEnum.httpdocsoasisopenorgwssxwstrust200512Renew))
                    {
                        requestVSSecurityTokenEnrollment.binarySecurityToken = new BinarySecurityTokenType[1];
                        requestVSSecurityTokenEnrollment.binarySecurityToken[0] = binarySecurityTokenPKCS7;
                        Console.WriteLine("\tAttaching the P10 for the renewal request.");
                    }
                }
                
                //Step 9.i
                //Create RequestVSSecurityToken

                RequestSecurityTokenType requestSecurityToken = new RequestSecurityTokenType();

                XmlElement[] Any = Utils.XMLSerializeRequestVSSecurityToken(requestVSSecurityTokenEnrollment);

                requestSecurityToken.Any = Any;

                //Step 10: create Stub and request for enroll
		
                //create stub for enrollment service
                veriSignCertIssuingServiceVS vsCertIssusingServiceStub = new veriSignCertIssuingServiceVS();
                SoapHttpClientProtocol stub = vsCertIssusingServiceStub as SoapHttpClientProtocol;
                //use different url and authentication method based on keyescrow
                if (Utils.isVeriSignWebServiceEndPoint(policyName))
                {
                    vsCertIssusingServiceStub.Url = SampleParameters.enrollmentURL;
                    Utils.setServiceAuthentication(true, ref stub);
                }
                else
                {
                    vsCertIssusingServiceStub.Url = SampleParameters.enterpriseServerURL;
                    Utils.setServiceAuthentication(false, ref stub);
                }

                try
                {
                    Console.WriteLine("\tMaking Web Service call for Enroll/Renewal.");
                    //send request and return RequestSecurityTokenResponse
                    RequestSecurityTokenResponseReturn = vsCertIssusingServiceStub.RequestSecurityToken(requestSecurityToken);
                }
                catch (Exception exc)
                {
                    Console.WriteLine("\tWeb Service Call failed. Error Message: '{0}'.", exc.Message);
                    return null;
                }
             } while (false);
            return RequestSecurityTokenResponseReturn;
        }

        /**
        * This function demonstrate how to get the value of RAPolicy and how to use it.
        */
        private bool prepareRequestAgainstRAPolicy()
        {
            RAPolicy rAPolicy = enrollmentPolicy.attributes.rAPolicy;
            if (null != rAPolicy)
            {
                if (rAPolicy.registerUser)
                {
                    //TODO: in this case , the policy requires that you register user before enroll for the certificate. 
                }
                if (rAPolicy.verifyUser)
                {
                    //TODO: in this case , the policy requires that you validate user before enroll for the certificate. 
                }
            }
            return true;
        }

        /**
        * This function demonstrate how to prepare request using informtion in clientPolicy
        */
        public bool prepareRequestAgainstClientPolicy(RequestTypeEnum requestType, X509Certificate2 cert)
        {
            bool ReturnValue = true;
		    ClientPolicy clientPolicy = enrollmentPolicy.attributes.clientPolicy;
            if (null != clientPolicy)
            {
                //Step 1: check the renewal overlap period
                if (0 == requestType.CompareTo(RequestTypeEnum.httpdocsoasisopenorgwssxwstrust200512Renew))
                {
                    int certRenewalOverlap = clientPolicy.certRenewalOverlap;
                    bool canRenewExpiredCerts = clientPolicy.renewExpiredCerts;
                    if (!Utils.isCertificateInRenewalWindow(cert, certRenewalOverlap, canRenewExpiredCerts))
                    {
                        Console.WriteLine("Certificate is Not in the Renewal Period.");
                        ReturnValue = false;
                    }
                }
            }
            return ReturnValue;
	    }

        /**
        * This function demonstrate how to prepare request use certificateValidity policy
        */
        public bool prepareRequestAgainstCertificateValidity(RequestTypeEnum requestType, X509Certificate2 cert, ulong validityOverrideDays)
        {
            bool ReturnValue = true;
            do{
		        //in case validityOverrideDays is zero or less, no action need take, use the system default validity
		        if (validityOverrideDays <= 0) 
                    break;
        		
                CertificateValidity certificateValidity = enrollmentPolicy.attributes.certificateValidity;
		        if ( (null != certificateValidity) && (certificateValidity.validityPeriodDays < validityOverrideDays) )
                {
			        Console.WriteLine("prepareRequestAgainstCertificateValidity: overideValidity can not exceed validity days");
                    ReturnValue = false;
                    break;
		        }

		        // in case of renew, make sure cert is in the renewal window
		        if ( (null != certificateValidity) && (0 == requestType.CompareTo(RequestTypeEnum.httpdocsoasisopenorgwssxwstrust200512Renew)))  
                {  
	                ulong certRenewalOverlap = certificateValidity.renewalPeriodDays;
                    if (!Utils.isCertificateInRenewalWindow(cert, (int)certRenewalOverlap, false))
                    {
                        Console.WriteLine("Certificate is Not in the Renewal Period.");
                        ReturnValue = false;
                    }
	            }
            }while(false);
            return ReturnValue;
	    }

        /**
        * This function demonstrate how to prepare request using CertificateOverrideValidity
        */
        public Hashtable prepareRequestAgainstCertificateOverrideValidity(ulong validityOverrideDays, ref Hashtable overrideValidityName)
        {
            if (validityOverrideDays > 0)
            {
                overrideValidityName.Add("overrideValidityDays", validityOverrideDays.ToString());
                Console.WriteLine("\tSetting: overrideValidityDays = {0}", validityOverrideDays.ToString());
            }
            return overrideValidityName;
        }

        /**
        * This function demonstrate how to prepare NVPs for subject name using SubjectNameInfo
        */
        public Hashtable prepareRequestAgainstSubjectNameInfo(ref Hashtable subjectNameMap)
        {
	        //get all subjectName attributes from policy 
	        subjectName subjectNameAttributes = enrollmentPolicy.attributes.subjectNameInfo;

	        //loop through all subjectNameAttributes 
            foreach (subjectNameAttribute item in subjectNameAttributes.subjectNameAttribute) 
            {
                foreach(AttributeNameValuePairType attributeType in item.subjectNameAttributeNameValuePair)
                {
                    //get the name defined in subjectNameAttributes
                    String name = Utils.trimDollarSign(attributeType.attributeNameValue.Value);

    		        //get the value from input
                    String value = (String)SampleParameters.sampleInput[name];
    		        if (null != value) 
                    {
                        Console.WriteLine("\tSetting: {0} = {1}", name, value);
                        subjectNameMap.Add(name, value);
    		        }

    		        //check if the nameValue pair is mandatory, if yes and missing from input, throw exception
                    if ((value == null) && (true == attributeType.attributeNameValue.mandatory))
                    {
    			        Console.WriteLine("Missing required name value pair (subjectName): " + name);
                        throw new Exception("Missing required name value pair (subjectName): " + name);
    		        }
        	    }
            }
	        return subjectNameMap;		
        }

        /**
        * This function demonstrate how to prepare NVPs for SAN, standard extensions and private extensions using extensions policy
        */
	    public Hashtable prepareRequestAgainstExtensions(ref Hashtable extensionHash)
        {
		    if (null != enrollmentPolicy.attributes.extensions) 
            {
			    //loop through all extensions
	            foreach (Extension extension in enrollmentPolicy.attributes.extensions) 
                {
        		    foreach(Object item in extension.extensionSyntax.Items)
                    {
                        AttributeNameValuePairType attrNameValue = item as AttributeNameValuePairType;
                        if (null != attrNameValue)
                        {
                            //get the name defined in subjectNameAttributes
                            String name = attrNameValue.attributeName;

                            //get the value from input
                            String value = (String)SampleParameters.sampleInput[name];
                            if (null != value)
                            {
                                Console.WriteLine("\tSetting (Extension NVP): {0} = {1}", name, value);
                                extensionHash.Add(name, value);
                            }

                            //check if the nameValue pair is mandatory, if yes and missing from input, throw exception
                            if ((value == null) && (true == attrNameValue.attributeNameValue.mandatory))
                            {
                                Console.WriteLine("Missing required name value pair (extension): " + name);
                                throw new Exception("Missing required name value pair (extension): " + name);
                            }
                        }
                        else
                        {
                            extensionValueType valueType = item as extensionValueType;
                            if (null != valueType)
                            {
                                String name = Utils.trimDollarSign(valueType.Value);

                                //get the value from input
                                String value = (String)SampleParameters.sampleInput[name];
                                if (null != value)
                                {
                                    Console.WriteLine("\tSetting (Extension NVP): {0} = {1}", name, value);
                                    extensionHash.Add(name, value);
                                }

                                //check if the nameValue pair is mandatory, if yes and missing from input, throw exception
                                if ((value == null) && (true == valueType.mandatory))
                                {
                                    Console.WriteLine("Missing required name value pair (extension): " + name);
                                    throw new Exception("Missing required name value pair (extension): " + name);
                                }
                            }
                        }
        		    }
	            }
		    }	
		    return extensionHash;
	    }

        /**
        * This function demonstrate how to prepare NVPs for cet publish and search params using SystemInfo policy
        */
	    public Hashtable prepareRequestAgainstSystemInfo(ref Hashtable systemHash)
        {
		    //get PublishCert and CACertPublishNameValuePair
            PublishCert publishCert = enrollmentPolicy.attributes.systemInfo.cACertPublish;

		    //in case it is Publish is clientProvided, get name value pair and make sure it match the restricted values defined in schema
            if (publishCert == PublishCert.clientProvided)
            {
                String name = "publish_flag";
                String value = (String)SampleParameters.sampleInput[name];
                if (null == value)
                {
                    Console.WriteLine("Missing required name value pair for System Info: " + name);
                    throw new Exception("missing required name value pair for System Info: " + name);
                }

                PublishCert userPublishCert = (PublishCert)Enum.Parse(typeof(PublishCert), value, true);
                systemHash.Add(name, value);
            }
            else
            {
                Console.WriteLine("\tPublish Cert can't be set by user.");
            }
            return systemHash;
	    }

        /**
        * This function demonstrate how to prepare PKCS10 using PrivateKeyInfo policy
        */
        public BinarySecurityTokenType preparePKCS10AgainstPrivateKeyInfo() 
        {
            String pKCS12FileName = null;
            String pKCS12Passwd = null;
	        //create BinaryToken Object
	        BinarySecurityTokenType binarySecurityTokenType = new BinarySecurityTokenType();

            // Specify the encoding type for the BinarySecurityTokenType element.
            binarySecurityTokenType.EncodingType = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd#base64binary";

            // Specify the value type of the enrollment request data. In this case, it's a PKCS#10 type.
            binarySecurityTokenType.ValueType = "http://schemas.verisign.com/pkiservices/2009/07/PKCS10";

            //get key size from policy
            int keySize = enrollmentPolicy.attributes.privateKeyAttributes.keysize;

            Console.WriteLine("\tCreating a CSR with Public Key of Length {0}.", keySize);
            //generate CSR based on key size. Please use your own function to suite your purpose.
    		String pkcs10 = Utils.generateCSRWithPublicKeyOnly(keySize, pKCS12FileName, pKCS12Passwd); 

            // Provide the base-64 encoded PKCS#10 value.
            binarySecurityTokenType.Value = pkcs10;

            return binarySecurityTokenType;
        }


        /**
        * convert the Hashtable of NVPs to NameValueType[]
        */
        public NameValueType[] mapToNameValueType(Hashtable input)
        {
		    NameValueType[] nameValuePairs = new NameValueType[input.Count];
            int index = 0;
		    foreach(String key in input.Keys)
            {
			    nameValuePairs[index]= new NameValueType();
			    nameValuePairs[index].name = key;
			    nameValuePairs[index].value = (String)input[key];
			    index++;
		    }
		    return nameValuePairs;
	    }

        /**
        * This function process the response by saving the certificate, PKCS12 and pKCS12 password to files.
        */
        public string processRequestSecurityTokenResponse(RequestSecurityTokenResponseType response)
        {
            XmlElement[] Any = response.Any;
            String requestSecurityTokenResponse = Any[0].InnerXml;
            System.IO.StringReader read = new StringReader(requestSecurityTokenResponse); 
            XmlSerializer serializer = new XmlSerializer(typeof(RequestVSSecurityTokenResponseEnrollmentType)); 
            XmlReader reader = new XmlTextReader(read);
            RequestVSSecurityTokenResponseEnrollmentType responseReturn = null;
            try
            {
                responseReturn = (RequestVSSecurityTokenResponseEnrollmentType)serializer.Deserialize(reader);
                return null;
            }
            catch(Exception e)
            { throw e; }
            finally
            {
                reader.Close();
                read.Close();
                read.Dispose();
            }
        }

        /**
        * This function demonstrate how to prepare cert element for renewal
        */
        public BinarySecurityTokenType prepareCertX509(X509Certificate2 cert)
        {
            //create BinaryToken Object
            BinarySecurityTokenType binarySecurityTokenType = new BinarySecurityTokenType();

            // Specify the encoding type for the BinarySecurityTokenType element.
            binarySecurityTokenType.EncodingType = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd#base64binary";

            // Specify the value type of the enrollment request data. In this case, it's a PKCS#10 type.
            binarySecurityTokenType.ValueType = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-x509-token-profile-1.0#X509v3";

            // Provide the base-64 encoded X.509 value.
            binarySecurityTokenType.Value = Convert.ToBase64String(cert.GetRawCertData());

            return binarySecurityTokenType;
        }

        /**
        * This function process the response by saving the certificate, PKCS12 and pKCS12 password to files.
        */
        public X509Certificate2 ParseResponseTokenElement(RequestSecurityTokenResponseType response, String certFileName, ref string password)
        {
            X509Certificate2 cert = null;
            XmlElement[] Any = response.Any;
            String requestSecurityTokenResponse = "<response>" + Any[0].InnerXml + "</response>";
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(requestSecurityTokenResponse);

            XmlNodeList binarySecurityTokenNL = xmlDoc.GetElementsByTagName("binarySecurityToken");
            String blob = binarySecurityTokenNL[0].InnerText;

            Utils.base64decodeAndSavetoFile(certFileName, blob);

            if (deliveryFormat == DeliveryFormat.httpschemasverisigncompkiservices200907PKCS12)
            {
                XmlNodeList pKCS12PasswordNL = xmlDoc.GetElementsByTagName("pKCS12Password");
                if (null != pKCS12PasswordNL)
                {
                    if (null != pKCS12PasswordNL[0])
                    {
                        password = pKCS12PasswordNL[0].InnerText;
                        String passwordFileName = certFileName + ".password";
                        if (File.Exists(passwordFileName))
                        {
                            File.Delete(passwordFileName);
                        }
                        TextWriter textWriter = new StreamWriter(passwordFileName, true);
                        textWriter.WriteLine(password);
                        textWriter.Close();
                    }
                }

                Console.WriteLine("\tDelivery Format is PKCS#12.");
                Console.WriteLine("\tPassword: {0}", password);

                cert = new X509Certificate2(certFileName, password);
            }
            else
            {
                Console.WriteLine("\tDelivery Format is PKCS#7. ");
                cert = Utils.getCertFromPKCS7(blob);
            }

            if (null != cert)
            {
                Console.WriteLine("\tReceived End Entity Certificate with Serial Number '{0}'.", cert.GetSerialNumberString());
            }
            return cert;
        }

        public String policyName = null;
        private CertificateEnrollmentPolicy enrollmentPolicy;
        private String profileOID;
        private DeliveryFormat deliveryFormat;
        private static String enrollmentAPIVersion = "1.0";
    }
}
