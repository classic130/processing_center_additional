﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using VeriSign.Cert.Enrollment;
using VeriSign.Cert.Mangment;

/**
 * This is the main sample code. It use SamplePolicyServiceClient, SampleEnrollmentServiceClient and SampleCertMgmtClient
 * to demonstrate how to get enrollment policy, enroll, renew, suspend, resume and revoke a certificate. 
 */

namespace SampleClient
{
    class SampleClient
    {
        static void Main(string[] args)
        {
            //To obtain the DN of the certificates in your user store, uncomment out the following line, 
            //then rebuild and run this sample application. Do this before modifying the sampleParameters.cs file, 
            //Remember to comment these lines back out before running the sample application for certificate 
            //lifecycle tasks.
            //            Utils.ListCerts(); return;

            String certSerialNumber;
            X509Certificate2 enrollCert = null;
            X509Certificate2 renewCert = null;
            SampleEnrollmentServiceClient renewalEnrollmentServiceClient = null;
            SampleCertMgmtClient sampleCertMgmtClient = null;

            //Step 1: Gets an enrollment policy from Managed PKI Web Service
            Console.WriteLine("1. Getting the Enrollment Policy using VeriSign's Managed PKI Web Service.");
            SamplePolicyServiceClient policyServiceClient = SamplePolicyServiceClient.getInstance();
            if (policyServiceClient.IsValidPolicy())
            {
                Console.WriteLine("   Successfully got the enrollment policy.");
            }
            else
            {
                Console.WriteLine("   Failed to get the enrollment policy.");
            }

            //Step 2: Gets enrollment policies with an oid default name from PolicyServiceClient
            Console.WriteLine("\n2. Getting the Enrollment Policy details from enrollment policy response.");

            String signKMSPolicy = SampleParameters.PolicyName;
            CertificateEnrollmentPolicy[] enrollmentPolicies = policyServiceClient.getEnrollmentPoliciesByDefaultName(signKMSPolicy);
            if (null == enrollmentPolicies)
            {
                Console.WriteLine("   Failed to get the enrollment policy for the prefix {0}.", SampleParameters.PolicyName);
                return;
            }
            else
            {
                Console.WriteLine("   Successfully got the enrollment policy for the prefix {0}.", SampleParameters.PolicyName);
            }

            if (enrollmentPolicies.Length > 0)
            {
                Console.WriteLine("\n3. Enrolling for a certificate using VeriSign's Managed PKI Web Service.");

                //Use the first enrollment policy returned to enroll for a certificate
                CertificateEnrollmentPolicy enrollmentPolicy = enrollmentPolicies[0];

                PrivateKeyInfo privateKeyInfo = enrollmentPolicy.attributes.privateKeyAttributes;

                //Step 3: Enrolls for a certificate. This certificate will have a short validity period so that 
                //the sample  application can immediately renew it
                //Checks if Certificate Validity can be overridden
                if ((null == enrollmentPolicy.attributes.certificateOverrideValidity) ||
                    (true == enrollmentPolicy.attributes.certificateOverrideValidity.overrideFlag))
                {
                    //Get renewal window from certificateValidity policy
                    ulong renewalPeriodDays = 0;
                    if (null != enrollmentPolicy.attributes.certificateValidity)
                    {
                        renewalPeriodDays = enrollmentPolicy.attributes.certificateValidity.renewalPeriodDays;
                    }

                    //Create the enrollment client
                    SampleEnrollmentServiceClient enrollmentServiceClient = new SampleEnrollmentServiceClient(enrollmentPolicy, policyServiceClient.getOIDByReferenceID(enrollmentPolicy.policyOIDReference).value);

                    enrollmentServiceClient.policyName = signKMSPolicy;
                    //Enrolls for a certificate. 
                    //Uses renewalPeriodDays to override Validity Days for the certificate so the application can 
                    //renew the certificate immediately (for demonstration purposes).
                    RequestSecurityTokenResponseType enrollResponse = enrollmentServiceClient.enrollForCertificate(RequestTypeEnum.httpdocsoasisopenorgwssxwstrust200512Issue, null, renewalPeriodDays);
                    if (null == enrollResponse)
                    {
                        Console.WriteLine("   Failed to enroll for a certificate.");
                        return;
                    }

                    //Processes the result
                    String enrollPassword = null;
                    String certFileName = Utils.getFileName(false, privateKeyInfo.keyescrow);
                    enrollCert = enrollmentServiceClient.ParseResponseTokenElement(enrollResponse, certFileName, ref enrollPassword);
                }

                Console.WriteLine("\n4. Renewing the certificate using VeriSign's Managed PKI Web Service.");
                //Step 4. Renews the certificate
                if (null != enrollCert)
                {
                    //Creates the enrollment client
                    renewalEnrollmentServiceClient = new SampleEnrollmentServiceClient(enrollmentPolicy, policyServiceClient.getOIDByReferenceID(enrollmentPolicy.policyOIDReference).value);
                    renewalEnrollmentServiceClient.policyName = SampleParameters.PolicyName;

                    //Renews the certificate, without overriding the default validity period.
                    RequestSecurityTokenResponseType responseRenew = renewalEnrollmentServiceClient.enrollForCertificate(RequestTypeEnum.httpdocsoasisopenorgwssxwstrust200512Renew, enrollCert, 0);

                    String renewPassword = null;
                    String renewCertFileName = Utils.getFileName(true, privateKeyInfo.keyescrow);
                    //Saves the certificate
                    renewCert = renewalEnrollmentServiceClient.ParseResponseTokenElement(responseRenew, renewCertFileName, ref renewPassword);
                }

                sampleCertMgmtClient = new SampleCertMgmtClient();

                Console.WriteLine("\n5. Suspending the certificate using VeriSign's Managed PKI Web Service.");
                //Step 5: Suspends the renewed certificate
                certSerialNumber = renewCert.GetSerialNumberString();
                int suspendResult = sampleCertMgmtClient.suspendCertificate(ref renewCert);
                if (0 == suspendResult)
                {
                    Console.WriteLine("   Successfully suspended certificate with serial number '{0}'.", certSerialNumber);
                }
                else
                {
                    Console.WriteLine("   Failed to suspend certificate with serial number '{0}'.", certSerialNumber);
                }

                Console.WriteLine("\n6. Resuming the certificate using VeriSign's Managed PKI Web Service.");
                //Step 6: Resume the renewed certificate
                int resumeResult = sampleCertMgmtClient.resumeCertificate(ref renewCert);
                if (0 == resumeResult)
                {
                    Console.WriteLine("   Successfully resumed certificate with serial number '{0}'.", certSerialNumber);
                }
                else
                {
                    Console.WriteLine("   Failed to resume certificate with serial number '{0}'.", certSerialNumber);
                }

                Console.WriteLine("\n7. Revoking the certificate using VeriSign's Managed PKI Web Service.");
                //Step 7: Revokes the renewed certificate
                int revokeResult = sampleCertMgmtClient.revokeCertificate(ref renewCert, RevokeReasonCodeEnum.KeyCompromise);
                if (0 == revokeResult)
                {
                    Console.WriteLine("   Successfully revoked certificate with serial number '{0}'.", certSerialNumber);
                }
                else
                {
                    Console.WriteLine("   Failed to revoke certificate with serial number '{0}'.", certSerialNumber);
                }
            }

            String encryptKMSPolicy = SampleParameters.EncryptPolicyName;
            CertificateEnrollmentPolicy[] enrollmentPoliciesKMS = policyServiceClient.getEnrollmentPoliciesByDefaultName(encryptKMSPolicy);
            if ((null != enrollmentPoliciesKMS) && (enrollmentPoliciesKMS.Length > 0))
            {
                Console.WriteLine("\n8. Enrolling for a certificate using the enterprise Key Management Service.");

                //Uses the first enrollmentPolicy to enroll for a certificate. 
                CertificateEnrollmentPolicy enrollmentPolicyKMS = enrollmentPoliciesKMS[0];
                SampleEnrollmentServiceClient enrollmentServiceClient = new SampleEnrollmentServiceClient(enrollmentPolicyKMS, policyServiceClient.getOIDByReferenceID(enrollmentPolicyKMS.policyOIDReference).value);

                enrollmentServiceClient.policyName = encryptKMSPolicy;

                //Enrolls for a certificate:
                //Uses renewalPeriodDays to override Validity Days for the certificate so the application can renew 
                //the certificate immediately (for demonstration purposes).
                RequestSecurityTokenResponseType enrollResponse = enrollmentServiceClient.enrollForCertificate(RequestTypeEnum.httpdocsoasisopenorgwssxwstrust200512Issue, null, 0);
                if (null == enrollResponse)
                {
                    Console.WriteLine("   Failed to enroll for a certificate.");
                    return;
                }

                //Processes the result
                String enrollPassword = null;
                String certFileName = SampleParameters.sampleOutputPath + SampleParameters.kmsEncryptCertFileName;
                enrollCert = enrollmentServiceClient.ParseResponseTokenElement(enrollResponse, certFileName, ref enrollPassword);

                if (enrollmentPolicyKMS.attributes.privateKeyAttributes.keyescrow)
                {
                    Console.WriteLine("\n9. Recovering key using VeriSign's Managed PKI Web Service.");
                    certSerialNumber = enrollCert.GetSerialNumberString();

                    String renewCertFileName = SampleParameters.sampleOutputPath + SampleParameters.kmsRecoverCertFileName;
                    bool isDualApprovalRequired = false;
                    //Step 5: Recovers the key
                    X509Certificate2 adminCert1 = new X509Certificate2(SampleParameters.enterpriseAdminCert1);
                    RequestKeyRecoveryResponseMessageType recoveryResponse1 = sampleCertMgmtClient.requestKeyRecovery(ref enrollCert, adminCert1, null);

                    //Makes a call to recover the certificate
                    renewCert = sampleCertMgmtClient.processKeyRecoveryResponse(recoveryResponse1, renewCertFileName, ref isDualApprovalRequired);

                    //Checks if the revocery was successful
                    if (isDualApprovalRequired)
                    {
                        //Uses an additional administrator certificate if the account needs dual approval for the recovery
                        X509Certificate2 adminCert2 = new X509Certificate2(SampleParameters.enterpriseAdminCert2);
                        RequestKeyRecoveryResponseMessageType recoveryResponse2 = sampleCertMgmtClient.requestKeyRecovery(ref enrollCert, adminCert2, null);

                        //Makes an additional call to recover the certificate, using the additional administrator certificate(s)
                        renewCert = sampleCertMgmtClient.processKeyRecoveryResponse(recoveryResponse2, renewCertFileName, ref isDualApprovalRequired);
                    }
                    if (null != renewCert)
                    {
                        Console.WriteLine("   Successfully recovered certificate with serial number '{0}'. New Serial Number is {1}.", certSerialNumber, renewCert.GetSerialNumberString());
                    }
                    else
                    {
                        Console.WriteLine("   Failed to recovered certificate with serial number '{0}'.", certSerialNumber);
                    }
                }
            }
        }
    }
}
