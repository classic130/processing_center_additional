/*
 * $Revision: 1.2 $
 * $Header: /cvsroot/mpki/vsaakm/vsaautil/include/vsaabase64.h,v 1.2 2002/09/25 23:34:33 buildman Exp $
 */

/*-----------------------------------------------------------------------\ 
| Copyright (C) VeriSign, Inc. created 1996, 1997. All rights reserved.  |
| This is an unpublished work protected as such under copyright law.     |
| This work contains proprietary, confidential, and trade secret         |
| information of VeriSign, Inc.  Use, disclosure or reproduction without |
| the expressed written authorization of VeriSign, Inc.  is prohibited.  |
\-----------------------------------------------------------------------*/


#ifndef _ENCODE_H_
#define _ENCODE_H_

static char *_encode_H = (char *) "$Id: vsaabase64.h,v 1.2 2002/09/25 23:34:33 buildman Exp $";

#ifdef  __cplusplus
extern "C" {
#endif

  /* Stolen from CVS/common/include/convfield.h */

#ifndef _ITEM_
#define _ITEM_ 1
  typedef struct {
    unsigned char *data;
    unsigned int len;
  } ITEM;
#endif

/* Base64Alloc 
 *	Encodes binary data into base64 format.
 */
int Base64Alloc (
    ITEM *,
    ITEM
    );

/* UnBase64Alloc 
 *	Decodes data in base64 format into binary format.
 */
int UnBase64Alloc (
    ITEM *,
    ITEM
    );

/* Bin2HascAlloc 
 *	Converts binary data to half ASCII characters.
 */
int Bin2HascAlloc (
    char **hasc,
    ITEM *bin
    );

/* Hasc2BinAlloc 
 *	Converts half ASCII characters to binary data.
 */
int Hasc2BinAlloc (
    ITEM *bin,
    char *hasc
    );

/* UudecodeAlloc 
 *	Takes uuencoded data and returns decoded data.
 */
int UudecodeAlloc ( 
    ITEM *uudecodedBuffer,
    ITEM uuencodedBuffer
    );

#ifdef  __cplusplus
}
#endif

#endif	/* _ENCODE_H_ */

