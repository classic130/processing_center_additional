//Function to check whether the activex control is already installed
function checkComponent()
{
<!-- VSSKBEGIN Apps/KeyManager#27 -->
<!-- VSSKEND Apps/KeyManager#27 -->
		return(temp);
}

//Function to redirect the flow after checking for the presence of activex control
function check(){
	var _flag=checkComponent();
	if (_flag == 1){
		window.open("../digitalidCenter.htm","_self");
	}
	else{	
<!-- VSSKBEGIN Apps/KeyManager#28 -->
<!-- VSSKEND Apps/KeyManager#28 -->
		
	}
}

