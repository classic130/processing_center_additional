
CREATE TABLE Addresses ( 
  AddressID                  NUMBER(38),
  EmployeeID                 NUMBER(38),
  PIN                        VARCHAR(16),
  FirstName                  VARCHAR(255),
  LastName                   VARCHAR(255),
  MiddleName                 VARCHAR(255),
  JobTitle                   VARCHAR(255),
  IntegerNumberTestCol       NUMBER(38),
  DateTestCol                DATE,
  FloatNumberTestCol         NUMBER(9,2),
  CurrencyTestCol            VARCHAR(64),
  Address                    VARCHAR(255),
  City                       VARCHAR(64),
  StateOrProvince            VARCHAR(64),
  PostalCode                 VARCHAR(64),
  Country                    VARCHAR(2),
  EmailAddress               VARCHAR(255),
  HomePhone                  VARCHAR(64),
  WorkPhone                  VARCHAR(64),
  FaxNumber                  VARCHAR(64),
  CertSerialNumber           VARCHAR(64),
  Certificate                VARCHAR(2000),
  CommonName                 VARCHAR(255),
  Notes                      VARCHAR(255),
  MailStop                   VARCHAR(255),
  CertificateStatus          VARCHAR(255)
);
  
DROP SEQUENCE VSAA_ADDRESS_ID;
CREATE SEQUENCE VSAA_ADDRESS_ID;

INSERT INTO Addresses ( 
  AddressID,
  EmployeeID,
  PIN,
  FirstName,
  LastName,
  MiddleName,
  JobTitle,
  Address,
  City,
  StateOrProvince,
  PostalCode,
  Country,
  EmailAddress,
  HomePhone,
  CommonName
) 
VALUES (
  VSAA_ADDRESS_ID.nextval,
  101,
  'password',
  'mgr1',
  'tester',
  'A.',
  'Manager',
  '1350 Charleston Road',
  'Mountain View',
  'CA',
  '94043',
  'US',
  'mgr1tester@foo.bar.com',
  '(650)123-4567',
  'mgr1 tester'
);

INSERT INTO Addresses ( 
  AddressID,
  EmployeeID,
  PIN,
  FirstName,
  LastName,
  MiddleName,
  JobTitle,
  Address,
  City,
  StateOrProvince,
  PostalCode,
  Country,
  EmailAddress,
  HomePhone,
  CommonName
) 
VALUES (
  VSAA_ADDRESS_ID.nextval,
  102,
  'password',
  'mgr2',
  'tester',
  'A.',
  'Manager',
  '1350 Charleston Road',
  'Mountain View',
  'CA',
  '94043',
  'US',
  'mgr2tester@foo.bar.com',
  '(650)123-4567',
  'mgr2 tester'
);
 
INSERT INTO Addresses ( 
  AddressID,
  EmployeeID,
  PIN,
  FirstName,
  LastName,
  MiddleName,
  JobTitle,
  Address,
  City,
  StateOrProvince,
  PostalCode,
  Country,
  EmailAddress,
  HomePhone,
  CommonName
) 
VALUES (
  VSAA_ADDRESS_ID.nextval,
  103,
  'password',
  'mgr3',
  'tester',
  'A.',
  'Manager',
  '1350 Charleston Road',
  'Mountain View',
  'CA',
  '94043',
  'US',
  'mgr3tester@foo.bar.com',
  '(650)123-4567',
  'mgr3 tester'
);
 
 
INSERT INTO Addresses ( 
  AddressID,
  EmployeeID,
  PIN,
  FirstName,
  LastName,
  MiddleName,
  JobTitle,
  Address,
  City,
  StateOrProvince,
  PostalCode,
  Country,
  EmailAddress,
  HomePhone,
  CommonName
) 
VALUES (
  VSAA_ADDRESS_ID.nextval,
  201,
  'password',
  'usr1',
  'tester',
  'A.',
  'Engineer',
  '1350 Charleston Road',
  'Mountain View',
  'CA',
  '94043',
  'US',
  'usr1tester@foo.bar.com',
  '(650)123-4567',
  'usr1 tester'
);
 
INSERT INTO Addresses ( 
  AddressID,
  EmployeeID,
  PIN,
  FirstName,
  LastName,
  MiddleName,
  JobTitle,
  Address,
  City,
  StateOrProvince,
  PostalCode,
  Country,
  EmailAddress,
  HomePhone,
  CommonName
) 
VALUES (
  VSAA_ADDRESS_ID.nextval,
  202,
  'password',
  'usr2',
  'tester',
  'A.',
  'Engineer',
  '1350 Charleston Road',
  'Mountain View',
  'CA',
  '94043',
  'US',
  'usr2tester@foo.bar.com',
  '(650)123-4567',
  'usr2 tester'
);
 
exit;

