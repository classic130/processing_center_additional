/* $Id: vsaaldap.cpp,v 1.6.2.4 2010/03/05 11:55:32 pchaudhari Exp $ */

/*--------------------------------------------------------------------\
| Copyright (C) VeriSign, Inc. created 1998. All rights reserved.     |
| This is an unpublished work protected as such under copyright law.  |  
| This work contains proprietary, confidential, and trade secret      |
| information of VeriSign, Inc.  Use, disclosure or reproduction      |
| without the expressed written authorization of VeriSign, Inc.       |
| is prohibited.                                                      |
\--------------------------------------------------------------------*/

/*--------------------------------------------------------------------\
 This is a data access layer to process an Automated Authentication 
 request with LDAP server. The module supports the following APIs:

 * Initialize()
   This function reads configuration file and initialize proper 
   environment for LDAP server access.

 * VerifyUser()
   The verify operation is invoked to verify (or authenticate) the 
   applicant after the applicant submits the enrollment form. 

 * RegisterUser()
   This function updates the directory with the issued certificate 
   for the request and a time stamp.

 * ErrorUser()
   This function appends the input name-value pairs to a LOG_FILE with
   a time stamp.

 * Finalize()
   This function releases all resource allocated in this module before
   the module is un-loaded.

\--------------------------------------------------------------------*/

/* Standard header files */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <stdarg.h>

/* LDAP SDK header files */

#include "ldap.h"         
#include "ldap_ssl.h"

/* Verisign AA header files */

#include "vsaaapi.h"
#include "vsaanls.h"
#include "localvsverify.h"
#include "vsaautil.h"
#include "vsutil.h"
#include "vsaabase64.h"
#include "vskpi.h"
#include "vsaaldap.h"
#include "vsaautil_crypto.h"

typedef int RETCODE;        // SUCCEED or FAIL

/* version information */

static const char*  _version_ = "@(#)$RCSfile: vsaaldap.cpp,v $ $Revision: 1.6.2.4 $";
      
/* Global variables */

#define TODECRYPT_LINE "# DECRYPT VALUE ON THE FOLLOWING LINE"
#define BUF_MAX_LEN 2048

static DIMCfg       gDIMCfg;
static VSAA_BOOL    gHasEncryptedLine = VSAA_FALSE;
  
DIMError gDIMErrorList[] = 
{
    { VSAA_LDAP_ERR,              (char *) "Unknown LDAP error"},
    { VSAA_LDAP_ERR_CFG,          (char *) "Invalid LDAP configuration file"},
    { VSAA_LDAP_ERR_INIT,         (char *) "Could not initiate an LDAP session"},
    { VSAA_LDAP_ERR_BIND,         (char *) "An error occurred when connecting to LDAP server"},
    { VSAA_LDAP_ERR_CFG_BINDDN,   (char *) "Invalid configuration entry about binding DN"},
    { VSAA_LDAP_ERR_SEARCH,               (char *) "LDAP search error"},
    { VSAA_LDAP_ERR_INVALID_DATA,          (char *) "Invalid input data"},
    { VSAA_LDAP_ERR_AUTH_ATTR_NOT_FOUND,   (char *) "Verification attribute was not found"},
    { VSAA_LDAP_ERR_AUTH_ATTR_NOT_QUALIFY, (char *) "Verification attribute was not qualified, authentication was rejected"},
    { VSAA_LDAP_ERR_HOSTNAME_NULL,         (char *) "LDAP host name was not specified or was not valid"},
    { VSAA_LDAP_ERR_PORT_MISSING,          (char *) "LDAP port was not specified or was not valid"},
    { VSAA_LDAP_ERR_AUTHENTICATE_FAILED,   (char *) "user name or password is incorrect"},
    { VSAA_LDAP_ERR_CONNECT_FAILED,        (char *) "could not connect to the LDAP server"},
    { VSAA_ERR_CFG_ENTRY_NOT_FOUND,        (char *) "No entry was found in directory"},
    { VSAA_ERR_CFG_DUPL_ENTRIES,           (char *) "More than one entry found in directory"},
    { VSAA_ERR_BASE64,                     (char *) "Base64 encoding or decoding error"},
    { VSAA_OUT_OF_MEMORY,                  (char *) "Out of memory"}
};

#define LDAP_PREPICKUP_PROCESS              ("PRE_PICKUP_PROCESS")
#define LDAP_PREREVOKE_PROCESS              ("PRE_REVOKE_PROCESS")
#define LDAP_PRERENEWAL_PROCESS             ("PRE_RENEWAL_PROCESS")

unsigned int gDIMErrorListCnt = sizeof(gDIMErrorList)/sizeof(DIMError);

/*********************************************
 * It defines the list of attributes         *
 * used determine the mapping between OnSite *
 * and the enterprise directory server       *
 *********************************************/
VSAACfgNVPair gFDFToLdapAttrDefaultMap[] =
{
  {KEY_FIRST,			        "givenName"},
  {KEY_LAST,			        "initial"},
  {"mail_lastName",				"sn"},
  {"mail_email",				"mail"},
  {VSAA_COMMON_NAME,			"cn"},
  {"corp_company",				"o"},
  {"org_unit",					"ou"},
  {"phoneNumber",				"telephoneNumber"},
  {"userID",					"uid"},
  {"password",					"userPassword"},
  {"jobTitle",					"title"},
  {"mailStop",					"mailStop"},
  {"employeeID",				"employeennumber"},
  {"embed_email",				"embed_email"},
  {"unstructured_addr",			"unstructuredAddress"},
  {"country",					"c"},
  {"city",						"l"},
  {"additional_field3",			"additional_field3"},
  {"additional_field4",			"additional_field4"},
  {"additional_field5",			"additional_field5"},
  {"additional_field6",			"additional_field6"},
  {"application",				"application"},
  {"authenticate",				"authenticate"},
  {"card_expire",				"card_expire"},
  {"cert_type",					"cert_type"},
  {"cert_DN",					"certDN"},
  {"cert_base64",   			"userCertificate;binary"},
  {"cert_serial",   			"serialNumber"},
  {"cert_jurisdiction_hash",	"cert_jurisdiction_hash"},
  {"certOrCRL",					"certOrCRL"},
  {"challenge",					"challenge"},
  {"character_filter",			"character_filter"},
  {"character_filter_param",	"character_filter_param"},
  {"character_encoding",		"character_encoding"},
  {"character_set",				"character_set"},
  {"class",						"class"},
  {"enroll_track",				"enroll_track"},
  {"form_file",					"form_file"},
  {"message",					"message"},
  {"messageStatus",				"messageStatus"},
  {VSAA_NONCE,					"nonce"},
  {"operation",					"operation"},
  {"originator",				"originator"},
  {"private_label",				"private_label"},
  {"product_config_file",		"product_config_file"},
  {"public_key",				"public_key"},
  {"public_key_format",			"public_key_format"},
  {"remote_host",				"remote_host"},
  {"session_id_string",			"session_id_string"},
  {"sid_class",					"sid_class"},
  {VSAA_XID,					"transaction_id"},
  {"user_data_1",				"user_data_1"},
  {"user_data_2",				"user_data_2"},
  {"user_data_3",				"user_data_3"},
  {"user_data_4",				"user_data_4"},
  {"user_data_5",				"user_data_5"},
  {VSAA_ENROLL_URL,				"vsenroll_url"}  
};

int gFDFToLdapAttrDefaultMapCount = sizeof(gFDFToLdapAttrDefaultMap)/sizeof(VSAACfgNVPair);


/**************************************************
 * It defines the list of attributes              *
 * used determine the mapping between Key manager *
 * and the enterprise directory server            *
 **************************************************/

char *gObjClass_INetOrgPerson_values[] = { (char *) "top", (char *) "person", (char *) "organizationalPerson", (char *) "inetOrgPerson", NULL };

VSAACfgNVPair gRecoverAttrMap_INetOrgPerson[] =
{
  {"vs_field1",                 "cn"},
  {"common_name",               "sn"},
  {"mask",                      "street"},
  {"iv",                        "uid"},
  {"pkcs12_password",           "title"},
  {"private_key",               "employeenumber"},
  {"cert",                      "description"},
  // For Novell ldap, need to map as the follow in vskmsrv.cfg
  //  {"cert",                      "postaladdress"},
  {"cert_status",               "businesscategory"},       	
  {"event_time",                "displayname"}
};

char *gObjClass_User_values[]= { (char *) "top", (char *) "person", (char *) "organizationalPerson", (char *) "user", NULL }; 

VSAACfgNVPair gRecoverAttrMap_User[] = 
{
  {"vs_field1",                 "cn"},
  {"common_name",               "displayName"},
  {"mask",                      "postOfficeBox"},
  {"iv",                        "l"},
  {"pkcs12_password",           "streetAddress"},
  {"private_key",               "wWWHomePage"},
  {"cert",                      "userCertificate"},
  {"cert_status",               "sn"},       	
  {"event_time",                "physicalDeliveryOfficeName"}
};

static VSAA_BOOL LDAP_VERIFICATION_USED = VSAA_TRUE;
static VSAA_BOOL LDAP_REGISTRATION_USED = VSAA_TRUE;
static VSAA_BOOL LDAP_RECOVERY_USED     = VSAA_TRUE;

int gRecoverAttrMapCount = sizeof(gRecoverAttrMap_INetOrgPerson)/sizeof(VSAACfgNVPair);

static char gCertSerialNumberLDAPAttr[MAX_CFG_VALUE_LENGTH] = "";
static char gCertLDAPAttr[MAX_CFG_VALUE_LENGTH] = "";
static VSAA_BOOL gIsCertSerialNumberLDAPAttrQueried = VSAA_FALSE;
static VSAA_BOOL gIsCertLDAPAttrQueried = VSAA_FALSE;
static VSAA_BOOL gDataSourceUseUTF8 = VSAA_TRUE;

static void VSAALDAP_PrintCfgAttrList( const VSAACfgAttrList *attrListPtr);
static void VSAALDAP_PrintCfgNVPairList(const VSAACfgNVPairList *attrListPtr);
static void VSAALDAP_PrintCfgNVTripleList( const VSAACfgNVTripleList *attrListPtr );
static VSAA_STATUS DoVerifyUser(const VSAA_NAME userInput[], VSAA_NAME **augmentedData);
static VSAA_STATUS DoPrePickupProcess(const VSAA_NAME userInput[], VSAA_NAME       **augmentedData);
static VSAA_STATUS DoPreRevokeProcess(const VSAA_NAME userInput[], VSAA_NAME       **augmentedData);
static VSAA_STATUS DoPreRenewProcess(const VSAA_NAME userInput[], VSAA_NAME       **augmentedData);
VSAA_STATUS DIM_KMInsertRow( LDAP           *ppLd, const char     *pszBaseDN, const VSAA_NAME subInfo[]);
VSAA_STATUS DIM_KMUpdateToIssued(LDAP           *pLdapID,  LDAPMessage	   *pEntry, const VSAA_NAME  subInfo[]);
VSAA_STATUS DIM_KMUpdateToPending(LDAP           *pLdapID, LDAPMessage	   *pEntry, const VSAA_NAME  subInfo[]);
VSAA_STATUS DIM_KMRecoverKeyAndCert(LDAP           *pLdapID,LDAPMessage	   *pEntry, const VSAA_NAME  subInfo[]);
VSAA_STATUS DIM_KMRetrievePwd(LDAP           *pLdapID, LDAPMessage	   *pEntry, const VSAA_NAME  subInfo[]);
VSAA_STATUS DIM_KMFindEntryByWebPin(LDAP           *pLdapID, LDAPMessage	   *pEntry,  const VSAA_NAME  subInfo[]);
VSAA_STATUS DIM_KMUpdateCertForPickup(LDAP           *pLdapID, LDAPMessage	   *pEntry, const VSAA_NAME  subInfo[]);
VSAA_STATUS DIM_KMDeleteFailedEntry(LDAP           *pLdapID, LDAPMessage	   *pEntry,  const VSAA_NAME  subInfo[]);
VSAA_STATUS DIM_KMChangePickupPassword(LDAP           *pLdapID, LDAPMessage	   *pEntry,  const VSAA_NAME  subInfo[]);

#define DIM_TRACE(x) VSTRACE(x);

/* Allow anonymous binding if the LDAP adminstrator allows so */

#define IS_NULL_PASSWORD_ALLOWED 1

/* Function implementation */

/* Initialize the module */
#ifdef __cplusplus
extern "C" {
#endif

VS_STATUS  (*VS_Log)(VS_LOG_TYPE level, int line, const char *filename,	const char *trans_id, const char *format, ...) = NULL;

VSAA_STATUS 
VSAA_LINK Initialize(
    const VSAA_NAME commonVSAAConfig[],
    const char*     pszServiceCfgFileName, 
    VS_STATUS  (*VSAA_Log)(VS_LOG_TYPE level, int line, const char *filename, const char *trans_id, const char *format, ...)
    )
{
    VSAA_STATUS status = VSAA_SUCCESS;    

    VS_Log = VSAA_Log;
    
    /* Determine whether UTF8 data is stored in data source from common configuration */
    if(commonVSAAConfig != NULL) {
        const char* pszDataSourceUserUTF8CfgValue = FindName(
            CFG_DB_USE_UTF8, strlen(CFG_DB_USE_UTF8), commonVSAAConfig);
        if(pszDataSourceUserUTF8CfgValue != NULL && !VSAAUTIL_StrCaseCmp(pszDataSourceUserUTF8CfgValue, "no")) 
            gDataSourceUseUTF8 = VSAA_FALSE;
    }

    /* Initialize the gDIMCfg to take default values */

    DIM_SetDefaultCfg(&gDIMCfg);
            
    /* 
     * Read configuration data into gDIMCfg. Unrecognized entries will be
     * tolerated as long as all required fields are given and no confliction
     * are found.
    */

    status = DIM_ReadConfigFile(pszServiceCfgFileName);

    DIM_TRACE("Inside LDAP module Initialize()");

    DIM_PrintCfg();

    if(status != VSAA_SUCCESS)
        return DIM_LogError(status);

    status = DIM_ValidateCfg(&gDIMCfg);
    if(status != VSAA_SUCCESS) {
        DIM_FreeCfg(&gDIMCfg);
        return DIM_LogError(status);
    }
    
    return VSAA_SUCCESS;
}
#ifdef __cplusplus
}
#endif

/* Release resources allocated for global data in this module */

VSAA_STATUS 
VSAA_LINK Finalize(void)
{
    DIM_TRACE("Inside LDAP module Finalize()");
    DIM_FreeCfg(&gDIMCfg);
    return VSAA_SUCCESS;
}

VSAA_STATUS 
VSAA_LINK VerifyUser(
    const VSAA_NAME userInput[], 
    VSAA_NAME       **augmentedData)
{
  VSAA_STATUS  status = VSAA_SUCCESS;
  const char *operation; 
  const char *t_xid;
  
  operation = FindName(VSAA_OPERATION, strlen(VSAA_OPERATION), userInput);
  t_xid = FindName (VSAA_XID, strlen (VSAA_XID), userInput);
  
  do {
    if ( operation == NULL || strlen(operation) == 0 ) {
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, t_xid, (char *)"Operation is missing in the name value list.");
      status =  VSAA_INTERNAL_ERROR;
      break;
    }
    
    if (!strcmp(operation, VSAA_AA_PICKUP) || !strcmp(operation, VSKPI_PICKUP) ) {
      // doing pre-pickup process
      if ( gDIMCfg.nPrePickupProcess ) {
        status = DoPrePickupProcess(userInput, augmentedData);
      }
    } else if (!strcmp(operation, VSAA_AA_REVOKE) ) {
      // doing pre-revoke process
      if ( gDIMCfg.nPreRevokeProcess ) {
        status = DoPreRevokeProcess(userInput, augmentedData);
      }
    } else if (!strcmp(operation, VSAA_AA_RENEWAL) ) {
      // doing pre-renew process
      if ( gDIMCfg.nPreRenewalProcess ) {
        status = DoPreRenewProcess(userInput, augmentedData);
      }
    } else {
      // always does the verify user for any operation other than pickup, revoke, renewal
      status = DoVerifyUser(userInput, augmentedData);
    }
  } while (0);
  
  return status;
}

/* 
    RegisterUser is used to handle four cases: new enrollment,
    renewal, revoke and pickup. The value of "original_operation"
    tells what action is. 
    
    If RegisterUser is being called during enrollment and 
    we will build the verAttrList array of VER attributes from   
    configuration file.                                          

    Otherwise, we must create our own verAttrList array from 
    data in the available user input which will be cert_DN
    for pickup and renewal and certSerial for revoke.

    It is a tough decision to determine the entry that should
    be updated in the later three cases. This implementation
    uses email address to identifier an entry in pickup
    and renewal cases, and cert_serial in revoke case. If an
    entry cannot be identified, an error will be reported
    to alert the user. In revoke case, certificate data will
    be deleted upon successful revocation. Configuration file 
    setup should follow this policy. Otherwise, this function 
    should be modified according to individual customer case.    
    Alternatively, code modification can also happen in vsaasrv.cpp
    by branching separate functions to handle these three
    cases according to value of "original_operation" and not
    passing the call to this function.
*/
	
VSAA_STATUS 
VSAA_LINK RegisterUser(const VSAA_NAME userInput[])
{
    VSAA_STATUS	status = VSAA_SUCCESS;
    
    LDAP        *pLdapID=NULL;
    LDAPMessage	*pResult=NULL, *pEntry=NULL;

    char        *pszFilter = NULL;
    char        *pszUserDN = NULL;
    char        *pszUserPWD = NULL;
    char        *pszDN = NULL;
    int         revoke_count = 0;
/* revoke_count variable is added to count the number of times
function DIM_BuildRevokeVerSetAttributes() is called and can be used 
as flag to decide whether BITSTRING or HEX STRING format of serial number 
to be set as attribute for searching in LDAP during revoke
*/

    const char  *origOpStr = NULL;
    const char  *messageStatus = NULL;
    VSAA_BOOL   isRenewalOperation = VSAA_FALSE;
    VSAA_BOOL   isPickupOperation = VSAA_FALSE;
    VSAA_BOOL   isRevokeOperation = VSAA_FALSE;
    VSAA_BOOL   isSearchAttrConstructed = VSAA_FALSE;

    VSAACfgAttrList*      verAttrListPtr = NULL;
    VSAACfgNVPairList*    setAttrListPtr = NULL;
 
    const char *t_xid;

    DIM_TRACE("RegisterUser()");

    /* Find out whether external LDAP server will be used */

    VSAA_BOOL      useExternalLDAPServer = DIM_IsExternalLDAPServerRequested(userInput);
    DIMCfgLDAPHost *pLdapHostCfg = (useExternalLDAPServer == VSAA_FALSE)?&gDIMCfg.regLDAPCfg:&gDIMCfg.regLDAPExternalCfg;
    char*          szObjClass = pLdapHostCfg->szObjClass;
    
    /* 
       Find out what the original operation is. It might be from 
       enrollment, pickup operation, revoke or renewal. Proper 
       identifier of target entry and update action should be constructed.
    */

    t_xid = FindName (VSAA_XID, strlen (VSAA_XID), userInput);
    origOpStr = VSAAUTIL_FindUserInputValue(VSAA_ORIG_OP, strlen(VSAA_ORIG_OP), userInput);
    if(!origOpStr) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "Could not find original_operation from user input.");
        return VSAA_INTERNAL_ERROR;
    }

    if(!strcmp(origOpStr, VSAA_AA_REVOKE)) {
        isRevokeOperation = VSAA_TRUE;
        isSearchAttrConstructed = VSAA_TRUE;
        szObjClass = NULL;
        revoke_count++;
        status = DIM_BuildRevokeVerSetAttributes(&verAttrListPtr, &setAttrListPtr, userInput,revoke_count);
        if(status != VSAA_SUCCESS) {
            return DIM_LogError(status);
        }

        if(verAttrListPtr == NULL) {
          // do no-op while certificate has been revoked in Verisign back-end 
          VS_Log(VS_LOG_ALERT, __LINE__, __FILE__, t_xid,  (char *) "Certificate status couldn't be recorded during revoke process because cert_serial was not in LDAP_ATTR_UPD.");
          return VSAA_NO_SERIAL;
        }
     
    } else if(!strcmp(origOpStr, VSAA_AA_SUBMIT)) {
        verAttrListPtr = gDIMCfg.verAttrListPtr;
        setAttrListPtr = gDIMCfg.setAttrListPtr;
        isSearchAttrConstructed = VSAA_FALSE;
    } else if(!strcmp(origOpStr, VSAA_AA_PICKUP) || !strcmp(origOpStr, "PickupPKCS12")) {
        isPickupOperation = VSAA_TRUE;
        isSearchAttrConstructed = VSAA_TRUE;
        szObjClass = NULL;
        status = DIM_BuildPickupVerSetAttributes(&verAttrListPtr, &setAttrListPtr, userInput);
        if(status != VSAA_SUCCESS) {
            return DIM_LogError(status);
        }
    } else if(!strcmp(origOpStr, VSAA_AA_RENEWAL)) {        
        isRenewalOperation = VSAA_TRUE;
        isSearchAttrConstructed = VSAA_TRUE;
        szObjClass = NULL;
        status = DIM_BuildRenewalVerSetAttributes(&verAttrListPtr, &setAttrListPtr, userInput);
        if(status != VSAA_SUCCESS) {
            return DIM_LogError(status);
        }        
    } else {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "Un-supported original_operation from user input.");
        return VSAA_INTERNAL_ERROR;
    }
    
    /* preparing the search filter */

    status = DIM_BuildLDAPSearchFilter(
                      &pszFilter,
                      userInput, 
                      verAttrListPtr, 
                      setAttrListPtr, 
                      szObjClass);
    

    if(status != VSAA_SUCCESS) {
        return DIM_LogError(status);
    }

    /* preparing the bind DN and PWD */

    if (!*pLdapHostCfg->szBindDN) {

        pszUserDN = pszUserPWD = NULL;

    } else {

        if( 
            (status = DIM_BuildBindDNPassword(
                          &pszUserDN,
                          &pszUserPWD,
                          userInput, 
                          pLdapHostCfg,
                          pszFilter) 
            ) != VSAA_SUCCESS 
          ) 
        {
            if(pszFilter) VSAAUTIL_Free(pszFilter);
            if(pszUserDN) VSAAUTIL_Free(pszUserDN);
            if(pszUserPWD) VSAAUTIL_Free(pszUserPWD);

            return DIM_LogError(status);
        }

    }

    /* 
        Use the binding information to connect to registration LDAP server 
        Query LDAP server for the entry to be registrated;
    */

    status = DIM_QueryLDAPServer(
        &pLdapID,
        &pResult,
        &pEntry,
        pLdapHostCfg->szHostName,
        pLdapHostCfg->nSSLEnabled?pLdapHostCfg->nSSLPort:pLdapHostCfg->nPort, 
        pLdapHostCfg->nSSLEnabled,
        pLdapHostCfg->szCertDB,
        pLdapHostCfg->szBaseDN,
        pszUserDN, 
        pszUserPWD,
        pszFilter,
        pLdapHostCfg->nProtocolVersion);
    
            
      if((status != VSAA_SUCCESS ) && (strcmp(origOpStr, VSAA_AA_REVOKE) == 0) && (revoke_count == 1))
      {
       revoke_count++;
       status = DIM_BuildRevokeVerSetAttributes(&verAttrListPtr, &setAttrListPtr, userInput,revoke_count);
       if(status != VSAA_SUCCESS) {
        return DIM_LogError(status);
        }
        if(verAttrListPtr == NULL) {
          // do no-op while certificate has been revoked in Verisign back-end
          VS_Log(VS_LOG_ALERT, __LINE__, __FILE__, t_xid,  (char *) "Certificate status couldn't be recorded during revoke process because cert_serial was not in LDAP_ATTR_UPD.");
          return VSAA_NO_SERIAL;
        }

    /* preparing the search filter */

    status = DIM_BuildLDAPSearchFilter(
                      &pszFilter,
                      userInput,
                      verAttrListPtr,
                      setAttrListPtr,
                      szObjClass);


    if(status != VSAA_SUCCESS) {
        return DIM_LogError(status);
    }

/* Query LDAP server for the entry to be registrated */

    status = DIM_QueryLDAPServer(
        &pLdapID,
        &pResult,
        &pEntry,
        pLdapHostCfg->szHostName,
        pLdapHostCfg->nSSLEnabled?pLdapHostCfg->nSSLPort:pLdapHostCfg->nPort,
        pLdapHostCfg->nSSLEnabled,
        pLdapHostCfg->szCertDB,
        pLdapHostCfg->szBaseDN,
        pszUserDN,
        pszUserPWD,
        pszFilter,
        pLdapHostCfg->nProtocolVersion);

    }

    if(isSearchAttrConstructed == VSAA_TRUE) {
        VSAAUTIL_FreeCfgAttrList(verAttrListPtr);
        VSAAUTIL_FreeCfgNVPairList(setAttrListPtr);
    }
    if(pszFilter) VSAAUTIL_Free(pszFilter);
    if(pszUserDN) VSAAUTIL_Free(pszUserDN);
    if(pszUserPWD) VSAAUTIL_Free(pszUserPWD);
     
    if(status != VSAA_SUCCESS ) {
       
         
      // Dealing with revoke successful, update entry fail case.
      if ( pLdapID )
        ldap_unbind(pLdapID);
      pLdapID = 0;

      if ( strcmp(origOpStr, VSAA_AA_REVOKE) == 0 ){
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "Certificate revoke operation is successful, but entry can not be found in the LDAP directory.");
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "Possible Reasons:");
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "\t1. Certificate has been renewed.");
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "\t2. Certificate was not registered in this LDAP directory.");
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,  (char *) "\t3. Tried to revoke signing certificate in the Key Manager dual key configuration.");
        return VSAA_SUCCESS;
      } else {
        return DIM_LogError(status);
      }
    }

    /*
        To do:
           Update the entry according to update configuration;
           Add or update new entry/certificates of the given input.
    */

    /* build dn to modify */

    if( (pszDN = ldap_get_dn(pLdapID, pEntry )) == NULL ) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "Could not find DN from LDAP entry retrieve.");
        ldap_msgfree(pResult);
        ldap_unbind(pLdapID);                
        return DIM_LogError(VSAA_ERR_CFG_ENTRY_NOT_FOUND);
    }
    
    ldap_msgfree(pResult);
    
    /* Update the entry according to update configuration */

    if(isRevokeOperation == VSAA_FALSE) {

        /* update certificate data and others */

        status = DIM_UpdateLDAPServerEntry(
            pLdapID,
            pszDN,
            gDIMCfg.updAttrListPtr,
            userInput);

        /* set certificate status to be valid if the attribute is given */

        if(status == VSAA_SUCCESS && gDIMCfg.certStatusAttrName[0] != 0) {
            status = DIM_UpdateOneLDAPServerEntry(
                pLdapID,
                pszDN,
                gDIMCfg.certStatusAttrName,
                gDIMCfg.certStatusValid);            
        }
    } else {

        /* set certificate status to be revoked if the attribute is given */

        if(gDIMCfg.certStatusAttrName[0] != 0) {
            status = DIM_UpdateOneLDAPServerEntry(
                pLdapID,
                pszDN,
                gDIMCfg.certStatusAttrName,
                gDIMCfg.certStatusRevoked);  
            
        } else {

            /* delete revoked certificate from LDAP server */

            if(gIsCertLDAPAttrQueried == VSAA_FALSE) {
                DIM_FindCertLDAPAttr();
            }

            if(gCertLDAPAttr[0]) {
                status = DIM_DeleteOneLDAPServerAttr(
                    pLdapID,
                    pszDN,
                    gCertLDAPAttr);     
            }
        }        
    }

    if(status != VSAA_SUCCESS) {	
        ldap_memfree(pszDN);
        ldap_unbind(pLdapID);        
        return status;
    }

    if(isRenewalOperation == VSAA_FALSE && isRevokeOperation == VSAA_FALSE) {
        status = DIM_RegLDAPServerEntry(
            pLdapID,
            pszDN,
            gDIMCfg.regAttrListPtr,
            userInput);
    }

    ldap_memfree(pszDN);
    ldap_unbind(pLdapID);        

    return status;
}

/*******************************************************************/
/*
 * Record this user in the log file
 */
/*******************************************************************/

VSAA_STATUS 
VSAA_LINK ErrorUser(const VSAA_NAME userInput[])
{
    int i;
    const char *t_xid;

    DIM_TRACE("ErrorUser()");
    t_xid = FindName (VSAA_XID, strlen (VSAA_XID), userInput);

    VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, t_xid, (char *) "An error occurred with user's input. Decoded message from Backend: ");
    for (i=0; userInput[i].pszName != NULL; i++)
    {
      // Not dumping the original user data
      if ( strcmp(userInput[i].pszName, VSKPI_ORIGINAL_OP) == 0 ) break;
      VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, t_xid,  (char *)"    %s=[%s]", userInput[i].pszName, userInput[i].pszValue);        
    }            

    return VSAA_SUCCESS ;
}


VSAA_STATUS 
KMOperation(const VSAA_NAME subInfo[], const char* operation)
{
    VSAA_STATUS  status = VSAA_SUCCESS;
    RETCODE      rc = 0;
    char         *pszFilter = NULL;
    char         *pszUserDN = NULL;
    char         *pszUserPWD = NULL;
    LDAP         *pLdapID=NULL;
    LDAPMessage  *pResult=NULL, *pEntry=NULL;
    char         *searchAttr = NULL;

    DIM_TRACE("KMOperation()");

    do {
        DIMCfgLDAPHost *pLdapHostCfg = &gDIMCfg.recoverLDAPCfg;
        char*          szObjClass = pLdapHostCfg->szObjClass;

        /* preparing the search filter */

        if ( (strcmp(operation, VSKPI_INSERTNEWROW) == 0) || 
             (strcmp(operation, VSKPI_UPDATETOISSUED) == 0)  ||
             (strcmp(operation, VSKPI_UPDATETOPENDING) == 0) ||
             (strcmp(operation, VSKPI_DELETEFAILEDENTRY) == 0) )
        {
            searchAttr = (char *) VSAA_FINGER_PRINT;
        } else {
            searchAttr = (char *) VSKPI_WEBPIN;
        }

        if ( 
            (status = DIM_RecoverBuildLDAPSearchFilter(
                          &pszFilter,
                          subInfo,
                          searchAttr,
                          pLdapHostCfg->szObjClass)
            ) != VSAA_SUCCESS
          ) 
        {
            return DIM_LogError(status);
        }
        
        /* preparing the bind DN and PWD */

        if (!*pLdapHostCfg->szBindDN) {
            pszUserDN = pszUserPWD = NULL;
        } else {
            if( 
                (status = DIM_BuildBindDNPassword(
                              &pszUserDN,
                              &pszUserPWD,
                              subInfo, 
                              pLdapHostCfg,
                              pszFilter) 
                ) != VSAA_SUCCESS 
              ) 
            {
                if(pszFilter) VSAAUTIL_Free(pszFilter);
                if(pszUserDN) VSAAUTIL_Free(pszUserDN);
                if(pszUserPWD) VSAAUTIL_Free(pszUserPWD);

                return DIM_LogError(status);
            }

        }

        /* 
            Use the binding information to connect to authentication LDAP server 
            Query LDAP server for the entry to be verified. The successful query
            will return valid pResult and pEntry for given search filter.
        */

        status = DIM_QueryLDAPServer(
            &pLdapID,
            &pResult,
            &pEntry,
            pLdapHostCfg->szHostName,
            pLdapHostCfg->nSSLEnabled?pLdapHostCfg->nSSLPort:pLdapHostCfg->nPort, 
            pLdapHostCfg->nSSLEnabled,
            pLdapHostCfg->szCertDB,
            pLdapHostCfg->szBaseDN,
            pszUserDN, 
            pszUserPWD,
            pszFilter,
            pLdapHostCfg->nProtocolVersion);

        if (status == VSAA_ERR_CFG_DUPL_ENTRIES) {
            // wrong! duplicate webpin
            VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "multiple entries found with the same webpin in the ldap server\n");
            status = VSAA_INTERNAL_ERROR;
            break;

        } else if (status == VSAA_ERR_CFG_ENTRY_NOT_FOUND && 
                   strcmp(operation, VSKPI_FINDENTRYBYWEBPIN) == 0) {
            for (int i = 0; subInfo[i].pszName != NULL; i++ ){
                if ( strcmp(subInfo[i].pszName, VSKPI_FOUND_ENTRY) == 0 ) {
                  status = VSAA_SUCCESS;
                  strcpy(subInfo[i].pszValue, "notFound");
                  break;
                } 
            }

            break;
            
        } else if (status == VSAA_ERR_CFG_ENTRY_NOT_FOUND && strcmp(operation, VSKPI_INSERTNEWROW)) {
            VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "no entry is found in the ldap server\n");
            status = VSAA_INTERNAL_ERROR;
            break;  
                        
        }else if (status == VSAA_LDAP_ERR_BIND) {
            VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "ldap server bind failed\n");
            status = VSAA_INTERNAL_ERROR;
            break;  
                        
        }else if ( strcmp(operation, VSKPI_INSERTNEWROW) == 0 ) {

            // insert a new row operation, status is submitted
            if (status == VSAA_ERR_CFG_ENTRY_NOT_FOUND) {
                status = DIM_KMInsertRow(pLdapID, pLdapHostCfg->szBaseDN, subInfo);  
            } else {
                VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "an entry for this fingerprint already existed in the ldap server\n");
                status = VSAA_HARD_ERROR;
                break;
            }
        } else if ( strcmp(operation, VSKPI_UPDATETOISSUED) == 0 ) {
            // after receiving the cert, update the status to issued
            status = DIM_KMUpdateToIssued(pLdapID, pEntry, subInfo);
        } else if ( strcmp(operation, VSKPI_UPDATETOPENDING) == 0 ) {
            // after receiving the cert, update the status to issued
            status = DIM_KMUpdateToPending(pLdapID, pEntry, subInfo);
        } else if ( strcmp(operation, VSKPI_RECOVERKEYANDCERT) == 0 ) {
            // doing the key recovery step
            status = DIM_KMRecoverKeyAndCert(pLdapID, pEntry, subInfo);
        } else if ( strcmp(operation, VSKPI_RETRIEVEPASSWORD) == 0 ) {
            // doing password retrieval
            status = DIM_KMRetrievePwd(pLdapID, pEntry, subInfo);
        } else if ( strcmp(operation, VSKPI_UPDATECERTFORPICKUP) == 0 ) {
            // updating the cert and get the common name
            status = DIM_KMUpdateCertForPickup(pLdapID, pEntry, subInfo);
        } else if ( strcmp(operation, VSKPI_FINDENTRYBYWEBPIN) == 0 ) {
            // looking for entries by webpin
            status = DIM_KMFindEntryByWebPin(pLdapID, pEntry, subInfo);
        } else if ( strcmp(operation, VSKPI_DELETEFAILEDENTRY) == 0 ) {
            status = DIM_KMDeleteFailedEntry(pLdapID, pEntry, subInfo);
	    } else if ( strcmp(operation, VSKPI_CHANGE_PICKUP_PASSWORD) == 0 ) {
	        // looking for entries by webpin
	        status = DIM_KMChangePickupPassword(pLdapID, pEntry, subInfo);
	    }
    } while (0);

    if ( pResult )
      ldap_msgfree(pResult);
    pResult = 0;
    if ( pLdapID )
      ldap_unbind(pLdapID);
    pLdapID = 0;

    return status;
}


VSAA_STATUS 
DIM_KMInsertRow( 
    LDAP           *ppLd,
    const char     *pszBaseDN,
	const VSAA_NAME subInfo[])
{
    RETCODE     rc = 0;
    char *eventTime = NULL;
    char *fingerPrint = NULL, *subscribername = NULL, *certStatus = NULL;
    char *mask = NULL, *iv = NULL, *ePriKey = NULL;
    time_t ltime;
	  LDAPMod *attrs[10];
    VSAA_STATUS status;
    char *webpinValues[2], *snameValues[2], *statusValues[2], *maskValues[2], *ivValues[2];
    char *epkeyValues[2], *eventTimeValues[2], *objectClass_values[2];
    LDAPMod webpinAttr, snameAttr, statusAttr, maskAttr, ivAttr, epkeyAttr, eventTimeAttr;
    // for ads support
    char *adsRequiredValue[2];
    LDAPMod adsRequiredAttr;


    DIM_TRACE("DIM_KMInsertRow()");

    do { 
        fingerPrint = (char*) VSAAUTIL_FindUserInputValue(VSAA_FINGER_PRINT, strlen(VSAA_FINGER_PRINT), subInfo);
        if ( fingerPrint == NULL ){
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "fingerprint is missing from inputList");
          status = VSAA_KM_PARAMETER_MISSING;
          break;
        }

        // KMS main program send in subscribername in UTF-8 format
        subscribername = (char*)VSAAUTIL_FindUserInputValue(VSKPI_COMMONNAME, strlen(VSKPI_COMMONNAME), subInfo);
        if ( subscribername == NULL ) {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "subscribername is missing from inputList");
          status = VSAA_KM_PARAMETER_MISSING;
          break;
        }

        certStatus = (char*)VSAAUTIL_FindUserInputValue(VSKPI_CERT_STATUS, strlen(VSKPI_CERT_STATUS), subInfo);
        if ( certStatus == NULL ) {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "certStatus is missing from inputList");
          status = VSAA_KM_PARAMETER_MISSING;
          break;
        }

        mask = (char*)VSAAUTIL_FindUserInputValue(VSKPI_MASK, strlen(VSKPI_MASK), subInfo);
        if ( mask == NULL ) {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "mask is missing from inputList");
          status = VSAA_KM_PARAMETER_MISSING;
          break;
        }

        iv = (char*)VSAAUTIL_FindUserInputValue(VSKPI_IV, strlen(VSKPI_IV), subInfo);
        if ( iv == NULL ) {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "iv is missing from inputList");
          status = VSAA_KM_PARAMETER_MISSING;
          break;
        }

        ePriKey = (char*)VSAAUTIL_FindUserInputValue(VSKPI_EPRIKEY, strlen(VSKPI_EPRIKEY), subInfo);
        if ( ePriKey == NULL ) {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "ePriKey is missing from inputList");
          status = VSAA_KM_PARAMETER_MISSING;
          break;
        }

        time( &ltime );
        eventTime = ctime(&ltime);
        eventTime[strlen(eventTime) - 1] = '\0';

        webpinValues[0] = fingerPrint;
        webpinValues[1] = NULL;
        webpinAttr.mod_op = LDAP_MOD_ADD;
        webpinAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_WEBPIN); 
        webpinAttr.mod_values = webpinValues;

        snameValues[0] = subscribername;
        snameValues[1] = NULL;
        snameAttr.mod_op = LDAP_MOD_ADD;
        snameAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_COMMONNAME);
        snameAttr.mod_values = snameValues;

        statusValues[0] = certStatus;
        statusValues[1] = NULL;
        statusAttr.mod_op = LDAP_MOD_ADD;
        statusAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_CERT_STATUS); 
        statusAttr.mod_values = statusValues;

        maskValues[0] = mask;
        maskValues[1] = NULL;
        maskAttr.mod_op = LDAP_MOD_ADD;
        maskAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_MASK); 
        maskAttr.mod_values = maskValues;

        ivValues[0] = iv;
        ivValues[1] = NULL;
        ivAttr.mod_op = LDAP_MOD_ADD;
        ivAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_IV); 
        ivAttr.mod_values = ivValues;

        epkeyValues[0] = ePriKey;
        epkeyValues[1] = NULL;
        epkeyAttr.mod_op = LDAP_MOD_ADD;
        epkeyAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_PRIKEY); 
        epkeyAttr.mod_values = epkeyValues;

        eventTimeValues[0] = eventTime;
        eventTimeValues[1] = NULL;
        eventTimeAttr.mod_op = LDAP_MOD_ADD;
        eventTimeAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_EVENTTIME); 
        eventTimeAttr.mod_values = eventTimeValues;

        LDAPMod objectClassAttribute;

        objectClassAttribute.mod_op = LDAP_MOD_ADD;
        objectClassAttribute.mod_type = (char *) "objectClass";

        if (VSAAUTIL_StrnCaseCmp(gDIMCfg.recoverLDAPCfg.szObjClass, "inetOrgPerson", strlen("inetOrgPerson")) == 0) {
            objectClassAttribute.mod_values = gObjClass_INetOrgPerson_values;
        } else if (VSAAUTIL_StrnCaseCmp(gDIMCfg.recoverLDAPCfg.szObjClass, "user", strlen("user")) == 0) {
            objectClassAttribute.mod_values = gObjClass_User_values;
        } else {
            objectClass_values[0] = gDIMCfg.recoverLDAPCfg.szObjClass;            
            objectClass_values[1] = NULL;
            objectClassAttribute.mod_values = objectClass_values;      
        }

        if (VSAAUTIL_StrnCaseCmp(gDIMCfg.recoverLDAPCfg.szObjClass, "user", strlen("user")) != 0) {
          // for non-ads support
          attrs[0] = &webpinAttr;
          attrs[1] = &snameAttr;
          attrs[2] = &statusAttr;
          attrs[3] = &maskAttr;
          attrs[4] = &ivAttr;
          attrs[5] = &eventTimeAttr;
          attrs[6] = &epkeyAttr;
          attrs[7] = &objectClassAttribute;
          attrs[8] = NULL;
        } else {
          adsRequiredValue[0] = fingerPrint;
          adsRequiredValue[1] = NULL;
          adsRequiredAttr.mod_op = LDAP_MOD_ADD;
          adsRequiredAttr.mod_type = (char *) "sAMAccountName"; 
          adsRequiredAttr.mod_values = adsRequiredValue;


          attrs[0] = &webpinAttr;
          attrs[1] = &snameAttr;
          attrs[2] = &statusAttr;
          attrs[3] = &maskAttr;
          attrs[4] = &ivAttr;
          attrs[5] = &eventTimeAttr;
          attrs[6] = &epkeyAttr;
          attrs[7] = &adsRequiredAttr;
          attrs[8] = &objectClassAttribute;
        }
        attrs[9] = NULL;

        char dn[200];
        sprintf(dn, "%s=%s,%s", DIM_RecoverGetLdapAttrName(VSKPI_WEBPIN), fingerPrint, pszBaseDN); 
        VS_Log (VS_LOG_DEBUG, __LINE__, __FILE__, NULL,  (char *) "About to insert new entry to DN: %s", dn);

        rc = ldap_add_s(ppLd, dn, attrs);
        if ( rc == LDAP_SUCCESS)
            status = VSAA_SUCCESS;
        else {
            VS_Log (VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "Insert new entry to ldap failed: %d, %s", rc, ldap_err2string(rc));
            status = VSAA_HARD_ERROR;
        }
    } while (0);

    return status;
}

VSAA_STATUS 
DIM_KMUpdateToIssued(
    LDAP           *pLdapID,
    LDAPMessage	   *pEntry, 
    const VSAA_NAME  subInfo[])
{
    RETCODE     rc = 0;
    VSAA_STATUS status = VSAA_SUCCESS;
    char        *eventTime = NULL;
    char        *certStatus = NULL, *webpin = NULL, *cert = NULL;
    time_t      ltime;
    LDAPMessage	*pResult=NULL;
    char        *pszDN = NULL;
    LDAPMod     *mods[10];
    char        *statusValues[2], *eventTimeValues[2], *snameValues[2], *b64certValues[2];
    LDAPMod     statusAttr, certAttr, eventTimeAttr, snameAttr;
    char        *subscribername = NULL;

    DIM_TRACE("DIM_KMUpdateToIssued()");
     
    do {
        // retrieve parameters from the input list

        certStatus = (char*)VSAAUTIL_FindUserInputValue(VSKPI_CERT_STATUS, strlen(VSKPI_CERT_STATUS), subInfo);
        if ( certStatus == NULL ){
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "certstatus is missing from inputList");
          status = VSAA_KM_PARAMETER_MISSING;
          break;
        }

        webpin = (char*)VSAAUTIL_FindUserInputValue(VSKPI_WEBPIN, strlen(VSKPI_WEBPIN), subInfo);
        if ( webpin == NULL ) {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "webpin is missing from inputList");
          status = VSAA_KM_WEBPIN_MISSING;
          break;
        }

        cert = (char*)VSAAUTIL_FindUserInputValue(VSKPI_CERT_OR_CRL, strlen(VSKPI_CERT_OR_CRL), subInfo);

        if ( cert == NULL ) {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "cert is missing from inputList");
          status = VSAA_KM_PARAMETER_MISSING;
          break;
        }

        // KMS main program send in subscribername in UTF-8 format
        subscribername = (char*)VSAAUTIL_FindUserInputValue(VSKPI_COMMONNAME, strlen(VSKPI_COMMONNAME), subInfo);

        time( &ltime );
        eventTime = ctime(&ltime);
        eventTime[strlen(eventTime) - 1] = '\0';

        /* build dn to modify */

        if( (pszDN = ldap_get_dn(pLdapID, pEntry )) == NULL ) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Could not find DN from LDAP entry retrieve.");
            ldap_msgfree(pResult);
            ldap_unbind(pLdapID);                
            return DIM_LogError(VSAA_ERR_CFG_ENTRY_NOT_FOUND);
        }

        ldap_msgfree(pResult);

        statusValues[0] = certStatus;
        statusValues[1] = NULL;
        statusAttr.mod_op = LDAP_MOD_REPLACE | LDAP_MOD_ADD;
        statusAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_CERT_STATUS);
        statusAttr.mod_values = statusValues;

        eventTimeValues[0] = eventTime;
        eventTimeValues[1] = NULL;
        eventTimeAttr.mod_op = LDAP_MOD_REPLACE | LDAP_MOD_ADD;
        eventTimeAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_EVENTTIME); 
        eventTimeAttr.mod_values = eventTimeValues;
                           
        b64certValues[0] = cert;
        b64certValues[1] = NULL;
        certAttr.mod_op = LDAP_MOD_REPLACE | LDAP_MOD_ADD; 
        certAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_CERT); 
        certAttr.mod_values = b64certValues;

        mods[0] = &statusAttr;
        mods[1] = &eventTimeAttr;   
        mods[2] = &certAttr;

        if (subscribername) {
            snameValues[0] = subscribername;
            snameValues[1] = NULL;
            snameAttr.mod_op = LDAP_MOD_REPLACE | LDAP_MOD_ADD;
            snameAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_COMMONNAME); 
            snameAttr.mod_values = snameValues;
        
            mods[3] = &snameAttr;
            mods[4] = NULL;
        } else {
            mods[3] = NULL;
        }

        VS_Log (VS_LOG_INFO, __LINE__, __FILE__, NULL,  (char *) "About to update DN: %s", pszDN);


       /* make the change */
        rc = ldap_modify_s(pLdapID, pszDN, mods);

        if (rc != LDAP_SUCCESS) {
            VS_Log (VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "update ldap entry failed: %d", rc);
            status = VSAA_HARD_ERROR;
            break;
        }

        /* Rename the entry */
        char rdn[200];
        sprintf(rdn, "%s=%s", DIM_RecoverGetLdapAttrName(VSKPI_WEBPIN), webpin); 
        rc = ldap_modrdn2_s(pLdapID, pszDN, rdn, 1);

        if (rc != LDAP_SUCCESS) {
            VS_Log (VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "update webpin field failed: %d", rc);
            status = VSAA_HARD_ERROR;
            break;
        }

    } while (0);

  return status;

}

VSAA_STATUS 
DIM_KMUpdateToPending(
    LDAP           *pLdapID,
    LDAPMessage	   *pEntry, 
    const VSAA_NAME  subInfo[])
{
    RETCODE     rc = 0;
    VSAA_STATUS status = VSAA_SUCCESS;
    char        *eventTime = NULL;
    char        *certStatus = NULL, *webpin = NULL;
    char        *p12password = NULL, *cert = NULL;
    time_t      ltime;
    LDAPMessage	*pResult=NULL;
    char        *pszDN = NULL;
    LDAPMod     *mods[10];
    char        *statusValues[2], *eventTimeValues[2], *p12passwordValues[2];
    LDAPMod     statusAttr, eventTimeAttr, p12passwordAttr;

    DIM_TRACE("DIM_KMUpdateToPending()");
    
    do {
        // retrieve parameters from the input list

        certStatus = (char*) VSAAUTIL_FindUserInputValue(VSKPI_CERT_STATUS, strlen(VSKPI_CERT_STATUS), subInfo);
        if ( certStatus == NULL ){
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "certstatus is missing from inputList");
          status = VSAA_KM_PARAMETER_MISSING;
          break;
        }

        webpin = (char*) VSAAUTIL_FindUserInputValue(VSKPI_WEBPIN, strlen(VSKPI_WEBPIN), subInfo);
        if ( webpin == NULL ) {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "webpin is missing from inputList");
          status = VSAA_KM_WEBPIN_MISSING;
          break;
        }

        p12password = (char*) VSAAUTIL_FindUserInputValue(VSKPI_P12PASSWORD, strlen(VSKPI_P12PASSWORD), subInfo);
        if ( p12password == NULL ) {
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "p12 password is missing from inputList");
          status = VSAA_KM_PARAMETER_MISSING;
          break;
        }

        time( &ltime );        
        eventTime = ctime(&ltime);
        eventTime[strlen(eventTime) - 1] = '\0';
 
        /* build dn to modify */

        if( (pszDN = ldap_get_dn(pLdapID, pEntry )) == NULL ) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Could not find DN from LDAP entry retrieve.");
            ldap_msgfree(pResult);
            ldap_unbind(pLdapID);                
            return DIM_LogError(VSAA_ERR_CFG_ENTRY_NOT_FOUND);
        }

        ldap_msgfree(pResult);

        statusValues[0] = certStatus;
        statusValues[1] = NULL;
        statusAttr.mod_op = LDAP_MOD_REPLACE | LDAP_MOD_ADD;
        statusAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_CERT_STATUS);
        statusAttr.mod_values = statusValues;

        eventTimeValues[0] = eventTime;
        eventTimeValues[1] = NULL;
        eventTimeAttr.mod_op = LDAP_MOD_REPLACE | LDAP_MOD_ADD;
        eventTimeAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_EVENTTIME);
        eventTimeAttr.mod_values = eventTimeValues;

        p12passwordValues[0] = p12password;
        p12passwordValues[1] = NULL;
        p12passwordAttr.mod_op = LDAP_MOD_REPLACE | LDAP_MOD_ADD;
        p12passwordAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_P12PASSWORD);
        p12passwordAttr.mod_values = p12passwordValues;

        mods[0] = &statusAttr;
        mods[1] = &eventTimeAttr;   
        mods[2] = &p12passwordAttr;
        mods[3] = NULL;
 
       VS_Log (VS_LOG_INFO, __LINE__, __FILE__, NULL,  (char *) "About to update DN: %s", pszDN);
       
       /* make the change */
        rc = ldap_modify_s(pLdapID, pszDN, mods);

        if (rc != LDAP_SUCCESS) {
            VS_Log (VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "update ldap entry failed: %d", rc);
            status = VSAA_HARD_ERROR;
            break;
        }

        /* Rename the entry */
        char rdn[200];
        sprintf(rdn, "%s=%s", DIM_RecoverGetLdapAttrName(VSKPI_WEBPIN), webpin); 
        rc = ldap_modrdn2_s(pLdapID, pszDN, rdn, 1);

        if (rc != LDAP_SUCCESS) {
            VS_Log (VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "update webpin field failed: %d", rc);
            status = VSAA_HARD_ERROR;
            break;
        }

  } while (0);

  return status;

}

VSAA_STATUS 
DIM_KMRetrievePwd(
    LDAP           *pLdapID,
    LDAPMessage	   *pEntry, 
    const VSAA_NAME  subInfo[])
{
    RETCODE      rc = 0;
    VSAA_STATUS  status = VSAA_SUCCESS;
    char         *webpin = NULL;
    char         p12password[kPKCS12_PASSWORD_MAX_LENGTH];
    int          i = 0;
    BerElement   *ber=NULL;
    char         **ppszVals = NULL, *pszAttribute = NULL; 

    DIM_TRACE("DIM_KMRetrievePwd()");

    do {

        for (  pszAttribute = ldap_first_attribute(pLdapID, pEntry, &ber);
              pszAttribute; 
              pszAttribute = ldap_next_attribute(pLdapID, pEntry, ber) ) 
        {
            if (VSAAUTIL_StrCaseCmp(pszAttribute, DIM_RecoverGetLdapAttrName(VSKPI_P12PASSWORD)) == 0) {
                if((ppszVals = ldap_get_values((LDAP *)pLdapID, pEntry, pszAttribute)) != NULL)
                {
                    if (*ppszVals) {
                        strcpy(p12password, ppszVals[0]);
                        break;
                    }
                }
            }

        }

        if (ppszVals)
            ldap_value_free(ppszVals);

        if (pszAttribute)
            ldap_memfree(pszAttribute);

        if (ber != NULL) 
            ldap_ber_free(ber, 0);

        for ( i = 0; subInfo[i].pszName != NULL; i++ ){
            if ( strcmp(subInfo[i].pszName, VSKPI_P12PASSWORD) == 0 ){
                strcpy(subInfo[i].pszValue, p12password);
                break;
            } 
        }

        if ( subInfo[i].pszValue == NULL ){
            status = VSAA_KM_ODBC_ERR_QUERY;
        }
    } while (0);


    return status;

}

VSAA_STATUS 
DIM_KMRecoverKeyAndCert(
    LDAP           *pLdapID,
    LDAPMessage	   *pEntry, 
    const VSAA_NAME  subInfo[])
{
    RETCODE      rc = 0;
    int          i, count;
    VSAA_STATUS  status = VSAA_SUCCESS;
    char         pcert[kDB_CERTIFICATE_MAX_LENGTH], pmask[kDB_MASK_MAX_LENGTH], piv[kDB_IV_MAX_LENGTH];
    char         peprivkey[kDB_EPRIVKEY_MAX_LENGTH], cname[kDB_COMMONNAME_MAX_LENGTH];
    char         *webpin = NULL;
    BerElement   *ber=NULL;
    char         **ppszVals = NULL, *pszAttribute = NULL;

    DIM_TRACE("DIM_KMRecoverKeyAndCert()");

    do {
        webpin = (char*)VSAAUTIL_FindUserInputValue(VSKPI_WEBPIN, strlen(VSKPI_WEBPIN), subInfo);
        if ( webpin == NULL ){
          VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "webpin is missing from inputList");
          status = VSAA_KM_WEBPIN_MISSING;
          break;
        }

        // Initialize the variable before using it.
        memset(pcert, 0, kDB_CERTIFICATE_MAX_LENGTH);
        memset(pmask, 0, kDB_MASK_MAX_LENGTH);
        memset(piv, 0, kDB_IV_MAX_LENGTH);
        memset(peprivkey, 0, kDB_EPRIVKEY_MAX_LENGTH);
        memset(cname, 0, kDB_COMMONNAME_MAX_LENGTH);

	count = 0;
        for (pszAttribute = ldap_first_attribute(pLdapID, pEntry, &ber);
              pszAttribute!=NULL; 
              pszAttribute = ldap_next_attribute(pLdapID, pEntry, ber) ) 
        {
	    if (count >= 6) 
	        // all entries are found
                break;      
            else if (VSAAUTIL_StrCaseCmp(pszAttribute, DIM_RecoverGetLdapAttrName(VSKPI_CERT_STATUS)) == 0) {
                if ((ppszVals = ldap_get_values((LDAP *)pLdapID, pEntry, pszAttribute)) != NULL && *ppszVals) {
                    if ((VSAAUTIL_StrCaseCmp(ppszVals[0], kDB_STATE_ISSUED) != 0) && (VSAAUTIL_StrCaseCmp(ppszVals[0], kDB_STATE_PENDING) != 0) ) {
                        VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "Cert status is not issued, so the certificate can not be recovered");
                        status = VSAA_KM_RECOVERINFO_EMPTY;
                        break;
                    } else {
                        // continue
                        count++;
                    }
                }
            } else if (VSAAUTIL_StrCaseCmp(pszAttribute, DIM_RecoverGetLdapAttrName(VSKPI_MASK)) == 0) {
                if((ppszVals = ldap_get_values((LDAP *)pLdapID, pEntry, pszAttribute)) != NULL && *ppszVals) {
                    strcpy(pmask, ppszVals[0]);
                    count++;
                } else {
                    VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "Mask retrieved from recovery data source is empty");
                    status = VSAA_KM_RECOVERINFO_EMPTY;
                    break;
                }
            } else if (VSAAUTIL_StrCaseCmp(pszAttribute, DIM_RecoverGetLdapAttrName(VSKPI_IV)) == 0) {
                if((ppszVals = ldap_get_values((LDAP *)pLdapID, pEntry, pszAttribute)) != NULL && *ppszVals) {
                    strcpy(piv, ppszVals[0]);
                    count++;                  
                } else {
                  VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "IV retrieved from recovery data source is empty");
                  status = VSAA_KM_RECOVERINFO_EMPTY;
                  break;
                }
            }  else if (VSAAUTIL_StrCaseCmp(pszAttribute, DIM_RecoverGetLdapAttrName(VSKPI_PRIKEY)) == 0) {
                if((ppszVals = ldap_get_values((LDAP *)pLdapID, pEntry, pszAttribute)) != NULL && *ppszVals) {
                    strcpy(peprivkey, ppszVals[0]);
                    count++;                   
                } else {
                  VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "Encrypted private key retrieved from recovery data source is empty");
                  status = VSAA_KM_RECOVERINFO_EMPTY;
                  break;
                }
            }  else if (VSAAUTIL_StrCaseCmp(pszAttribute, DIM_RecoverGetLdapAttrName(VSKPI_COMMONNAME)) == 0) {
                if((ppszVals = ldap_get_values((LDAP *)pLdapID, pEntry, pszAttribute)) != NULL && *ppszVals) {
                    strcpy(cname, ppszVals[0]);
                    count++;
                } else {
                  VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "Common name retrieved from recovery data source is empty");
                  status = VSAA_KM_RECOVERINFO_EMPTY;
                  break;
                }
           } else if (VSAAUTIL_StrCaseCmp(pszAttribute, DIM_RecoverGetLdapAttrName(VSKPI_CERT)) == 0) {
                if((ppszVals = ldap_get_values((LDAP *)pLdapID, pEntry, pszAttribute)) != NULL && *ppszVals)
                {
                    strcpy(pcert, ppszVals[0]);
                    count++;
                } else {
                    VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "Cert retrieved from recovery data source is empty");
                    status = VSAA_KM_RECOVERINFO_EMPTY;
                    break;
                }
	   }
        }

        if (ppszVals)
            ldap_value_free(ppszVals);

        if (pszAttribute)
            ldap_memfree(pszAttribute);
 
        if (ber) 
            ber_free(ber, 0);    
        
        // copy the query result into array
        for ( i = 0; subInfo[i].pszName != NULL; i++ ){
          if ( strcmp(subInfo[i].pszName, VSKPI_CERT_OR_CRL) == 0 ){
            strcpy(subInfo[i].pszValue, pcert);
          } else if ( strcmp(subInfo[i].pszName, VSKPI_MASK) == 0 ){
            strcpy(subInfo[i].pszValue, pmask);
          } else if ( strcmp(subInfo[i].pszName, VSKPI_IV) == 0 ){
            strcpy(subInfo[i].pszValue, piv);
          } else if ( strcmp(subInfo[i].pszName, VSKPI_EPRIKEY) == 0 ){
            strcpy(subInfo[i].pszValue, peprivkey);
          } else if ( strcmp(subInfo[i].pszName, KEY_COMMONNAME) == 0 ){
            strcpy(subInfo[i].pszValue, cname);
          }
        }

    } while (0);

    return status;
}

VSAA_STATUS 
DIM_KMUpdateCertForPickup(
    LDAP           *pLdapID,
    LDAPMessage	   *pEntry, 
    const VSAA_NAME  subInfo[])
{
    RETCODE      rc = 0;
    int          i;
    VSAA_STATUS  status = VSAA_SUCCESS;
    char         cname[kDB_COMMONNAME_MAX_LENGTH];
    char         *webpin = NULL, *cert = NULL, *certStatus;
    char    *statusValues[2], *eventTimeValues[2], *p12passwordValues[2], *b64certValues[2];
    LDAPMod certAttr, statusAttr, eventTimeAttr, p12passwordAttr; 
    BerElement   *ber=NULL;
    char         **ppszVals = NULL, *pszAttribute = NULL;
    time_t       ltime;
    char         *eventTime = NULL;
    LDAPMod      *mods[10];
    char         *pszDN = NULL;
    LDAPMessage	 *pResult=NULL;

    DIM_TRACE("DIM_KMUpdateCertForPickup()");

    do {
        memset(cname, 0, kDB_COMMONNAME_MAX_LENGTH);

        webpin = (char*)VSAAUTIL_FindUserInputValue(VSKPI_WEBPIN, strlen(VSKPI_WEBPIN), subInfo);
        if ( webpin == NULL ){
            VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "webpin is missing from inputList");
            status = VSAA_KM_WEBPIN_MISSING;
            break;
        }

        cert = (char*)VSAAUTIL_FindUserInputValue(VSKPI_CERT_OR_CRL, strlen(VSKPI_CERT_OR_CRL), subInfo);
        if ( cert == NULL ){
            VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "cert is missing from inputList");
            status = VSAA_KM_PARAMETER_MISSING;
            break;
        }

        certStatus = (char*)VSAAUTIL_FindUserInputValue(VSKPI_CERT_STATUS, strlen(VSKPI_CERT_STATUS), subInfo);
        if ( certStatus == NULL ){
            VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "certStatus is missing from inputList");
            status = VSAA_KM_PARAMETER_MISSING;
            break;
        }

        if( (pszDN = ldap_get_dn(pLdapID, pEntry )) == NULL ) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Could not find DN from LDAP entry retrieve.");
            ldap_msgfree(pResult);
            ldap_unbind(pLdapID);                
            return DIM_LogError(VSAA_ERR_CFG_ENTRY_NOT_FOUND);
        }

        ldap_msgfree(pResult);

        for (  pszAttribute = ldap_first_attribute(pLdapID, pEntry, &ber);
              pszAttribute; 
              pszAttribute = ldap_next_attribute(pLdapID, pEntry, ber) ) 
        {
            if (VSAAUTIL_StrCaseCmp(pszAttribute, DIM_RecoverGetLdapAttrName(VSKPI_COMMONNAME)) == 0) {
                if((ppszVals = ldap_get_values((LDAP *)pLdapID, pEntry, pszAttribute)) != NULL)
                {
                    if (*ppszVals) {
                        strcpy(cname, ppszVals[0]);
                        break;
                    }
                }
            }
        }


        if (ppszVals)
            ldap_value_free(ppszVals);

        if (pszAttribute)
            ldap_memfree(pszAttribute);

        if (ber) 
            ber_free(ber, 0);    

        time( &ltime );
        eventTime = ctime(&ltime);
        eventTime[strlen(eventTime) - 1] = '\0';

        eventTimeValues[0] = eventTime;
        eventTimeValues[1] = NULL;
        eventTimeAttr.mod_op = LDAP_MOD_REPLACE | LDAP_MOD_ADD;
        eventTimeAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_EVENTTIME); 
        eventTimeAttr.mod_values = eventTimeValues;

        statusValues[0] = certStatus;
        statusValues[1] = NULL;
        statusAttr.mod_op = LDAP_MOD_REPLACE | LDAP_MOD_ADD;
        statusAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_CERT_STATUS);
        statusAttr.mod_values = statusValues;

        p12passwordValues[0] = (char *) " ";
        p12passwordValues[1] = NULL;
        p12passwordAttr.mod_op = LDAP_MOD_REPLACE;
        p12passwordAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_P12PASSWORD);
        p12passwordAttr.mod_values = p12passwordValues;


        b64certValues[0] = cert;
        b64certValues[1] = NULL;
        certAttr.mod_op = LDAP_MOD_REPLACE | LDAP_MOD_ADD; 
        certAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_CERT); 
        certAttr.mod_values = b64certValues;

        mods[0] = &statusAttr;
        mods[1] = &eventTimeAttr;   
        mods[2] = &certAttr;
        mods[3] = &p12passwordAttr;
        mods[4] = NULL;

        VS_Log (VS_LOG_INFO, __LINE__, __FILE__, NULL,  (char *) "About to update DN: %s", pszDN);

        /* make the change */
        rc = ldap_modify_s(pLdapID, pszDN, mods);

        if (rc != LDAP_SUCCESS) {
            VS_Log (VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "update ldap entry failed: %d", rc);
            status = VSAA_HARD_ERROR;
            break;
        }

        // copy the query result into array
        for ( i = 0; subInfo[i].pszName != NULL; i++ ){
            if ( strcmp(subInfo[i].pszName, KEY_COMMONNAME) == 0 ) {
                strcpy(subInfo[i].pszValue, cname);
            }
        }

    } while (0);

    return status;
}

VSAA_STATUS 
DIM_KMFindEntryByWebPin(
    LDAP           *pLdapID,
    LDAPMessage	   *pEntry, 
    const VSAA_NAME  subInfo[])
{
    RETCODE      rc = 0;
    int          i;
    VSAA_STATUS  status = VSAA_SUCCESS;
    char         cname[kDB_COMMONNAME_MAX_LENGTH];
    char         *webpin = NULL;
    BerElement   *ber=NULL;
    char         **ppszVals = NULL, *pszAttribute = NULL;

    DIM_TRACE("DIM_KMFindEntryByWebPin()");

    do {
        memset(cname, 0, kDB_COMMONNAME_MAX_LENGTH);

        for (  pszAttribute = ldap_first_attribute(pLdapID, pEntry, &ber);
          pszAttribute; 
          pszAttribute = ldap_next_attribute(pLdapID, pEntry, ber) ) 
        {
            if (VSAAUTIL_StrCaseCmp(pszAttribute, DIM_RecoverGetLdapAttrName(VSKPI_COMMONNAME)) == 0) {
                if((ppszVals = ldap_get_values((LDAP *)pLdapID, pEntry, pszAttribute)) != NULL)
                {
                    if (*ppszVals) {
                        strcpy(cname, ppszVals[0]);
                        break;
                    }
                }
            }

        }

        if (ppszVals)
            ldap_value_free(ppszVals);

        if (pszAttribute)
            ldap_memfree(pszAttribute);
 
        if (ber) 
            ber_free(ber, 0);    
       
        // copy the query result into array
        for ( i = 0; subInfo[i].pszName != NULL; i++ ) {
            if ( strcmp(subInfo[i].pszName, KEY_COMMONNAME) == 0 ) {
              strcpy(subInfo[i].pszValue, cname);
            } else if ( strcmp(subInfo[i].pszName, VSKPI_FOUND_ENTRY) == 0 ) {
              strcpy(subInfo[i].pszValue, "found");
            } 
        }
    } while (0);

    return status;
}
    
VSAA_STATUS 
DIM_KMDeleteFailedEntry(
    LDAP           *pLdapID,
    LDAPMessage	   *pEntry, 
    const VSAA_NAME  subInfo[])
{
    RETCODE      rc = 0;
    VSAA_STATUS  status = VSAA_SUCCESS;
    LDAPMessage	*pResult=NULL;
    char        *pszDN = NULL;

    DIM_TRACE("DIM_KMDeleteFailedEntry()");
    
    do {
        if( (pszDN = ldap_get_dn(pLdapID, pEntry )) == NULL ) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Could not find DN from LDAP entry retrieve.");
            ldap_msgfree(pResult);
            ldap_unbind(pLdapID);                
            return DIM_LogError(VSAA_ERR_CFG_ENTRY_NOT_FOUND);
        }

        ldap_msgfree(pResult);

        VS_Log (VS_LOG_INFO, __LINE__, __FILE__, NULL,  (char *) "About to delete DN: %s", pszDN);

       /* make the change */
        rc = ldap_delete_s(pLdapID, pszDN);

        if ( rc != LDAP_SUCCESS ) {
          VS_Log(VS_LOG_INFO, __LINE__, __FILE__, NULL, (char *) "LDAP delete operation failed:%s", rc);
        }
    } while (0);

    status = VSAA_SUCCESS;

    return status;
}

VSAA_STATUS 
DIM_KMChangePickupPassword(
    LDAP           *pLdapID,
    LDAPMessage	   *pEntry, 
    const VSAA_NAME  subInfo[])
{
    RETCODE      rc = 0;
    VSAA_STATUS  status = VSAA_SUCCESS;
     char        *webpin = NULL, *p12password = NULL;
    char         *p12passwordValues[2];
    LDAPMod      p12passwordAttr; 
    LDAPMod      *mods[2];  
    char         **ppszVals = NULL, *pszAttribute = NULL;
    BerElement   *ber=NULL;
    char         *pszDN = NULL;
    LDAPMessage	*pResult=NULL;

    DIM_TRACE("DIM_KMChangePickupPassword()");

    do {
        webpin = (char*)VSAAUTIL_FindUserInputValue(VSKPI_WEBPIN, strlen(VSKPI_WEBPIN), subInfo);
         if ( webpin == NULL ) {
             VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "webpin is missing from inputList");
             status = VSAA_KM_WEBPIN_MISSING;
             break;
         }

         p12password = (char*) VSAAUTIL_FindUserInputValue(VSKPI_P12PASSWORD, strlen(VSKPI_P12PASSWORD), subInfo);
         if ( p12password == NULL ) {
             VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL, (char *) "p12 password is missing from inputList");
             status = VSAA_KM_PARAMETER_MISSING;
              break;
         }

        for (  pszAttribute = ldap_first_attribute(pLdapID, pEntry, &ber);
          pszAttribute; 
          pszAttribute = ldap_next_attribute(pLdapID, pEntry, ber) ) 
        {
            if (VSAAUTIL_StrCaseCmp(pszAttribute, DIM_RecoverGetLdapAttrName(VSKPI_CERT_STATUS)) == 0) {
                if((ppszVals = ldap_get_values((LDAP *)pLdapID, pEntry, pszAttribute)) != NULL)
                {
                    if (*ppszVals) {
		                if (strcmp(ppszVals[0], "pending")==0 || strcmp(ppszVals[0], "issued")==0) {
                            status = VSAA_SUCCESS;
                            break;
                        } else {
			                status = VSAA_INTERNAL_ERROR;
                            break;
                        }
                    }
                }
            }
        }

        if (ppszVals)
            ldap_value_free(ppszVals);

        if (pszAttribute)
            ldap_memfree(pszAttribute);
 
        if (ber) 
            ber_free(ber, 0);    
       
        if (status == VSAA_SUCCESS) {
            /* build dn to modify */

            if( (pszDN = ldap_get_dn(pLdapID, pEntry )) == NULL ) {
                VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Could not find DN from LDAP entry retrieve.");
                ldap_msgfree(pResult);
                ldap_unbind(pLdapID);                
                return DIM_LogError(VSAA_ERR_CFG_ENTRY_NOT_FOUND);
            }

            ldap_msgfree(pResult);

            // need to check the cert_status is pending

            p12passwordValues[0] = p12password;
            p12passwordValues[1] = NULL;
            p12passwordAttr.mod_op = LDAP_MOD_REPLACE | LDAP_MOD_ADD;
            p12passwordAttr.mod_type = (char *) DIM_RecoverGetLdapAttrName(VSKPI_P12PASSWORD);
            p12passwordAttr.mod_values = p12passwordValues;

            mods[0] = &p12passwordAttr;
            mods[1] = NULL;
 
           VS_Log (VS_LOG_INFO, __LINE__, __FILE__, NULL,  (char *) "About to update the pickup password for %s", pszDN);
       
           /* make the change */
            rc = ldap_modify_s(pLdapID, pszDN, mods);

            if (rc != LDAP_SUCCESS) {
                VS_Log (VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "update ldap entry failed: %d", rc);
                status = VSAA_HARD_ERROR;
                break;
            }
        }
    } while (0);

    return status;
}





static VSAA_STATUS DoVerifyUser(const VSAA_NAME userInput[], VSAA_NAME **augmentedData)
{
    VSAA_STATUS	status = VSAA_SUCCESS;
    
    LDAP        *pLdapID=NULL;
    LDAPMessage	*pResult=NULL, *pEntry=NULL;

    /* 
       The value of the following variables might be from user's input,
       it should be allocated as needed rather than using a fixed size
       buffer which might cause over-flow.
    */

    char        *pszFilter = NULL;
    char        *pszUserDN = NULL;
    char        *pszUserPWD = NULL;

    const char  *pszStatus = VSAA_YES;
        

    VSAA_BOOL      useExternalLDAPServer = DIM_IsExternalLDAPServerRequested(userInput);
    DIMCfgLDAPHost *pLdapHostCfg = (useExternalLDAPServer == VSAA_FALSE)?&gDIMCfg.verLDAPCfg:&gDIMCfg.verLDAPExternalCfg;

    DIM_TRACE("VerifyUser()");

    /* preparing the search filter */
    
    if( 
        (status = DIM_BuildLDAPSearchFilter(
                      &pszFilter,
                      userInput, 
                      gDIMCfg.verAttrListPtr, 
                      gDIMCfg.setAttrListPtr, 
                      pLdapHostCfg->szObjClass)
        ) != VSAA_SUCCESS
      ) 
    {
        return DIM_LogError(status);
    }
    
    /* preparing the bind DN and PWD */

    if (!*pLdapHostCfg->szBindDN) {

        pszUserDN = pszUserPWD = NULL;

    } else {

        if( 
            (status = DIM_BuildBindDNPassword(
                          &pszUserDN,
                          &pszUserPWD,
                          userInput, 
                          pLdapHostCfg,
                          pszFilter) 
            ) != VSAA_SUCCESS 
          ) 
        {
            if(pszFilter) VSAAUTIL_Free(pszFilter);
            if(pszUserDN) VSAAUTIL_Free(pszUserDN);
            if(pszUserPWD) VSAAUTIL_Free(pszUserPWD);

            return DIM_LogError(status);
        }

    }

    /* 
        Use the binding information to connect to authentication LDAP server 
        Query LDAP server for the entry to be verified. The successful query
        will return valid pResult and pEntry for given search filter.
    */

    status = DIM_QueryLDAPServer(
        &pLdapID,
        &pResult,
        &pEntry,
        pLdapHostCfg->szHostName,
        pLdapHostCfg->nSSLEnabled?pLdapHostCfg->nSSLPort:pLdapHostCfg->nPort, 
        pLdapHostCfg->nSSLEnabled,
        pLdapHostCfg->szCertDB,
        pLdapHostCfg->szBaseDN,
        pszUserDN, 
        pszUserPWD,
        pszFilter,
        pLdapHostCfg->nProtocolVersion);
    
    if(pszFilter) VSAAUTIL_Free(pszFilter);
    if(pszUserDN) VSAAUTIL_Free(pszUserDN);
    if(pszUserPWD) VSAAUTIL_Free(pszUserPWD);


    if(status != VSAA_SUCCESS ) {
      if ( pLdapID )
        ldap_unbind(pLdapID);
      pLdapID = 0;

	/* Start : CR25934 augment user input data from information provided in LDAP server. */
        /* Commented out to fix the Honeywell reported issue of enrollment passing even if the verification failed.
    status = DIM_AugmentUserDataWithLDAPEntry(
        augmentedData,
        userInput,
        pszStatus,
        pLdapID,
        pEntry,
        gDIMCfg.setAttrListPtr,
        gDIMCfg.getAttrListPtr);
        */
	/* End : CR25934 */
      
      return DIM_LogError(status);
    }

    /*     
      Determine whether all required match data are satisfied. 
      If not, VSAA_PENDING should be reported for MANUAL_AUTH attributes, 
      and VSAA_NO for AUTH attributes.
    */

    const char* inputEncoding = VSAAUTIL_FindUserInputValue(VSAA_ENCODING_NAME, strlen(VSAA_ENCODING_NAME), userInput);
    if(VSAA_TRUE != DIM_IsLDAPEntryAuthorized(pLdapID, pEntry, inputEncoding, gDIMCfg.authAttrListPtr))
        pszStatus = VSAA_NO;    
    else if(VSAA_TRUE != DIM_CompareUserInputWithLDAPEntry(userInput, pLdapID, pEntry, gDIMCfg.manualAuthAttrListPtr))
        pszStatus = VSAA_PENDING;
    
    /* 
       Validation is done, we are ready to augment user input data from
       information provided in LDAP server.
    */
    
    status = DIM_AugmentUserDataWithLDAPEntry(
        augmentedData,
        userInput,
        pszStatus,
        pLdapID,
        pEntry,
        gDIMCfg.setAttrListPtr,
        gDIMCfg.getAttrListPtr);

    ldap_msgfree(pResult);
    ldap_unbind(pLdapID);

    return status;
}


void
DIM_SetDefaultCfg(DIMCfg* pDIMCfg)
{
    DIM_TRACE("DIM_SetDefaultCfg()");

    DIM_InitLDAPHostCfg(&pDIMCfg->verLDAPCfg);
    DIM_InitLDAPHostCfg(&pDIMCfg->regLDAPCfg);
    DIM_InitLDAPHostCfg(&pDIMCfg->recoverLDAPCfg);
    // recover data source use "inetOrgPerson" object class as default
    strcpy(pDIMCfg->recoverLDAPCfg.szObjClass, "inetOrgPerson");
    DIM_InitLDAPHostCfg(&pDIMCfg->verLDAPExternalCfg);
    DIM_InitLDAPHostCfg(&pDIMCfg->regLDAPExternalCfg);

    pDIMCfg->mapAttrListPtr = NULL;
    pDIMCfg->verAttrListPtr = NULL;
    pDIMCfg->authAttrListPtr = NULL;
    pDIMCfg->manualAuthAttrListPtr = NULL;
    pDIMCfg->getAttrListPtr = NULL;
    pDIMCfg->setAttrListPtr = NULL;
    pDIMCfg->regAttrListPtr = NULL;
    pDIMCfg->updAttrListPtr = NULL;	

    pDIMCfg->certStatusAttrName[0] = '\0';
    pDIMCfg->certStatusValid[0] = '\0';
    pDIMCfg->certStatusInvalid[0] = '\0';
    pDIMCfg->certStatusRevoked[0] = '\0';

    pDIMCfg->nLogEnabled = VSAA_FALSE;

    pDIMCfg->nPrePickupProcess = VSAA_FALSE;
    pDIMCfg->nPreRevokeProcess = VSAA_FALSE;
    pDIMCfg->nPreRenewalProcess = VSAA_FALSE;
}

void
DIM_FreeCfg(DIMCfg* pDIMCfg)
{
    DIM_TRACE("DIM_FreeCfg()");

    if(!pDIMCfg) return;

    VSAAUTIL_FreeCfgNVPairList(pDIMCfg->mapAttrListPtr);
    VSAAUTIL_FreeCfgAttrList(pDIMCfg->verAttrListPtr);
    VSAAUTIL_FreeCfgNVPairList(pDIMCfg->authAttrListPtr);
    VSAAUTIL_FreeCfgAttrList(pDIMCfg->manualAuthAttrListPtr);
    VSAAUTIL_FreeCfgAttrList(pDIMCfg->getAttrListPtr);
    VSAAUTIL_FreeCfgNVPairList(pDIMCfg->setAttrListPtr);
    VSAAUTIL_FreeCfgNVTripleList(pDIMCfg->regAttrListPtr);
    VSAAUTIL_FreeCfgAttrList(pDIMCfg->updAttrListPtr);    

    DIM_SetDefaultCfg(pDIMCfg);
}

void 
DIM_InitLDAPHostCfg(DIMCfgLDAPHost* hostCfgPtr)
{
    DIM_TRACE("DIM_InitLDAPHostCfg()");

    if(hostCfgPtr == NULL) return;

    *hostCfgPtr->szHostName = 0;
    hostCfgPtr->nPort = -1;
    hostCfgPtr->nSSLPort = -1;
    hostCfgPtr->nProtocolVersion = 3;
    *hostCfgPtr->szBindDN = 0;
    *hostCfgPtr->szBindPassword = 0;
    *hostCfgPtr->szReadDN = 0;
    *hostCfgPtr->szReadPassword = 0;
    *hostCfgPtr->szBaseDN = 0;
    *hostCfgPtr->szObjClass = 0;
    *hostCfgPtr->szEmailAttr = 0;
    hostCfgPtr->nSSLEnabled = VSAA_FALSE;
    *hostCfgPtr->szCertDB = 0;
    
}

char* 
DIM_GetErrorMsg(VSAA_STATUS status)
{
    int i;

    for(i=0; i<(int)gDIMErrorListCnt; i++) {
        if(gDIMErrorList[i].errId == (unsigned int)status) return gDIMErrorList[i].errMsg;
    }

    return gDIMErrorList[0].errMsg;
}

VSAA_STATUS 
DIM_LogError(VSAA_STATUS status)
{
    VS_Log(VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "Error 0x%x: %s", status, DIM_GetErrorMsg(status));
    
    return status;
}


/* 
   This function read config entries from given file into gLDAPCfg.
   Because the configuration file also contains entries for AA server
   and ODBC setting, those entries will not be examined in this LDAP
   module. Thus this function only logs unrecognized entries in log file
   and then continue to read rest of file. However, invalid LDAP entries
   will cause the function to fail. This serves to ensure the program 
   to do what customers actually want to do. 
*/

VSAA_STATUS
DIM_ReadConfigFile(const char* pszServiceCfgFileName)
{
    VSAA_STATUS status = VSAA_SUCCESS;
    FILE*       cfgFp;
    char        szLine[MAX_CFG_VALUE_LENGTH];
    char        szOrigLine[MAX_CFG_VALUE_LENGTH];
    char*       pszName = NULL;
    int         i;
    int         toDecryptFlag = VSAA_FALSE;
    char        decryptedString[BUF_MAX_LEN];
    int         decryptedStringLen;
	
    VSAACfgAttrList* valueListPtr = NULL;

    /* open configuration file */

    cfgFp = fopen(pszServiceCfgFileName, "r");
    if (!cfgFp) {
        VS_Log (VS_LOG_ERROR, __LINE__, __FILE__, NULL,    (char *) "Could not open file %s to read configuration data.", pszServiceCfgFileName);
        return VSAA_LDAP_ERR_CFG;
    }

    /* while there are more lines in the config file */

    while((status = VSAAUTIL_ReadEntryLine(szLine, MAX_CFG_VALUE_LENGTH, cfgFp)) == VSAA_SUCCESS && *szLine)
    {
        if (*szLine == CFG_COMMENT_MARK) {
          if ( strstr(szLine, TODECRYPT_LINE) != NULL ) {
            gHasEncryptedLine = VSAA_TRUE;
            toDecryptFlag = VSAA_TRUE;
          }
          continue;
        }


        strcpy(szOrigLine, szLine);        
        
        /* 
            assume each config entry consists of less than MAX_CFG_VALUE_LENGTH 
            characters which might spread several lines.
        */

        i = strlen(szLine);
        if( i == MAX_CFG_VALUE_LENGTH && szLine[i-1] != '\n') {
            status = VSAA_ERR_CFG_FILE_LINE_TOO_LONG;
            VS_Log (VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "A configuration line was found to be too long (>%ld bytes): %s", MAX_CFG_VALUE_LENGTH, szLine);
            break;
        } else {
            szOrigLine[i-1] = '\0';
        }

        /* 
            the last char will be a newline.  blow it away, and then
            squeeze out the trailing spaces. 
        */

        szLine[i--] = '\0';
        while(isspace(szLine[i])) 
            szLine[i--] = '\0';

        /* find the offset of the first non-space character */
        
        i = 0;		
        while(isspace(szLine[i])) 
            i++;		

        /* allow blank lines in configuration file */

        if(szLine[i] == 0) continue;

        /* decrypt the value */
        if ( toDecryptFlag == VSAA_TRUE ) {
          int j = 0;

          /* szLine +i is the beginning of the name
             szLine +i +j is the beginning of the value
            */
          while ( !isspace(szLine[i+j]) ) j++;
          while (  isspace(szLine[i+j]) )  j++;
          memset( decryptedString, 0, BUF_MAX_LEN);
          decryptedStringLen = BUF_MAX_LEN;
          if ( vsaautil_decrypt(szLine + i +j, strlen(szLine + i +j), decryptedString, &decryptedStringLen) != 0 ) {
            VS_Log (VS_LOG_ERROR, __LINE__, __FILE__, NULL,   (char *) "Unable to decrypt line: %s", szOrigLine);
            status = VSAA_LDAP_ERR_CFG;
            break;
          }
          sprintf(szLine +i +j, "%s\n", decryptedString);
          toDecryptFlag = VSAA_FALSE;
        }

        
        /* split to get name and its value parts */

        pszName = NULL;
        valueListPtr = NULL;

        /* extract from the first non-space character */
        status = VSAAUTIL_ExtractAttrNameValues(&pszName, &valueListPtr, szLine + i);

        if(status != VSAA_SUCCESS) {
            
            VS_Log (VS_LOG_WARNING, __LINE__, __FILE__, NULL,   (char *) "Invalid entry in configuration file: %s", szOrigLine);
            break;

        } else if(!pszName) {
            
            VS_Log (VS_LOG_ERROR, __LINE__, __FILE__, NULL,   (char *) "Invalid entry in configuration file: %s", szOrigLine);
            if(valueListPtr) VSAAUTIL_FreeCfgAttrList(valueListPtr);
            status = VSAA_LDAP_ERR_CFG;
            break;

        } else {

            /* figure out which name this is */

            i = VSAAUTIL_CountAttr(valueListPtr);

            if( !strncmp(pszName, VER_PREFIX, strlen(VER_PREFIX)) && LDAP_VERIFICATION_USED) {
                
                /* 
                    Attributes for authentication LDAP server were found;
                    each attribute should consists of only two entries:
                    the name and its value. If multiple values are given,
                    the configuration is not correct.                    
                */

                if(i != 1) {

                    if( i == 0 && IS_NULL_PASSWORD_ALLOWED && 
                        (!strcmp(VER_PWD, pszName) || 
                         !strcmp(VER_READ_PWD, pszName) ||
                         !strcmp(VER_PWD_EXTERNAL, pszName) ||
                         !strcmp(VER_READ_PWD_EXTERNAL, pszName)
                        )
                      )
                    {
                    
                        VS_Log (VS_LOG_WARNING, __LINE__, __FILE__, NULL,  (char *) "No value was given for %s", pszName);
                    } else if ( i == 0 && !strcmp(VER_HOST, pszName) ) {
                        LDAP_VERIFICATION_USED = VSAA_FALSE;
                        VS_Log (VS_LOG_INFO, __LINE__, __FILE__, NULL,  (char *) "No LDAP verification host is specified, so LDAP will not be used as verification data source.");
                    } else {
                         
                        status = VSAA_LDAP_ERR_CFG;

                    }

                } else {
                
                    if(!strcmp(VER_HOST, pszName))
                        strcpy(gDIMCfg.verLDAPCfg.szHostName, valueListPtr->pszValue);                    
                    else if(!strcmp(VER_PORT, pszName)) 
                        sscanf(valueListPtr->pszValue, "%d", &gDIMCfg.verLDAPCfg.nPort);
                    else if(!strcmp(VER_SSL_PORT, pszName)) 
                        sscanf(valueListPtr->pszValue, "%d", &gDIMCfg.verLDAPCfg.nSSLPort);
                    else if(!strcmp(VER_DN, pszName)) 
                        strcpy(gDIMCfg.verLDAPCfg.szBindDN, valueListPtr->pszValue);
                    else if(!strcmp(VER_PWD, pszName))
                        strcpy(gDIMCfg.verLDAPCfg.szBindPassword, valueListPtr->pszValue);
                    else if(!strcmp(VER_READ_DN, pszName)) 
                        strcpy(gDIMCfg.verLDAPCfg.szReadDN, valueListPtr->pszValue);
                    else if(!strcmp(VER_READ_PWD, pszName))
                        strcpy(gDIMCfg.verLDAPCfg.szReadPassword, valueListPtr->pszValue);
                    else if(!strcmp(VER_BASEDN, pszName))
                        strcpy(gDIMCfg.verLDAPCfg.szBaseDN, valueListPtr->pszValue);
                    else if(!strcmp(VER_OBJCLASS, pszName))
                        strcpy(gDIMCfg.verLDAPCfg.szObjClass, valueListPtr->pszValue);
                    else if(!strcmp(VER_EMAIL, pszName))
                        strcpy(gDIMCfg.verLDAPCfg.szEmailAttr, valueListPtr->pszValue);
                    else if(!strcmp(VER_SSL, pszName)) 
                        gDIMCfg.verLDAPCfg.nSSLEnabled = !VSAAUTIL_StrCaseCmp(VSAA_ON, valueListPtr->pszValue);
                    else if(!strcmp(VER_CERTDB, pszName))
                        strcpy(gDIMCfg.verLDAPCfg.szCertDB, valueListPtr->pszValue);
                    else if (!strcmp(VER_PROTOCOL_VERSION, pszName))
                        sscanf(valueListPtr->pszValue, "%d", &gDIMCfg.verLDAPCfg.nProtocolVersion); 

                    /* attributes for external authentication LDAP server */
                    
                    else if(!strcmp(VER_HOST_EXTERNAL, pszName))
                        strcpy(gDIMCfg.verLDAPExternalCfg.szHostName, valueListPtr->pszValue);
                    else if (!strcmp(VER_PORT_EXTERNAL, pszName))
                        sscanf(valueListPtr->pszValue, "%d", &gDIMCfg.verLDAPExternalCfg.nPort);                    
                    else if (!strcmp(VER_SSL_PORT_EXTERNAL, pszName))
                        sscanf(valueListPtr->pszValue, "%d", &gDIMCfg.verLDAPExternalCfg.nSSLPort);    
                    else if (!strcmp(VER_DN_EXTERNAL, pszName)) 
                        strcpy(gDIMCfg.verLDAPExternalCfg.szBindDN, valueListPtr->pszValue);
                    else if (!strcmp(VER_PWD_EXTERNAL, pszName)) 
                        strcpy(gDIMCfg.verLDAPExternalCfg.szBindPassword, valueListPtr->pszValue);
                    else if(!strcmp(VER_READ_DN_EXTERNAL, pszName)) 
                        strcpy(gDIMCfg.verLDAPExternalCfg.szReadDN, valueListPtr->pszValue);
                    else if(!strcmp(VER_READ_PWD_EXTERNAL, pszName))
                        strcpy(gDIMCfg.verLDAPExternalCfg.szReadPassword, valueListPtr->pszValue);
                    else if (!strcmp(VER_BASEDN_EXTERNAL, pszName))
                        strcpy(gDIMCfg.verLDAPExternalCfg.szBaseDN, valueListPtr->pszValue);
                    else if (!strcmp(VER_OBJCLASS_EXTERNAL, pszName))
                        strcpy(gDIMCfg.verLDAPExternalCfg.szObjClass, valueListPtr->pszValue);
                    else if(!strcmp(VER_EMAIL_EXTERNAL, pszName))
                        strcpy(gDIMCfg.verLDAPExternalCfg.szEmailAttr, valueListPtr->pszValue);
                    else if(!strcmp(VER_SSL_EXTERNAL, pszName)) 
                        gDIMCfg.verLDAPExternalCfg.nSSLEnabled = !VSAAUTIL_StrCaseCmp(VSAA_ON, valueListPtr->pszValue);
                    else if(!strcmp(VER_CERTDB_EXTERNAL, pszName))
                        strcpy(gDIMCfg.verLDAPExternalCfg.szCertDB, valueListPtr->pszValue);
                }

            } else if(!strncmp(pszName, REG_PREFIX, strlen(REG_PREFIX)) && LDAP_REGISTRATION_USED) {
                
                /* attributes for registration LDAP server */

                if(i != 1) {
                    
                    if( i == 0 && IS_NULL_PASSWORD_ALLOWED && 
                        (!strcmp(REG_PWD, pszName) || 
                         !strcmp(REG_READ_PWD, pszName) ||
                         !strcmp(REG_PWD_EXTERNAL, pszName) ||
                         !strcmp(REG_READ_PWD_EXTERNAL, pszName)
                        )
                      )
                    {
                    
                        VS_Log (VS_LOG_WARNING, __LINE__, __FILE__, NULL,  (char *) "No value was given for %s", pszName);

                    } else if ( i == 0 && !strcmp(REG_HOST, pszName) ) {
                        LDAP_REGISTRATION_USED = VSAA_FALSE;
                        VS_Log (VS_LOG_INFO, __LINE__, __FILE__, NULL,  (char *) "No LDAP registration host is specified, so LDAP will not be used as registration data source.");
                    } else {
                         
                        status = VSAA_LDAP_ERR_CFG;

                    }

                } else {
                
                    if(!strcmp(REG_HOST, pszName)) 
                        strcpy(gDIMCfg.regLDAPCfg.szHostName, valueListPtr->pszValue);                    
                    else if(!strcmp(REG_PORT, pszName)) 
                        sscanf(valueListPtr->pszValue, "%d", &gDIMCfg.regLDAPCfg.nPort);
                    else if(!strcmp(REG_SSL_PORT, pszName)) 
                        sscanf(valueListPtr->pszValue, "%d", &gDIMCfg.regLDAPCfg.nSSLPort);
                    else if(!strcmp(REG_DN, pszName)) 
                        strcpy(gDIMCfg.regLDAPCfg.szBindDN, valueListPtr->pszValue);
                    else if(!strcmp(REG_PWD, pszName))
                        strcpy(gDIMCfg.regLDAPCfg.szBindPassword, valueListPtr->pszValue);
                    else if(!strcmp(REG_READ_DN, pszName)) 
                        strcpy(gDIMCfg.regLDAPCfg.szReadDN, valueListPtr->pszValue);
                    else if(!strcmp(REG_READ_PWD, pszName))
                        strcpy(gDIMCfg.regLDAPCfg.szReadPassword, valueListPtr->pszValue);
                    else if(!strcmp(REG_BASEDN, pszName))
                        strcpy(gDIMCfg.regLDAPCfg.szBaseDN, valueListPtr->pszValue);
                    else if(!strcmp(REG_OBJCLASS, pszName))
                        strcpy(gDIMCfg.regLDAPCfg.szObjClass, valueListPtr->pszValue);
                    else if(!strcmp(REG_EMAIL, pszName))
                        strcpy(gDIMCfg.regLDAPCfg.szEmailAttr, valueListPtr->pszValue);
                    else if(!strcmp(REG_SSL, pszName)) 
                        gDIMCfg.regLDAPCfg.nSSLEnabled = !VSAAUTIL_StrCaseCmp(VSAA_ON, valueListPtr->pszValue);
                    else if(!strcmp(REG_CERTDB, pszName))
                        strcpy(gDIMCfg.regLDAPCfg.szCertDB, valueListPtr->pszValue);
                    else if (!strcmp(REG_PROTOCOL_VERSION, pszName))
                        sscanf(valueListPtr->pszValue, "%d", &gDIMCfg.regLDAPCfg.nProtocolVersion); 
                    
                    /* attributes for external registration LDAP server */
                    
                    else if(!strcmp(REG_HOST_EXTERNAL, pszName))
                        strcpy(gDIMCfg.regLDAPExternalCfg.szHostName, valueListPtr->pszValue);
                    else if (!strcmp(REG_PORT_EXTERNAL, pszName))
                        sscanf(valueListPtr->pszValue, "%d", &gDIMCfg.regLDAPExternalCfg.nPort);                    
                    else if (!strcmp(REG_SSL_PORT_EXTERNAL, pszName))
                        sscanf(valueListPtr->pszValue, "%d", &gDIMCfg.regLDAPExternalCfg.nSSLPort);    
                    else if (!strcmp(REG_DN_EXTERNAL, pszName)) 
                        strcpy(gDIMCfg.regLDAPExternalCfg.szBindDN, valueListPtr->pszValue);
                    else if (!strcmp(REG_PWD_EXTERNAL, pszName)) 
                        strcpy(gDIMCfg.regLDAPExternalCfg.szBindPassword, valueListPtr->pszValue);
                    else if(!strcmp(REG_READ_DN_EXTERNAL, pszName)) 
                        strcpy(gDIMCfg.regLDAPExternalCfg.szReadDN, valueListPtr->pszValue);
                    else if(!strcmp(REG_READ_PWD_EXTERNAL, pszName))
                        strcpy(gDIMCfg.regLDAPExternalCfg.szReadPassword, valueListPtr->pszValue);
                    else if (!strcmp(REG_BASEDN_EXTERNAL, pszName))
                        strcpy(gDIMCfg.regLDAPExternalCfg.szBaseDN, valueListPtr->pszValue);
                    else if (!strcmp(REG_OBJCLASS_EXTERNAL, pszName))
                        strcpy(gDIMCfg.regLDAPExternalCfg.szObjClass, valueListPtr->pszValue);
                    else if(!strcmp(REG_EMAIL_EXTERNAL, pszName))
                        strcpy(gDIMCfg.regLDAPExternalCfg.szEmailAttr, valueListPtr->pszValue);
                    else if(!strcmp(REG_SSL_EXTERNAL, pszName)) 
                        gDIMCfg.regLDAPExternalCfg.nSSLEnabled = !VSAAUTIL_StrCaseCmp(VSAA_ON, valueListPtr->pszValue);
                    else if(!strcmp(REG_CERTDB_EXTERNAL, pszName))
                        strcpy(gDIMCfg.regLDAPExternalCfg.szCertDB, valueListPtr->pszValue);
                    
                }

            } else if(!strncmp(pszName, RECOVER_PREFIX, strlen(RECOVER_PREFIX)) && LDAP_RECOVERY_USED ) {
                
                /* attributes for registration LDAP server */

                if(i != 1) {
                    
                    if( i == 0 && IS_NULL_PASSWORD_ALLOWED && 
                        (!strcmp(RECOVER_PWD, pszName) || 
                         !strcmp(RECOVER_READ_PWD, pszName)
                        )
                      )
                    {
                       VS_Log (VS_LOG_WARNING, __LINE__, __FILE__, NULL,  (char *) "No value was given for %s", pszName);

                    }  else if ( i == 0 && !strcmp(RECOVER_HOST, pszName) ) {
                        LDAP_RECOVERY_USED = VSAA_FALSE;
                        VS_Log (VS_LOG_INFO, __LINE__, __FILE__, NULL,  (char *) "No LDAP recovery host is specified, so LDAP will not be used as key recovery data source.");
                    } else if (!strcmp(RECOVER_LDAP_ATTR_MAP, pszName)) {
                        if(i != 2) 
                            status = VSAA_LDAP_ERR_CFG;
                        else
                            status = VSAAUTIL_AppendCfgNVPairEntry(&gDIMCfg.recoverMapAttrListPtr, valueListPtr->pszValue, valueListPtr->next->pszValue);                      
                    } else {
                         
                        status = VSAA_LDAP_ERR_CFG;
                    }

                } else {
                
                    if(!strcmp(RECOVER_HOST, pszName)) 
                        strcpy(gDIMCfg.recoverLDAPCfg.szHostName, valueListPtr->pszValue);                    
                    else if(!strcmp(RECOVER_PORT, pszName)) 
                        sscanf(valueListPtr->pszValue, "%d", &gDIMCfg.recoverLDAPCfg.nPort);
                    else if(!strcmp(RECOVER_SSL_PORT, pszName)) 
                        sscanf(valueListPtr->pszValue, "%d", &gDIMCfg.recoverLDAPCfg.nSSLPort);
                    else if(!strcmp(RECOVER_DN, pszName)) 
                        strcpy(gDIMCfg.recoverLDAPCfg.szBindDN, valueListPtr->pszValue);
                    else if(!strcmp(RECOVER_PWD, pszName))
                        strcpy(gDIMCfg.recoverLDAPCfg.szBindPassword, valueListPtr->pszValue);
                    else if(!strcmp(RECOVER_READ_DN, pszName)) 
                        strcpy(gDIMCfg.recoverLDAPCfg.szReadDN, valueListPtr->pszValue);
                    else if(!strcmp(RECOVER_READ_PWD, pszName))
                        strcpy(gDIMCfg.recoverLDAPCfg.szReadPassword, valueListPtr->pszValue);
                    else if(!strcmp(RECOVER_BASEDN, pszName))
                        strcpy(gDIMCfg.recoverLDAPCfg.szBaseDN, valueListPtr->pszValue);
                    else if(!strcmp(RECOVER_OBJCLASS, pszName))
                        strcpy(gDIMCfg.recoverLDAPCfg.szObjClass, valueListPtr->pszValue);
                    else if(!strcmp(RECOVER_EMAIL, pszName))
                        strcpy(gDIMCfg.recoverLDAPCfg.szEmailAttr, valueListPtr->pszValue);
                    else if(!strcmp(RECOVER_SSL, pszName)) 
                        gDIMCfg.recoverLDAPCfg.nSSLEnabled = !VSAAUTIL_StrCaseCmp(VSAA_ON, valueListPtr->pszValue);
                    else if(!strcmp(RECOVER_CERTDB, pszName))
                        strcpy(gDIMCfg.recoverLDAPCfg.szCertDB, valueListPtr->pszValue);  
                    else if (!strcmp(RECOVER_PROTOCOL_VERSION, pszName))
                        sscanf(valueListPtr->pszValue, "%d", &gDIMCfg.recoverLDAPCfg.nProtocolVersion);                     
                }

            } else if (!strcmp(LDAP_LOG, pszName)) {

                if(i != 1)                
                    status = VSAA_LDAP_ERR_CFG;                
                else 
                    gDIMCfg.nLogEnabled = !VSAAUTIL_StrCaseCmp(VSAA_ON, valueListPtr->pszValue);             

            } else if (!strcmp(LDAP_LOG_LEVEL, pszName)) {

                if(i != 1)                
                    status = VSAA_LDAP_ERR_CFG;                
                else {
                    gDIMCfg.nLogLevel = atoi(valueListPtr->pszValue);             
                }

            } else if (!strcmp(LDAP_PREPICKUP_PROCESS, pszName)) {

                if(i != 1)                
                    status = VSAA_LDAP_ERR_CFG;                
                else 
                    gDIMCfg.nPrePickupProcess = !VSAAUTIL_StrCaseCmp(VSAA_ON, valueListPtr->pszValue);             

            } else if (!strcmp(LDAP_PREREVOKE_PROCESS, pszName)) {

                if(i != 1)                
                    status = VSAA_LDAP_ERR_CFG;                
                else 
                    gDIMCfg.nPreRevokeProcess = !VSAAUTIL_StrCaseCmp(VSAA_ON, valueListPtr->pszValue);             

            } else if (!strcmp(LDAP_PRERENEWAL_PROCESS, pszName)) {

                if(i != 1)                
                    status = VSAA_LDAP_ERR_CFG;                
                else 
                    gDIMCfg.nPreRenewalProcess = !VSAAUTIL_StrCaseCmp(VSAA_ON, valueListPtr->pszValue);             

            } else if (!strcmp(LDAP_ATTR_MAP, pszName)) {

                if(i != 2) 
                    status = VSAA_LDAP_ERR_CFG;
                else
                    status = VSAAUTIL_AppendCfgNVPairEntry(&gDIMCfg.mapAttrListPtr, valueListPtr->pszValue, valueListPtr->next->pszValue);

            } else if (!strcmp(LDAP_ATTR_SET, pszName)) {
                
                if(i != 2) 
                    status = VSAA_LDAP_ERR_CFG;
                else
                    status = VSAAUTIL_AppendCfgNVPairEntry(&gDIMCfg.setAttrListPtr, valueListPtr->pszValue, valueListPtr->next->pszValue);
                
            } else if (!strcmp(LDAP_ATTR_VER, pszName)) {
                
                if(i != 1) 
                    status = VSAA_LDAP_ERR_CFG;
                else
                    status = VSAAUTIL_AppendCfgAttrEntry(&gDIMCfg.verAttrListPtr, valueListPtr->pszValue);
                
            } else if (!strcmp(LDAP_ATTR_AUTH, pszName)) {
                
                if(i != 2) 
                    status = VSAA_LDAP_ERR_CFG;
                else
                    status = VSAAUTIL_AppendCfgNVPairEntry(&gDIMCfg.authAttrListPtr, valueListPtr->pszValue, valueListPtr->next->pszValue);
                
            } else if (!strcmp(LDAP_ATTR_MANUAL_AUTH, pszName)) {
                
                if(i != 1) 
                    status = VSAA_LDAP_ERR_CFG;
                else
                    status = VSAAUTIL_AppendCfgAttrEntry(&gDIMCfg.manualAuthAttrListPtr, valueListPtr->pszValue);
                
            } else if (!strcmp(LDAP_ATTR_GET, pszName)) {
                
                if(i != 1) 
                    status = VSAA_LDAP_ERR_CFG;                    
                else
                    status = VSAAUTIL_AppendCfgAttrEntry(&gDIMCfg.getAttrListPtr, valueListPtr->pszValue);
                
            } else if (!strcmp(LDAP_ATTR_UPD, pszName)) {
                
                if(i != 1) 
                    status = VSAA_LDAP_ERR_CFG;                    
                else
                    status = VSAAUTIL_AppendCfgAttrEntry(&gDIMCfg.updAttrListPtr, valueListPtr->pszValue);
                
            } else if (!strcmp(LDAP_ATTR_REG, pszName)) {
                
                if(i != 3) 
                    status = VSAA_LDAP_ERR_CFG;                    
                else {
                    if (!VSAAUTIL_StrCaseCmp("LDAP_MOD_ADD", valueListPtr->next->next->pszValue)) 
                        i = LDAP_MOD_ADD;
                    else if (!VSAAUTIL_StrCaseCmp("LDAP_MOD_DELETE", valueListPtr->next->next->pszValue)) 
                        i = LDAP_MOD_DELETE;                        
                    else if (!VSAAUTIL_StrCaseCmp("LDAP_MOD_REPLACE", valueListPtr->next->next->pszValue))
                        i = LDAP_MOD_REPLACE;
                    else { 
                        i = -1;
                        VS_Log (VS_LOG_ERROR, __LINE__, __FILE__, NULL,   (char *) "Invalid third field for a %s rule: %s", pszName, szOrigLine);
                    }
                        
                    if(i != -1)
                        status = VSAAUTIL_AppendCfgNVTripleEntry(&gDIMCfg.regAttrListPtr, valueListPtr->pszValue, valueListPtr->next->pszValue, i);
                }                

            } else if(!strcmp(LDAP_ATTR_CERT_STATUS, pszName)) {
                
                if(i != 1)
                    status = VSAA_LDAP_ERR_CFG;                
                else
                    strcpy(gDIMCfg.certStatusAttrName, valueListPtr->pszValue);                    

            } else if(!strcmp(LDAP_VALUE_CERT_STATUS_VALID, pszName)) {
                
                if(i != 1)
                    status = VSAA_LDAP_ERR_CFG;                
                else
                    strcpy(gDIMCfg.certStatusValid, valueListPtr->pszValue);                    

            } else if(!strcmp(LDAP_VALUE_CERT_STATUS_INVALID, pszName)) {
                
                if(i != 1)
                    status = VSAA_LDAP_ERR_CFG;                
                else
                    strcpy(gDIMCfg.certStatusInvalid, valueListPtr->pszValue);                    

            } else if(!strcmp(LDAP_VALUE_CERT_STATUS_REVOKED, pszName)) {
                
                if(i != 1)
                    status = VSAA_LDAP_ERR_CFG;                
                else
                    strcpy(gDIMCfg.certStatusRevoked, valueListPtr->pszValue);                    

            } else {                
                VS_Log (VS_LOG_DEBUG, __LINE__, __FILE__, NULL,  (char *) "Ignored configuration entry for LDAP setting: %s", szOrigLine);
            }            

            if(status != VSAA_SUCCESS) {
                VS_Log (VS_LOG_ERROR, __LINE__, __FILE__, NULL,  (char *) "Incorrect number of fields for %s: %s", pszName, szOrigLine);
            }
            
            VSAAUTIL_Free(pszName);
            VSAAUTIL_FreeCfgAttrList(valueListPtr);

            pszName = NULL;
            valueListPtr = NULL;

            if(status != VSAA_SUCCESS) {
                break;
            }
        }
    }

    fclose (cfgFp);

    DIM_TRACE("Called DIM_ReadConfigFile()");

    return status;
}

/* Make sure required fields are given and valid */

VSAA_STATUS
DIM_ValidateVerLDAPConfig(DIMCfgLDAPHost* hostCfgPtr)
{
    DIM_TRACE("DIM_ValidateVerLDAPConfig()");

    if(!hostCfgPtr) /* should never happen */ 
        return VSAA_SUCCESS;

    if ( !LDAP_VERIFICATION_USED ) {
        VS_Log(VS_LOG_INFO, __LINE__, __FILE__, NULL,   (char *) "LDAP is not used for verification process.");
        return VSAA_SUCCESS;
    }

    if (!*hostCfgPtr->szHostName) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", VER_HOST);
        return (DIM_LogError(VSAA_LDAP_ERR_CFG));
    }

    if (-1 == hostCfgPtr->nPort) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", VER_PORT);
        return(DIM_LogError(VSAA_LDAP_ERR_CFG));
    }

    if (!*hostCfgPtr->szBaseDN) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", VER_BASEDN);
        return(DIM_LogError(VSAA_LDAP_ERR_CFG));
    }

    if (!*hostCfgPtr->szBindDN ||
        (!VSAAUTIL_StrCaseCmp(hostCfgPtr->szBindDN, "NULL") && !*hostCfgPtr->szReadDN)
       ) 
    {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", VER_DN);
        return(DIM_LogError(VSAA_LDAP_ERR_CFG));
    }

    if (!IS_NULL_PASSWORD_ALLOWED && !*hostCfgPtr->szBindPassword) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", VER_PWD);
        return(DIM_LogError(VSAA_LDAP_ERR_CFG));
    }    

    if(hostCfgPtr->nSSLEnabled && !*hostCfgPtr->szCertDB) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", VER_CERTDB);
        return DIM_LogError(VSAA_LDAP_ERR_CFG);
    }

    if(hostCfgPtr->nSSLEnabled && -1 == hostCfgPtr->nSSLPort) {    
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", VER_SSL_PORT);
        return DIM_LogError(VSAA_LDAP_ERR_CFG);	
    }
        
    return VSAA_SUCCESS;
}

VSAA_STATUS
DIM_ValidateRegLDAPConfig(DIMCfgLDAPHost* hostCfgPtr)
{
    DIM_TRACE("DIM_ValidateRegLDAPConfig()");

    if(!hostCfgPtr) /* should never happen */ 
        return VSAA_SUCCESS;

    if ( !LDAP_REGISTRATION_USED ) {
        VS_Log(VS_LOG_INFO, __LINE__, __FILE__, NULL,   (char *) "LDAP is not used for registration process.");
        return VSAA_SUCCESS;
    }

    if (!*hostCfgPtr->szHostName) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", REG_HOST);
        return (DIM_LogError(VSAA_LDAP_ERR_CFG));
    }

    if (-1 == hostCfgPtr->nPort) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", REG_PORT);
        return(DIM_LogError(VSAA_LDAP_ERR_CFG));
    }

    if (!*hostCfgPtr->szBaseDN) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", REG_BASEDN);
        return(DIM_LogError(VSAA_LDAP_ERR_CFG));
    }

    if (!*hostCfgPtr->szBindDN ||
        (!VSAAUTIL_StrCaseCmp(hostCfgPtr->szBindDN, "NULL") && !*hostCfgPtr->szReadDN)
       ) 
    {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", REG_DN);
        return(DIM_LogError(VSAA_LDAP_ERR_CFG));
    }

    if (!IS_NULL_PASSWORD_ALLOWED && !*hostCfgPtr->szBindPassword) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", REG_PWD);
        return(DIM_LogError(VSAA_LDAP_ERR_CFG));    
    }    

    if(hostCfgPtr->nSSLEnabled && !*hostCfgPtr->szCertDB) {    
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", REG_CERTDB);
        return DIM_LogError(VSAA_LDAP_ERR_CFG);
    }

    if(hostCfgPtr->nSSLEnabled && -1 == hostCfgPtr->nSSLPort) {    
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", REG_SSL_PORT);
        return DIM_LogError(VSAA_LDAP_ERR_CFG);	
    }

    return VSAA_SUCCESS;
}

VSAA_STATUS
DIM_ValidateVerLDAPExternalConfig(DIMCfgLDAPHost* hostCfgPtr)
{
    DIM_TRACE("DIM_ValidateVerLDAPExternalConfig()");

    if(!hostCfgPtr) /* should never happen */ 
        return VSAA_SUCCESS;

    /* the user specified at least one external parameter.  make
       sure that the required set is represented */

    if( *hostCfgPtr->szHostName   ||
        -1 != hostCfgPtr->nPort   ||
        *hostCfgPtr->szBaseDN     ||
        *hostCfgPtr->szBindDN     ||
        *hostCfgPtr->szBindPassword ||
        *hostCfgPtr->szObjClass     ||
        *hostCfgPtr->szCertDB       ||
        hostCfgPtr->nSSLEnabled) 
    {                
        if (!*hostCfgPtr->szHostName) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", VER_HOST_EXTERNAL);
            return (DIM_LogError(VSAA_LDAP_ERR_CFG));
        }
        
        if (-1 == hostCfgPtr->nPort) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", VER_PORT_EXTERNAL);
            return(DIM_LogError(VSAA_LDAP_ERR_CFG));
        }
        
        if (!*hostCfgPtr->szBaseDN) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", VER_BASEDN_EXTERNAL);
            return(DIM_LogError(VSAA_LDAP_ERR_CFG));
        }
        
        if (!*hostCfgPtr->szBindDN ||
            (!VSAAUTIL_StrCaseCmp(hostCfgPtr->szBindDN, "NULL") && !*hostCfgPtr->szReadDN)
           ) 
        {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", VER_DN_EXTERNAL);
            return(DIM_LogError(VSAA_LDAP_ERR_CFG));
        }
        
        if (!IS_NULL_PASSWORD_ALLOWED && !*hostCfgPtr->szBindPassword) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", VER_PWD_EXTERNAL);
            return(DIM_LogError(VSAA_LDAP_ERR_CFG));
        }         

        if(hostCfgPtr->nSSLEnabled && !*hostCfgPtr->szCertDB) {    
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", VER_CERTDB_EXTERNAL);
            return DIM_LogError(VSAA_LDAP_ERR_CFG);
        }

        if(hostCfgPtr->nSSLEnabled && -1 == hostCfgPtr->nSSLPort) {    
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", VER_SSL_PORT_EXTERNAL);
            return DIM_LogError(VSAA_LDAP_ERR_CFG);	
        }
    }

    return VSAA_SUCCESS;
}

VSAA_STATUS
DIM_ValidateRegLDAPExternalConfig(DIMCfgLDAPHost* hostCfgPtr)
{
    DIM_TRACE("DIM_ValidateRegLDAPExternalConfig()");

    if(!hostCfgPtr) /* should never happen */ 
        return VSAA_SUCCESS;

    /* the user specified at least one external parameter.  make
       sure that the required set is represented */

    if( *hostCfgPtr->szHostName   ||
        -1 != hostCfgPtr->nPort   ||
        *hostCfgPtr->szBaseDN     ||
        *hostCfgPtr->szBindDN     ||
        *hostCfgPtr->szBindPassword ||
        *hostCfgPtr->szObjClass     ||
        *hostCfgPtr->szCertDB       ||
        hostCfgPtr->nSSLEnabled) 
    {                
        if (!*hostCfgPtr->szHostName) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", REG_HOST_EXTERNAL);
            return (DIM_LogError(VSAA_LDAP_ERR_CFG));
        }
        
        if (-1 == hostCfgPtr->nPort) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", REG_PORT_EXTERNAL);
            return(DIM_LogError(VSAA_LDAP_ERR_CFG));
        }
        
        if (!*hostCfgPtr->szBaseDN) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", REG_BASEDN_EXTERNAL);
            return(DIM_LogError(VSAA_LDAP_ERR_CFG));
        }
        
        if (!*hostCfgPtr->szBindDN ||
            (!VSAAUTIL_StrCaseCmp(hostCfgPtr->szBindDN, "NULL") && !*hostCfgPtr->szReadDN)
           ) 
        {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", REG_DN_EXTERNAL);
            return(DIM_LogError(VSAA_LDAP_ERR_CFG));
        }
        
        if (!IS_NULL_PASSWORD_ALLOWED && !*hostCfgPtr->szBindPassword) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", REG_PWD_EXTERNAL);
            return(DIM_LogError(VSAA_LDAP_ERR_CFG));
        }        

        if(hostCfgPtr->nSSLEnabled && !*hostCfgPtr->szCertDB) {    
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", REG_CERTDB_EXTERNAL);
            return DIM_LogError(VSAA_LDAP_ERR_CFG);
        }

        if(hostCfgPtr->nSSLEnabled && -1 == hostCfgPtr->nSSLPort) {    
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Configuration file error:  %s not specified.", REG_SSL_PORT_EXTERNAL);
            return DIM_LogError(VSAA_LDAP_ERR_CFG);	
        }
    }

    return VSAA_SUCCESS;
}

void
DIM_CopyValidHostConfig(
    DIMCfgLDAPHost* targetHostCfg, 
    DIMCfgLDAPHost* srcHostCfg)
{
    DIM_TRACE("DIM_CopyValidHostConfig()");

    if(!targetHostCfg || !srcHostCfg)
        return;

    if (!*targetHostCfg->szHostName) {
        strcpy(targetHostCfg->szHostName, srcHostCfg->szHostName);
        targetHostCfg->nSSLEnabled = srcHostCfg->nSSLEnabled;
    }
    
    if (-1 == targetHostCfg->nPort) {
        targetHostCfg->nPort = srcHostCfg->nPort;
    }
    
    if (!*targetHostCfg->szBaseDN) {
        strcpy(targetHostCfg->szBaseDN, srcHostCfg->szBaseDN);
    }
    
    if (!*targetHostCfg->szObjClass) {
        strcpy(targetHostCfg->szObjClass, srcHostCfg->szObjClass);
    }
    
    if (!*targetHostCfg->szEmailAttr) {
        strcpy(targetHostCfg->szEmailAttr, srcHostCfg->szEmailAttr);
    }
    
    if (!*targetHostCfg->szBindDN) {
        strcpy(targetHostCfg->szBindDN, srcHostCfg->szBindDN);
    }
    
    if (!*targetHostCfg->szBindPassword) {
        strcpy(targetHostCfg->szBindPassword, srcHostCfg->szBindPassword);
    }
        
    if (!*targetHostCfg->szReadDN) {
        strcpy(targetHostCfg->szReadDN, srcHostCfg->szReadDN);
    }
    
    if (!*targetHostCfg->szReadPassword) {
        strcpy(targetHostCfg->szReadPassword, srcHostCfg->szReadPassword);
    }
            
    if(targetHostCfg->nSSLEnabled && !*targetHostCfg->szCertDB) {
        strcpy(targetHostCfg->szCertDB, srcHostCfg->szCertDB);
    }

    if(targetHostCfg->nSSLEnabled && -1 == targetHostCfg->nSSLPort) {    
        targetHostCfg->nSSLPort = srcHostCfg->nSSLPort;
    }
}

VSAA_STATUS
DIM_ValidateCfg(DIMCfg* pDIMCfg)
{
    VSAA_STATUS status = VSAA_SUCCESS;

    DIM_TRACE("DIM_ValidateCfg()");

    status = DIM_ValidateVerLDAPConfig(&pDIMCfg->verLDAPCfg);
    if(status != VSAA_SUCCESS)
        return DIM_LogError(status);

    status = DIM_ValidateVerLDAPExternalConfig(&pDIMCfg->verLDAPExternalCfg);
    if(status != VSAA_SUCCESS)
        return DIM_LogError(status);

    /* 
       if there is no extra ldap server for registration, 
       use the standard authentication setting. 
    */

    DIM_CopyValidHostConfig(&pDIMCfg->regLDAPCfg, &pDIMCfg->verLDAPCfg);
    DIM_CopyValidHostConfig(&pDIMCfg->regLDAPExternalCfg, &pDIMCfg->verLDAPExternalCfg);
    
    status = DIM_ValidateRegLDAPConfig(&pDIMCfg->regLDAPCfg);
    if(status != VSAA_SUCCESS)
        return DIM_LogError(status);

    status = DIM_ValidateRegLDAPExternalConfig(&pDIMCfg->regLDAPExternalCfg);
    if(status != VSAA_SUCCESS)
        return DIM_LogError(status);

    return status;
}

void
DIM_PrintHostCfg(char* msg, DIMCfgLDAPHost* hostCfg)
{
  if( VS_Log == NULL ) return;

  if(msg) 
    VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL,  (char *)"CFG %s", msg);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL,  (char *)"CFG     Host name: %s", hostCfg->szHostName);
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL,  (char *)"CFG     Port: %ld", hostCfg->nPort);
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL,  (char *)"CFG     Secure Port: %ld", hostCfg->nSSLPort);
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL,  (char *)"CFG     Binding DN: %s", hostCfg->szBindDN);
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL,  (char *)"CFG     Binding password: %s", hostCfg->szBindPassword);
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL,  (char *)"CFG     Readable binding DN: %s", hostCfg->szReadDN);
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL,  (char *)"CFG     Readable binding password: %s", hostCfg->szReadPassword);
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL,  (char *)"CFG     Base DN: %s", hostCfg->szBaseDN);
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL,  (char *)"CFG     Object class %s", hostCfg->szObjClass);
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL,  (char *)"CFG     Secure LDAP mode: %s", hostCfg->nSSLEnabled?"ON":"OFF");
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL,  (char *)"CFG     Certificate database %s", hostCfg->szCertDB);   
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL,  (char *)"CFG     LDAP Protocol Version: %d", hostCfg->nProtocolVersion);
}

void 
DIM_PrintCfg()
{
  if ( VS_Log == NULL ) return;
  if ( gHasEncryptedLine ) return;
  DIM_TRACE("DIM_PrintCfg()");
  DIM_PrintHostCfg((char *) "AUTH LDAP CONFIG: ", &gDIMCfg.verLDAPCfg);
  DIM_PrintHostCfg((char *) "REG LDAP CONFIG: ", &gDIMCfg.regLDAPCfg); 
  DIM_PrintHostCfg((char *) "RECOVER LDAP CONFIG: ", &gDIMCfg.recoverLDAPCfg);       
  
  DIM_PrintHostCfg((char *) "AUTH EXTERNAL LDAP CONFIG: ", &gDIMCfg.verLDAPExternalCfg);
  DIM_PrintHostCfg((char *) "REG EXTERNAL LDAP CONFIG: ", &gDIMCfg.regLDAPExternalCfg);         
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *) "CFG %s rules: ", LDAP_ATTR_MAP);        
  VSAALDAP_PrintCfgNVPairList(gDIMCfg.mapAttrListPtr);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *) "CFG %s rules: ", RECOVER_LDAP_ATTR_MAP);        
  VSAALDAP_PrintCfgNVPairList(gDIMCfg.recoverMapAttrListPtr);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *) "CFG %s rules: ", LDAP_ATTR_VER);
  VSAALDAP_PrintCfgAttrList(gDIMCfg.verAttrListPtr);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *) "CFG %s rules: ", LDAP_ATTR_AUTH);
  VSAALDAP_PrintCfgNVPairList(gDIMCfg.authAttrListPtr);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *) "CFG %s rules: ", LDAP_ATTR_MANUAL_AUTH);
  VSAALDAP_PrintCfgAttrList(gDIMCfg.manualAuthAttrListPtr);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *) "CFG %s rules: ", LDAP_ATTR_GET);
  VSAALDAP_PrintCfgAttrList(gDIMCfg.getAttrListPtr);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *) "CFG %s rules: ", LDAP_ATTR_SET);
  VSAALDAP_PrintCfgNVPairList(gDIMCfg.setAttrListPtr);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *) "CFG %s rules: ", LDAP_ATTR_UPD);
  VSAALDAP_PrintCfgAttrList(gDIMCfg.updAttrListPtr);
  
  VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *) "CFG %s rules: ", LDAP_ATTR_REG);
  VSAALDAP_PrintCfgNVTripleList(gDIMCfg.regAttrListPtr); 
  
  
}

/*******************************************************************
 *
 * Build a filter string based on the hard valued set list and 
 * user input.
 *
 * Parameters:
 *    szFilter       --- output search filter string
 *    userInput      --- user input of name value pairs 
 *    attrListPtr    --- LDAP X500 search attributes
 *    setAttrListPtr --- X500 attributes which has been set a value
 *    pszObjClass    --- Object class name to be searched in LDAP
 *******************************************************************/
VSAA_STATUS 
DIM_BuildLDAPSearchFilter(
    char                         **ppszFilter,
    const VSAA_NAME              userInput[],
    const VSAACfgAttrList        *searchAttrListPtr,
    const VSAACfgNVPairList      *setAttrListPtr,
    const char                   *pszObjClass)
{ 
    char          *pAttr = NULL;
    const char    *pVal=NULL;
    unsigned int  nCount = 0;
    unsigned int  filterLength = 0;
    char          *pszFilter = NULL;
    
    const VSAACfgNVPairList *tmpSetAttrListPtr = setAttrListPtr;

    DIM_TRACE("DIM_BuildLDAPSearchFilter()");    

    if(!ppszFilter) {
        return VSAA_INTERNAL_ERROR;
    }

    *ppszFilter = NULL;

    filterLength += 3; /* add an extra bytes for last character ')' */
    pszFilter = (char *)VSAAUTIL_Malloc(filterLength+1);
    if(!pszFilter) {
        return VSAA_OUT_OF_MEMORY;
    }
    
    sprintf(pszFilter, "(&");
    
    if (pszObjClass && *pszObjClass) {    
        
        filterLength += strlen(pszObjClass)+14;
        pszFilter = (char *)VSAAUTIL_Realloc(pszFilter, filterLength+1);
        if(!pszFilter) {
            return VSAA_OUT_OF_MEMORY;
        } else {
            strcat(pszFilter, "(objectclass=");
            strcat(pszFilter, pszObjClass);
            strcat(pszFilter, ")");
            nCount++;
        }
    }

    while(searchAttrListPtr != NULL && *searchAttrListPtr->pszValue) {    
        
        pVal = NULL;
        
        pAttr = (char*)DIM_GetFDFAttrName(searchAttrListPtr->pszValue);
        if(!pAttr) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "No user enrollment field is defined to be mapped to LDAP search attribute '%s'", searchAttrListPtr->pszValue);
            VSAAUTIL_Free(pszFilter);
            return VSAA_ERR_INVALID_DATA;
        }

        /* 
            find whether a value for the attribute has been hard-set,
            if so, the search value for the attribute will use the hard
            set one.
        */

        tmpSetAttrListPtr = setAttrListPtr;
        while(tmpSetAttrListPtr != NULL && tmpSetAttrListPtr->pszName && *tmpSetAttrListPtr->pszName) {
            if(!strcmp(pAttr, tmpSetAttrListPtr->pszName))
                pVal = tmpSetAttrListPtr->pszValue;

            tmpSetAttrListPtr = tmpSetAttrListPtr->next;
        }

    

        /* 
           If there is no value hard-coded for the attribute, find
           corresponding DIM_GetFDFAttrName attribute in user enrollment page from
           local hosting web server, and find its value from user input.           
        */

        if(!pVal) {

            if(!(pVal = (char*)VSAAUTIL_FindUserInputValue(pAttr, strlen(pAttr), userInput))) {
                VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "No data was found from user input for the required search attribute '%s'", pAttr);
                VSAAUTIL_Free(pszFilter);
                return VSAA_ERR_INVALID_DATA;
            }

        }

        /* Now, we are ready to set up search string */

        filterLength += strlen(searchAttrListPtr->pszValue)+strlen(pVal)+3;
        pszFilter = (char *)VSAAUTIL_Realloc(pszFilter, filterLength+1);
        if(!pszFilter) {
            return VSAA_OUT_OF_MEMORY;
        } else {
            strcat(pszFilter, "(");
            strcat(pszFilter, searchAttrListPtr->pszValue);
            strcat(pszFilter, "=");
            strcat(pszFilter, pVal);
            strcat(pszFilter, ")");        
        
            nCount++;
        }

        searchAttrListPtr = searchAttrListPtr->next;

    }

    if (!nCount) {

        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "No data is available for filtering.");
        VSAAUTIL_Free(pszFilter);
        return VSAA_ERR_INVALID_DATA;

    } else if (2 > nCount) {

        /* 
           The first two bytes "(&" of pszFilter is not proper if
           only one pair is present in the search string.
        */

        pszFilter[0] = ' ';
        pszFilter[1] = ' ';

    } else {

        /* mark the end of search filter to match "(& */

        strcat(pszFilter, ")"); 

    }

    const char* inputEncoding = VSAAUTIL_FindUserInputValue(VSAA_ENCODING_NAME, strlen(VSAA_ENCODING_NAME), userInput);
    if(gDataSourceUseUTF8 == VSAA_TRUE && inputEncoding != NULL && strlen(inputEncoding) > 0) {
        int rc = NativeToUTF8(ppszFilter, pszFilter, inputEncoding);
        if(rc != 0) {
            VS_Log (VS_LOG_WARNING, __LINE__, __FILE__, NULL,   (char *) "Conversion from native to UTF-8 encoding failed on search filter (%s) with error (%d)", pszFilter, rc);
            *ppszFilter = pszFilter;
        } else {
            free(pszFilter);
        }
    } else {
        *ppszFilter = pszFilter;
    }

    return VSAA_SUCCESS;
}

/*******************************************************************
 *
 * Build a filter string based on the hard valued set list and 
 * user input.
 *
 * Parameters:
 *    szFilter       --- output search filter string
 *    userInput      --- user input of name value pairs 
 *    attrListPtr    --- LDAP X500 search attributes
 *    setAttrListPtr --- X500 attributes which has been set a value
 *    pszObjClass    --- Object class name to be searched in LDAP
 *******************************************************************/
VSAA_STATUS 
DIM_RecoverBuildLDAPSearchFilter(
    char                         **ppszFilter,
    const VSAA_NAME              userInput[],
    char                         *searchAttrName,
    const char                   *pszObjClass)
{ 
    char          *pAttr = NULL;
    const char    *pVal=NULL;
    unsigned int  nCount = 0;
    unsigned int  filterLength = 0;
    char          *pszFilter = NULL;
    
    DIM_TRACE("DIM_BuildLDAPSearchFilter()");    

    if(!ppszFilter) {
        return VSAA_INTERNAL_ERROR;
    }

    *ppszFilter = NULL;

    filterLength += 3; /* add an extra bytes for last character ')' */
    pszFilter = (char *)VSAAUTIL_Malloc(filterLength+1);
    if(!pszFilter) {
        return VSAA_OUT_OF_MEMORY;
    }
    
    sprintf(pszFilter, "(&");
    
    if (pszObjClass && *pszObjClass) {    
        
        filterLength += strlen(pszObjClass)+14;
        pszFilter = (char *)VSAAUTIL_Realloc(pszFilter, filterLength+1);
        if(!pszFilter) {
            return VSAA_OUT_OF_MEMORY;
        } else {
            strcat(pszFilter, "(objectclass=");
            strcat(pszFilter, pszObjClass);
            strcat(pszFilter, ")");
            nCount++;
        }
    }

    pAttr = (char*)DIM_RecoverGetLdapAttrName(VSKPI_WEBPIN);
    if(!pAttr) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "not RECOVER_LDAP_ATTR_MAP for attribute '%s'", VSKPI_WEBPIN);
        VSAAUTIL_Free(pszFilter);
        return VSAA_ERR_INVALID_DATA;
    }

    if(!(pVal = (char*)VSAAUTIL_FindUserInputValue(searchAttrName, strlen(searchAttrName), userInput))) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "No data was found from user input for the required search attribute '%s'", searchAttrName);
        VSAAUTIL_Free(pszFilter);
        return VSAA_ERR_INVALID_DATA;
    }
   
    /* Now, we are ready to set up search string */

    filterLength += strlen(pAttr)+strlen(pVal)+3;
    pszFilter = (char *)VSAAUTIL_Realloc(pszFilter, filterLength+1);
    if(!pszFilter) {
        return VSAA_OUT_OF_MEMORY;
    } else {
        strcat(pszFilter, "(");
        strcat(pszFilter, pAttr);
        strcat(pszFilter, "=");
        strcat(pszFilter, pVal);
        strcat(pszFilter, ")");        
    
        nCount++;
    }

    if (!nCount) {

        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "No data is available for filtering.");
        VSAAUTIL_Free(pszFilter);
        return VSAA_ERR_INVALID_DATA;

    } else if (2 > nCount) {

        /* 
           The first two bytes "(&" of pszFilter is not proper if
           only one pair is present in the search string.
        */

        pszFilter[0] = ' ';
        pszFilter[1] = ' ';

    } else {

        /* mark the end of search filter to match "(& */

        strcat(pszFilter, ")"); 

    }

    const char* inputEncoding = VSAAUTIL_FindUserInputValue(VSAA_ENCODING_NAME, strlen(VSAA_ENCODING_NAME), userInput);
    if(gDataSourceUseUTF8 == VSAA_TRUE && inputEncoding != NULL && strlen(inputEncoding) > 0) {
        int rc = NativeToUTF8(ppszFilter, pszFilter, inputEncoding);
        if(rc != 0) {
            VS_Log (VS_LOG_WARNING, __LINE__, __FILE__, NULL,   (char *) "Conversion from native to UTF-8 encoding failed on search filter (%s) with error (%d)", pszFilter, rc);
            *ppszFilter = pszFilter;
        } else {
            free(pszFilter);
        }
    } else {
        *ppszFilter = pszFilter;
    }

    return VSAA_SUCCESS;
}


/*******************************************************************
 *
 * Find out the DIM_GetFDFAttrName attribute for a X500 attribute
 *
 *******************************************************************/

const char* 
DIM_GetFDFAttrName(const char* pszX500Attr)
{
    int i;

    VSAACfgNVPairList* userDefinedFDFAttrNameToLdapAttrMapPtr = gDIMCfg.mapAttrListPtr;

    DIM_TRACE("DIM_GetFDFAttrName()");

    if (!pszX500Attr || !*pszX500Attr) {
        return NULL;
    }

    while(userDefinedFDFAttrNameToLdapAttrMapPtr != NULL && userDefinedFDFAttrNameToLdapAttrMapPtr->pszValue) {
        if( VSAAUTIL_StrCaseCmp(userDefinedFDFAttrNameToLdapAttrMapPtr->pszValue, pszX500Attr) == 0 )
            return userDefinedFDFAttrNameToLdapAttrMapPtr->pszName;
        
        userDefinedFDFAttrNameToLdapAttrMapPtr = userDefinedFDFAttrNameToLdapAttrMapPtr->next;
    }

    for(i=0; i<gFDFToLdapAttrDefaultMapCount; i++)
    {
        if( VSAAUTIL_StrCaseCmp(gFDFToLdapAttrDefaultMap[i].pszValue, pszX500Attr) == 0 )
        return gFDFToLdapAttrDefaultMap[i].pszName;
    }

    return NULL;
}


/*******************************************************************
 *
 * Find out the DIM_RecoverGetFDFAttrName attribute for a X500 attribute
 *
 *******************************************************************/

const char* 
DIM_RecoverGetLdapAttrName(const char* pszX500Attr)
{
    int i;

    DIM_TRACE("DIM_RecoverGetLdapAttrName()");


    VSAACfgNVPairList* userDefinedAttrNameToLdapAttrMapPtr = gDIMCfg.recoverMapAttrListPtr;


    if (!pszX500Attr || !*pszX500Attr) {
        return NULL;
    }

    while(userDefinedAttrNameToLdapAttrMapPtr != NULL && userDefinedAttrNameToLdapAttrMapPtr->pszValue) {
        if( VSAAUTIL_StrCaseCmp(userDefinedAttrNameToLdapAttrMapPtr->pszName, pszX500Attr) == 0 )
            return userDefinedAttrNameToLdapAttrMapPtr->pszValue;
        
        userDefinedAttrNameToLdapAttrMapPtr = userDefinedAttrNameToLdapAttrMapPtr->next;
    }
    if (VSAAUTIL_StrnCaseCmp(gDIMCfg.recoverLDAPCfg.szObjClass, "inetOrgPerson", strlen("inetOrgPerson")) == 0) {
        for(i=0; i<gRecoverAttrMapCount; i++)
        {
            if( VSAAUTIL_StrCaseCmp(gRecoverAttrMap_INetOrgPerson[i].pszName, pszX500Attr) == 0 )
            return gRecoverAttrMap_INetOrgPerson[i].pszValue;
        }
    } else if (VSAAUTIL_StrnCaseCmp(gDIMCfg.recoverLDAPCfg.szObjClass, "user", strlen("user")) == 0) {
        for(i=0; i<gRecoverAttrMapCount; i++)
        {
            if( VSAAUTIL_StrCaseCmp(gRecoverAttrMap_User[i].pszName, pszX500Attr) == 0 )
            return gRecoverAttrMap_User[i].pszValue;
        }
    }

    return NULL;
}

VSAA_STATUS 
DIM_PopulateConfigDN(
    char                 **ppszUserDN, 
    const char           szConfigDN[], 
    const VSAA_NAME      userInput[])
{
    char *pszX500Attr = NULL, *pszNextX500Attr = NULL;
    char *pszFDFAttrNameAttr = NULL;
    char *pszVal = NULL;
    char szTemp[1024], *pszTemp = NULL;
    char *pszPrintFormatChars = NULL;
    const char *pszConfigTmp = NULL;
    const char *t_xid;
    
    char *pszUserDN = NULL;
    int  pszUserDNLen = 0;
    
    VSAA_STATUS status = VSAA_SUCCESS;

    DIM_TRACE("DIM_PopulateConfigDN()");
    t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);

    if(ppszUserDN == NULL)
        return VSAA_INTERNAL_ERROR;
    
    *ppszUserDN = NULL;    
    
    if(szConfigDN[0]) {
        /* 
          Assume that szConfigDN has either of the following syntax: 
    
              "<...>"
          or
      
              "<...%s...>"+<>
        
          The former gives hard coded DN, and the later depends on user 
          input from enrollment page.
        */
        
        if(szConfigDN[0] != CFG_BINDDN_BEGIN_CHAR) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "Syntax Error on %s line: \"%s\" doesn't begin with character '%c'", VER_DN, szConfigDN, CFG_BINDDN_BEGIN_CHAR);
            return VSAA_LDAP_ERR_CFG_BINDDN;
        }
        
        if(szConfigDN[strlen(szConfigDN)-1]==CFG_BINDDN_END_CHAR) {
            
            /* a hard coded DN */
            
            pszUserDN = VSAAUTIL_Strdup(&szConfigDN[1]);
            if(!pszUserDN) {
                status = VSAA_OUT_OF_MEMORY;
                return DIM_LogError(VSAA_OUT_OF_MEMORY);
            } else {
                pszUserDN[strlen(pszUserDN)-1]='\0';        /* filter out the trail '"' */
            }
            
        } else {
            
            /* user specified DN from enrollment page */
            
            /* 
            Find the trailing CFG_BINDDN_END_CHAR. It could not be the last character. 
            We expect the next char to be CFG_BINDDN_ATTR_DELIMITER ('+').
            
              It is a little bit simplified if the character '"' is actully
              part of binding DN. Either to enhance code to handle this
              or assume that '"' should not be content of a DN. 
            */
            
            pszX500Attr = (char *)strchr(&szConfigDN[1], CFG_BINDDN_END_CHAR);
            if(!pszX500Attr || pszX500Attr[1] != CFG_BINDDN_ATTR_DELIMITER) {
                
                VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "Syntax Error on %s line: %s", VER_DN, szConfigDN);
                return VSAA_LDAP_ERR_CFG_BINDDN;
                
            }
            
            pszX500Attr += 2;
            
            pszConfigTmp = szConfigDN + 1;
            
            do {
                
                /* 
                   do we assume that only one attribute will be input from user? 
                   No. We will handle multiple attribute input so that szConfigDN
                   allows syntax:
            
                   "<...>"+<attribute 1>+<attribute 2>+...
              
                   Thus an attribute name ends before the next character '+'.
                */
                
                pszNextX500Attr = strchr(pszX500Attr, CFG_BINDDN_ATTR_DELIMITER);
                if(pszNextX500Attr) {
                    memset(szTemp, 0, sizeof(szTemp));
                    strncpy(szTemp, pszX500Attr, pszNextX500Attr-pszX500Attr);
                    pszX500Attr = szTemp;
                    pszNextX500Attr++;
                }
                
                pszFDFAttrNameAttr = (char*)DIM_GetFDFAttrName(pszX500Attr);
                if(!pszFDFAttrNameAttr) {
                    VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "No HTML tag was was found to be mapped to X500 attribute %s", pszX500Attr);
                    if(pszUserDN) VSAAUTIL_Free(pszUserDN);
                    return VSAA_ERR_CFG_ENTRY_NOT_FOUND;
                }
                if(!(pszVal = (char*)VSAAUTIL_FindUserInputValue(pszFDFAttrNameAttr, strlen(pszFDFAttrNameAttr), userInput)))
                {
                    VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "No user input was found for attribute %s", pszFDFAttrNameAttr);
                    if(pszUserDN) VSAAUTIL_Free(pszUserDN);
                    return VSAA_ERR_INVALID_DATA;
                }
                
                if( !(pszPrintFormatChars = (char *)strstr(pszConfigTmp, "%s")) ) {
                    
                    VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "Syntax Error on %s line: %s", VER_DN, szConfigDN);
                    if(pszUserDN) VSAAUTIL_Free(pszUserDN);
                    return VSAA_LDAP_ERR_CFG_BINDDN;
                    
                }
                
                if(!pszUserDN) {
                    pszUserDN = (char *)VSAAUTIL_Calloc(strlen(pszConfigTmp)+strlen(pszVal)+1, 1);
                } else {
                    pszUserDN = (char *)VSAAUTIL_Realloc(pszUserDN, strlen(pszUserDN)+strlen(pszConfigTmp)+strlen(pszVal)+1);
                }

                if(!pszUserDN) {
                    return DIM_LogError(VSAA_OUT_OF_MEMORY);            
                }

                pszUserDNLen = strlen(pszUserDN);
                strcat(pszUserDN, pszConfigTmp);
                pszUserDN[pszUserDNLen+(int)(pszPrintFormatChars-pszConfigTmp)] = 0;
                strcat(pszUserDN, pszVal);
                
                pszConfigTmp = pszPrintFormatChars + 2;
                if(!pszNextX500Attr) {
                    strcat(pszUserDN, pszConfigTmp);
                    break;
                } else {
                    pszX500Attr = pszNextX500Attr;
                    pszNextX500Attr = NULL;
                }
            } while (!pszX500Attr);
            
            
            /* filter out the trail '"+' */
            
            pszTemp = strchr(pszUserDN, '"');
            if (pszTemp) {
                
                *pszTemp = '\0';
                
            } else {
                
                VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "Syntax Error on %s line: %s", VER_DN, szConfigDN);
                VSAAUTIL_Free(pszUserDN);
                return VSAA_LDAP_ERR_CFG_BINDDN;
                
            }
        }
    }

    *ppszUserDN = pszUserDN;

    VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, t_xid,   (char *) "DN was populated to be: %s", pszUserDN);

    return VSAA_SUCCESS;
}

/* Handle password attribute */

VSAA_STATUS 
DIM_PopulateConfigPassword(
    char                 **ppszUserPWD, 
    const char           szConfigPWD[], 
    const VSAA_NAME      userInput[])
{
    char *pszX500Attr = NULL, *pszNextX500Attr = NULL;
    char *pszFDFAttrNameAttr = NULL;
    char *pszVal = NULL;
    char *pszUserPWD = NULL;
    const char *t_xid;

    DIM_TRACE("DIM_PopulateConfigPassword()");
    t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);

    if(ppszUserPWD == NULL)
        return VSAA_INTERNAL_ERROR;
    
    *ppszUserPWD = NULL;    
    
    if(!szConfigPWD[0]) {
        return VSAA_SUCCESS;
    }

    if(szConfigPWD[strlen(szConfigPWD)-1] == CFG_BINDDN_END_CHAR) {
        
        /* a hard coded PWD */

        pszUserPWD = VSAAUTIL_Strdup(&szConfigPWD[1]);
        if(!pszUserPWD) {
            return DIM_LogError(VSAA_OUT_OF_MEMORY);
        } else {
            pszUserPWD[strlen(pszUserPWD)-1]='\0';        /* filter out the trail '"' */
        }                

    } else {
        
        /* a soft coded PWD */

        pszFDFAttrNameAttr = (char*)DIM_GetFDFAttrName(szConfigPWD);
        if(!pszFDFAttrNameAttr) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "No HTML tag was was found to be mapped to X500 attribute %s", szConfigPWD);
            return VSAA_ERR_CFG_ENTRY_NOT_FOUND;
        }
        if(!(pszVal = (char*)VSAAUTIL_FindUserInputValue(pszFDFAttrNameAttr, strlen(pszFDFAttrNameAttr), userInput)))
        {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "No user input was found for attribute %s", pszFDFAttrNameAttr);
            return VSAA_ERR_INVALID_DATA;            
        }

        pszUserPWD = VSAAUTIL_Strdup(pszVal);
        if(!pszUserPWD) {
            return DIM_LogError(VSAA_OUT_OF_MEMORY);
        }
                
    }

    *ppszUserPWD = pszUserPWD;
    
    return VSAA_SUCCESS;
}

/*******************************************************************
 *
 * Build a DN and Password Pair using the configuration information
 *
 *******************************************************************/

VSAA_STATUS 
DIM_BuildBindDNPassword(
    char                 **ppszUserDN, 
    char                 **ppszUserPWD,
    const VSAA_NAME      userInput[], 
    const DIMCfgLDAPHost *pLdapHostCfg, 
    const char           *pszFilter)    
{         
    VSAA_STATUS status = VSAA_SUCCESS;
    LDAP        *pLdapID=NULL;
    LDAPMessage	*pResult=NULL, *pEntry=NULL;
    char        *dn = NULL;
    char        *pszUserPWD = NULL;
    char        *pszUserDN = NULL;
    const char *t_xid;

    DIM_TRACE("DIM_BuildBindDNPassword()");
    t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);

    if(ppszUserDN == NULL || ppszUserPWD == NULL || pLdapHostCfg == NULL)
        return VSAA_INTERNAL_ERROR;
    
    *ppszUserDN = NULL;
    *ppszUserPWD = NULL;
    
    status = DIM_PopulateConfigPassword(
        &pszUserPWD,
        pLdapHostCfg->szBindPassword,            
        userInput);
    
    if(status != VSAA_SUCCESS ) {
        return DIM_LogError(status);
    }

    if(!VSAAUTIL_StrCaseCmp(pLdapHostCfg->szBindDN, "NULL")) { 
        
        /* Need to use pLdapHostCfg->szReadDN to find ppszUserDN */
        
        char *pszReadDN = NULL;
        char *pszReadPWD = NULL;
        
        status = DIM_PopulateConfigDN(
            &pszReadDN, 
            pLdapHostCfg->szReadDN, 
            userInput);

        if(status != VSAA_SUCCESS ) {
            VSAAUTIL_Free(pszUserPWD);
            return DIM_LogError(status);
        }

        status = DIM_PopulateConfigPassword(
            &pszReadPWD,
            pLdapHostCfg->szReadPassword,            
            userInput);

        if(status != VSAA_SUCCESS ) {
            VSAAUTIL_Free(pszUserPWD);
            VSAAUTIL_Free(pszReadDN);
            return DIM_LogError(status);
        }

        status = DIM_QueryLDAPServer(
            &pLdapID,
            &pResult,
            &pEntry,
            pLdapHostCfg->szHostName,
            pLdapHostCfg->nSSLEnabled?pLdapHostCfg->nSSLPort:pLdapHostCfg->nPort, 
            pLdapHostCfg->nSSLEnabled,
            pLdapHostCfg->szCertDB,
            pLdapHostCfg->szBaseDN,
            pszReadDN, 
            pszReadPWD,
            pszFilter,
            pLdapHostCfg->nProtocolVersion);
        
        VSAAUTIL_Free(pszReadDN);
        VSAAUTIL_Free(pszReadPWD);

        if(status != VSAA_SUCCESS ) {
          if ( pLdapID )
            ldap_unbind(pLdapID);
          pLdapID = 0;
          VSAAUTIL_Free(pszUserPWD);
          return DIM_LogError(status);
        }
        
        if((dn = ldap_get_dn(pLdapID, pEntry)) == NULL ) {
            ldap_msgfree (pResult);
            ldap_unbind (pLdapID);
            VSAAUTIL_Free(pszUserPWD);
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "Could not find the user binding DN.");
            return DIM_LogError(VSAA_ERR_CFG_ENTRY_NOT_FOUND);
		}

        pszUserDN = VSAAUTIL_Strdup(dn);
        if(pszUserDN == NULL) {
            VSAAUTIL_Free(pszUserPWD);
            status = VSAA_OUT_OF_MEMORY;
            return DIM_LogError(VSAA_OUT_OF_MEMORY);            
        }

        ldap_memfree(dn);
        ldap_msgfree(pResult);
        ldap_unbind(pLdapID);        

    } else {

        status = DIM_PopulateConfigDN(
            &pszUserDN, 
            pLdapHostCfg->szBindDN,
            userInput);        

        if(status != VSAA_SUCCESS ) {
            VSAAUTIL_Free(pszUserPWD);
            return DIM_LogError(status);
        }

    }

    VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, t_xid,   (char *) "Binding DN was found to be: %s", pszUserDN?pszUserDN:"NULL");
    
    *ppszUserDN = pszUserDN;
    *ppszUserPWD = pszUserPWD;

    return status;
}

/*** rebindproc
 ***
 *** DESCRIPTION
 ***   LDAP callback function this function is called during ldap referal chasing for authentication.
 ***
 *** REVISION HISTORY
 *** Date            Author      Desc
 *** ----            ------      ----
 *** Jul, 13, 07     Chenna      Added Callback function for authentication when ldap_search_s does referral chasing (artf27577)
 ***/
 
int LDAP_CALL LDAP_CALLBACK rebindproc( LDAP *ld, char **whop, char **credp,int *methodp, int freeit, void *crd)
  {
  
	DIMCredPtr lusrcred ;
	lusrcred = (DIMCred *) crd;
	 switch(freeit) {
  	case 1:
  	
  	    break;
        
  	case 0:
  	
  	*whop = (*lusrcred).userDN; 
  	 *credp = (*lusrcred).passwd; 
  	*methodp = LDAP_AUTH_SIMPLE;
	break;
  	
  	}
  	
     return LDAP_SUCCESS;
  }

/*** DIM_QueryLDAPServer
 ***
 *** DESCRIPTION
 ***     build a connection to ldap server and search for a target entry
 ***
 *** ARGUMENTS 
 ***    LDAP           **ppLd         - IN - pointer to LDAP directory
 ***    LDAPMessage    **ppResult     - IN - message from LDAP call
 ***    LDAPMessage    **ppEntry      - IN - LDAP entry
 ***    const char     *pszHost       - IN - LDAP hostname
 ***    unsigned int   nPort          - IN - LDAP Port
 ***    VSAA_BOOL      nSSLEnabled    - IN - SSL enabled or not
 ***    const char     *pszCertDB     - IN - cert DB name
 ***    const char     *pszBaseD      - IN - base DN
 ***    const char     *pszUserDN     - IN - user DN
 ***    const char     *pszUserPWD    - IN - user password
 ***    const char     *pszFilter     - IN - filter
 ***    unsigned int   nProtocolVersion - IN - LDAP protocol version
 ***                               
 ***
 *** RETURNS 
 ***   VSAA_STATUS - return status (from vsverify.h)
 ***
 *** POSSIBLE ERROR CODES RETURNED:
 ***  all possible error codes from vsverify.h
 ***
 *** REVISION HISTORY
 ***   Date          Author     Desc
 ***   ----          ------     ----
 ***   ?             Ming      Created.
 ***   Jan 5, 20001  Tom       if ldap_simple_bind_s call() fail, 
 ***                           check whether is caused by incorrect username, password
 ***                           or the connection to ldap server is lost, and return different
 ***                           error code
 ***/

VSAA_STATUS 
DIM_QueryLDAPServer(
    LDAP           **ppLd,
    LDAPMessage    **ppResult,
    LDAPMessage    **ppEntry,
    const char     *pszHost, 
    unsigned int   nPort, 
    VSAA_BOOL      nSSLEnabled,
    const char     *pszCertDB,
    const char     *pszBaseDN,
    const char     *pszUserDN, 
    const char     *pszUserPWD,
    const char     *pszFilter,
    unsigned int   nProtocolVersion)
{
    int  rc;
    char *pszAttrs[2];
    char szTemp[1024];
    DIMCred pszUserCrd;

    DIM_TRACE("DIM_QueryLDAPServer()");

    /* create an LDAP session */

    if(nSSLEnabled == VSAA_TRUE)
    {        
        sprintf(szTemp, "Calling ldapssl_client_init(%s, NULL)...", pszCertDB);    
        DIM_TRACE(szTemp);

        if( ldapssl_client_init(pszCertDB, NULL) < 0 )
        {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Could not initialize netscape client certificate database %s", pszCertDB); 
            return VSAA_LDAP_ERR_INIT;
        }
    
        sprintf(szTemp, "Calling ldapssl_init(%s, %ld, 1)...", pszHost, nPort);    
        DIM_TRACE(szTemp);

        *ppLd = ldapssl_init(pszHost, nPort, 1);
    
    } else {

        *ppLd = ldap_init(pszHost, nPort); 
        
    }

    if( !*ppLd )
    {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Could not initiate ldap session with %s", pszHost);
        return VSAA_LDAP_ERR_INIT;
    }

 	/* set ldap version to 3 */

 	sprintf(szTemp, "Attempting to set protocol version to %d", nProtocolVersion);
       DIM_TRACE(szTemp);

 	rc = ldap_set_option(*ppLd, LDAP_OPT_PROTOCOL_VERSION, &nProtocolVersion);
 	if (LDAP_SUCCESS != rc) {
 		sprintf(szTemp, "Call to set protocol version failed:  %s", ldap_err2string(rc));
 		DIM_TRACE(szTemp);
 	}

    /* Set the rebind callback function */

    pszUserCrd.userDN = (char *) pszUserDN;
    pszUserCrd.passwd = (char *) pszUserPWD;
    ldap_set_rebind_proc( *ppLd, rebindproc, (void *) &pszUserCrd);

    sprintf(szTemp, "Connected to LDAP server: %s:%ld", pszHost, nPort);
    DIM_TRACE(szTemp);

    /* authenticate  with the user binding information */

    if( LDAP_SUCCESS != (rc = ldap_simple_bind_s(*ppLd, pszUserDN, pszUserPWD)) ) {
		VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "LDAP error (id=%ld): %s, while attempting to bind to server %s with DN: %s", rc, ldap_err2string(rc), pszHost, pszUserDN ? pszUserDN : "NULL");

	    if (rc == LDAP_PARAM_ERROR) 
		    return DIM_LogError(VSAA_LDAP_ERR_AUTHENTICATE_FAILED);
	    else if (rc == LDAP_SERVER_DOWN) 
		    return DIM_LogError(VSAA_LDAP_ERR_CONNECT_FAILED);
        else 
		    return DIM_LogError(VSAA_LDAP_ERR_BIND);
    }

    sprintf(szTemp, "Bound to LDAP server with DN: %s", pszUserDN);
    DIM_TRACE(szTemp);

    /* 
        We don't really need any attributes returned by ldap_search_s,
        but sending a NULL attribute list returns _all_ attributes
    */

    pszAttrs[0] = NULL;
    pszAttrs[1] = NULL;

    /* perform search - retrieve no values */

    if (pszFilter) {
        rc = ldap_search_s(*ppLd, pszBaseDN, LDAP_SCOPE_SUBTREE, pszFilter, pszAttrs, 0, ppResult);
    } else {
        rc = ldap_search_s(*ppLd, pszUserDN, LDAP_SCOPE_BASE,    NULL,      pszAttrs, 0, ppResult);
    }

    if( rc != LDAP_SUCCESS ) {

        /* search error */

        ldap_msgfree(*ppResult);
        ldap_unbind(*ppLd);

        *ppLd = 0;
        *ppResult = NULL;

        if (pszFilter) {
            sprintf(szTemp, "Received error (id=%ld): %s, while attempting a subtree search of server %s with:\n"
                            "base DN %s and filter %s", rc, ldap_err2string(rc), pszHost, pszBaseDN, pszFilter);
        } else {
            sprintf(szTemp, "Received error (id=%ld): %s, while attempting a base search of server %s with:\n"
                            "user DN %s", rc, ldap_err2string(rc), pszHost, pszUserDN);
        }
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) szTemp);
        
        return VSAA_LDAP_ERR_SEARCH;

    }

    sprintf(szTemp, "ldap_search_s(%s, %s) succeeded", pszBaseDN, pszFilter);
    DIM_TRACE(szTemp);

    /* check number of entries found, expect only one entry */

    if ((rc = ldap_count_entries(*ppLd, *ppResult)) != 1)
    {
      /* search found either no data or more than one entry */
      if (rc == 0) { 
        // not freeing result and ppLD due to the KMS operations depends on 
        // return code VSAA_ERR_CFG_ENTRY_NOT_FOUND
        // If not KMS operation, ppld and result will be free in the caller.
        if ( *ppResult )
          ldap_msgfree(*ppResult);
        *ppResult = NULL;
        return VSAA_ERR_CFG_ENTRY_NOT_FOUND;
      }  else {
        ldap_msgfree(*ppResult);
        ldap_unbind(*ppLd);
        
        *ppLd = 0;
        *ppResult = NULL;
        
        return VSAA_ERR_CFG_DUPL_ENTRIES;
      }
    }

    DIM_TRACE("Exactly one entry was found from the LDAP server!");

    /* make sure the first entry is not NULL */

    if( (*ppEntry = ldap_first_entry(*ppLd, *ppResult ))== NULL )
    {
        ldap_msgfree(*ppResult);
        ldap_unbind(*ppLd);

        *ppLd = 0;
        *ppResult = NULL;

        return VSAA_ERR_CFG_ENTRY_NOT_FOUND;
    }

    DIM_TRACE("The entry found was valid.");

    return VSAA_SUCCESS;
}

/*******************************************************************
 * Update ldap entry with the value from user input for those
 * attributes specifed in updAttrListPtr. The major usage is 
 * to update certificates.
 *******************************************************************/

VSAA_STATUS
DIM_UpdateLDAPServerEntry(
    const LDAP            *pLdapID,
    const char            *pszDN,
    const VSAACfgAttrList *updAttrListPtr,
    const VSAA_NAME       userInput[])
{
    int           rc;   
    const char    *pszAttr;
    const char    *pszValue;
    const char    *t_xid;
    unsigned int  idxOut;
    int           idxIn; 
    char          *x500UIdValue = NULL;
    int           x500UIdlen = 0;
 
    LDAPMod       mod;
    LDAPMod       *mods[2];
    
    ITEM          updateValue;
    struct berval updateBerval;
    struct berval *updateBervals[2];
    char	      *updateVals[2];
        
    ITEM          certBinary;

    DIM_TRACE("DIM_UpdateLDAPServerEntry()");
    t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);

    /* 
       Determine the original operation. For pickup and renewal, only certificate and
       certificate serial number (cert_serial) is available from user input.
    */

    const char* origOpStr = VSAAUTIL_FindUserInputValue(VSAA_ORIG_OP, strlen(VSAA_ORIG_OP), userInput);
    VSAA_BOOL   isRenewalOperation = VSAA_FALSE;
    VSAA_BOOL   isPickupOperation = VSAA_FALSE;
    
    if(!origOpStr) {
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "Could not find original_operation from user input.");
        return VSAA_INTERNAL_ERROR;
    } else {    
        if(!strcmp(origOpStr, VSAA_AA_PICKUP) || !strcmp(origOpStr, "PickupPKCS12")) {
            isPickupOperation = VSAA_TRUE;        
        } else if(!strcmp(origOpStr, VSAA_AA_RENEWAL)) {        
            isRenewalOperation = VSAA_TRUE;        
        } 
    }

    while(updAttrListPtr != NULL && *updAttrListPtr->pszValue) 
    {
        certBinary.len = 0;

        pszAttr = (char*)DIM_GetFDFAttrName(updAttrListPtr->pszValue);
        if(!pszAttr) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "Could not find a DIM_GetFDFAttrName mapping for %s", updAttrListPtr->pszValue);
            return DIM_LogError(VSAA_ERR_INVALID_DATA);
        }

        /* 
            We don't limit the update fields to be certificates only.
            If a field is certificate, we need to treat it as
            binary or base64 accordingly.
        */
        
        /* build userCertificate modification structure */

        pszValue = VSAAUTIL_FindUserInputValue(pszAttr, strlen(pszAttr), userInput);
        
        if (pszValue) {
            
            mod.mod_op = LDAP_MOD_REPLACE | LDAP_MOD_ADD; 
            mod.mod_type = (char *)updAttrListPtr->pszValue;

            if(
                 !VSAAUTIL_StrCaseCmp(updAttrListPtr->pszValue, CFG_UPD_CERT_BIN_ATTR) ||
                 !VSAAUTIL_StrCaseCmp(updAttrListPtr->pszValue, CFG_UPD_SMIME_CERT_BIN_ATTR)
              ) 
            {
                
                mod.mod_op |= LDAP_MOD_BVALUES;

                updateValue.len = strlen(pszValue);
                updateValue.data = (unsigned char*)pszValue;
                            
                /* only binary certificate requires conversion from Base64 to BER */

                if(UnBase64Alloc(&certBinary, updateValue)) {
                    return VSAA_ERR_BASE64;
                }

                updateBerval.bv_len = (unsigned long)certBinary.len;
                updateBerval.bv_val = (char*)certBinary.data;

                updateBervals[0] = &updateBerval;
                updateBervals[1] = NULL;
                
                mod.mod_bvalues = updateBervals;
                
            } else if (!VSAAUTIL_StrCaseCmp(updAttrListPtr->pszValue, CFG_UPD_CERT_SERIAL_ATTR)) {
                
                /* Update data as a NULL-terminated array of string values for the attribute */

                /* x500UniqueIdentifier has bit string syntax. pszValue contains cert serial
                   number as string. SunOne directory and MS AD accepts string values but 
                   openldap cribs about it. So convert the cert serial number in string to
                   bit string. Bit string has to be presented in '10110101'B format.
                */

                /* One char will take 8 char in bit string. 3 extra char for opening and closing
                   single colon and ending B for bit string format. */
                
                x500UIdlen = strlen(pszValue)*8 + 3;

                x500UIdValue = (char *)malloc(x500UIdlen);

                x500UIdValue[0] = '\'';

                for(idxOut=0; idxOut<strlen(pszValue); idxOut++)
                {
                    char sChar = pszValue[idxOut];
                    for(idxIn=8;idxIn>0;idxIn--) 
                    {
                        x500UIdValue[(idxOut*8)+idxIn] = '0' + (0x01 & sChar);
                        sChar >>= 1;
                    }
                }

                x500UIdValue[x500UIdlen-2] = '\''; 
                x500UIdValue[x500UIdlen-1] = 'B'; 

                mod.mod_op |= LDAP_MOD_BVALUES;

                updateBerval.bv_len = (unsigned long)x500UIdlen;
                updateBerval.bv_val = (char*)x500UIdValue;

                updateBervals[0] = &updateBerval;
                updateBervals[1] = NULL;
                
                mod.mod_bvalues = updateBervals;

            } else {
                updateVals[0] = (char*) pszValue;
                updateVals[1] = NULL;

                mod.mod_values = updateVals;
            }

            mods[0] = &mod;

        } else {

            if( 
                (isRenewalOperation == VSAA_TRUE || isPickupOperation == VSAA_TRUE) &&
                strcmp(pszAttr, VSAA_CERT_BASE64) && 
                strcmp(pszAttr, VSAA_CERT_SERIAL)
              )
            {
                updAttrListPtr = updAttrListPtr->next;
                continue;
            } else {
                VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "Could not find n-v match for attribute: %s", pszAttr);
                return DIM_LogError(VSAA_ERR_INVALID_DATA);
            }

        }

        mods[1] = NULL;

        /* make the change */

        VS_Log (VS_LOG_INFO, __LINE__, __FILE__, t_xid,  (char *) "About to update DN: %s", pszDN);

        rc = ldap_modify_s((LDAP*)pLdapID, pszDN, mods);

        /* free allocated memory */

        if(certBinary.len && certBinary.data) {
            free(certBinary.data);
            certBinary.len = 0;
            certBinary.data = NULL;
        }

        if(x500UIdValue != NULL)
        {
            free(x500UIdValue);
            x500UIdValue = NULL;
        }

        if(rc != LDAP_SUCCESS) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "Upload certificate in field %s failed. LDAP error (id=%ld): %s", updAttrListPtr->pszValue, rc, ldap_err2string(rc));
            return DIM_LogError(VSAA_UPDATE_FAILED);
        }

        updAttrListPtr = updAttrListPtr->next;
    }

    return VSAA_SUCCESS;
}

/*******************************************************************
 * Register ldap entry with the value from user input for those
 * attributes specifed in updAttrListPtr. The major usage is 
 * to update certificates.
 *******************************************************************/

VSAA_STATUS
DIM_RegLDAPServerEntry(
    const LDAP                *pLdapID,
    const char                *pszDN,
    const VSAACfgNVTripleList *regAttrListPtr,
    const VSAA_NAME           userInput[])
{
    int      rc;
    char     *regValue[2];
    LDAPMod  mod;
    LDAPMod  *mods[2];
    const char *t_xid;

    DIM_TRACE("DIM_RegLDAPServerEntry()");
    t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);

    while(regAttrListPtr != NULL && *regAttrListPtr->pszName) 
    {
        regValue[0] = (char *)regAttrListPtr->pszValue; 
        regValue[1] = NULL;

        mod.mod_op = regAttrListPtr->nValue;
        mod.mod_type = (char *)regAttrListPtr->pszName;
        mod.mod_values = regValue;
        //Begin Changes:NSN SPO PKI issue
        if (regAttrListPtr->nValue == LDAP_MOD_DELETE){
          regValue[0] = NULL; 
          regValue[1] = NULL;
          mod.mod_values = regValue;	
        }
        //End Changes:NSN SPO PKI issue
        mods[0] = &mod;
        mods[1] = NULL;

        /* make the change */

        VS_Log (VS_LOG_INFO, __LINE__, __FILE__, t_xid,  (char *) "About to update DN: %s", pszDN);

        rc = ldap_modify_s((LDAP *)pLdapID, pszDN, mods);	
        if(rc != LDAP_SUCCESS) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "Unable to update attribute %s.LDAP error (id=%ld): %s", regAttrListPtr->pszName, rc, ldap_err2string(rc));
            return DIM_LogError(VSAA_UPDATE_FAILED);
        }

        regAttrListPtr = regAttrListPtr->next;
    }

    return VSAA_SUCCESS;
}

/*******************************************************************
 * Register ldap entry with given attribute and its value.
 *******************************************************************/

VSAA_STATUS
DIM_UpdateOneLDAPServerEntry(
    const LDAP                *pLdapID,
    const char                *pszDN,
    const char                *attr,
    const char                *value)    
{
    int      rc;
    char     *regValue[2];
    LDAPMod  mod;
    LDAPMod  *mods[2];

    DIM_TRACE("DIM_UpdateOneLDAPServerEntry()");

    if(attr != NULL && *attr != 0 && value != NULL) 
    {
        regValue[0] = (char *)value; 
        regValue[1] = NULL;

        mod.mod_op = LDAP_MOD_REPLACE | LDAP_MOD_ADD;
        mod.mod_type = (char *)attr;
        mod.mod_values = regValue;

        mods[0] = &mod;
        mods[1] = NULL;

        /* make the change */

        VS_Log (VS_LOG_INFO, __LINE__, __FILE__, NULL,  (char *) "About to update DN: %s", pszDN);

        rc = ldap_modify_s((LDAP *)pLdapID, pszDN, mods);	
        if(rc != LDAP_SUCCESS) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Unable to update attribute %s.LDAP error (id=%ld): %s", attr, rc, ldap_err2string(rc));
            return DIM_LogError(VSAA_UPDATE_FAILED);
        }        
    }

    return VSAA_SUCCESS;
}

/*******************************************************************
 * Register revoke operation. delete a given attribute from a given 
 * ldap entry 
 *******************************************************************/

VSAA_STATUS
DIM_DeleteOneLDAPServerAttr(
    const LDAP                *pLdapID,
    const char                *pszDN,
    const char                *attr)    
{
    int      rc;
    LDAPMod  mod;
    LDAPMod  *mods[2];

    DIM_TRACE("DIM_DeleteOneLDAPServerAttr()");

    if(attr != NULL && *attr != 0 ) 
    {
        mod.mod_op = LDAP_MOD_DELETE;
        mod.mod_type = (char *)attr;
        mod.mod_values = NULL;

        mods[0] = &mod;
        mods[1] = NULL;

        /* make the change */

        VS_Log (VS_LOG_INFO, __LINE__, __FILE__, NULL,  (char *) "About to detele attribute %s from DN: %s", attr, pszDN);

        rc = ldap_modify_s((LDAP *)pLdapID, pszDN, mods);	
        if(rc != LDAP_SUCCESS) {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Unable to delete attribute %s.LDAP error (id=%ld): %s", attr, rc, ldap_err2string(rc));
            return DIM_LogError(VSAA_UPDATE_FAILED);
        }        
    }

    return VSAA_SUCCESS;
}

/* 
 * This function collects user input data or hard set data
 * for certain fields specified in configuration file.
 * The data is stored into an array of VSAA_NAME structure
 * augmentedData. The last element of augmentedData will be
 * always NULL data for caller to determined the size of
 * the allocated array.
 *
 * With regard to non-ASCII character support, we assume that
 * the values of setAttrListPtr are encoded with UNICODE. In 
 * other words, if AutoAdmin configuration contains non-ASCII,
 * then it must be UNICODE. The encoding of values of attributes
 * getAttrListPtr depends on the data source encoding 
 * configuration parameter DATA_SOURCE_USE_UTF8. 
 */

VSAA_STATUS
DIM_AugmentUserDataWithLDAPEntry(
    VSAA_NAME                 **augmentedData,
    const VSAA_NAME           userInput[],
    const char                *pszAuthValue,
    LDAP                      *pLdapID,
    LDAPMessage               *pEntry,
    const VSAACfgNVPairList   *setAttrListPtr,
    const VSAACfgAttrList     *getAttrListPtr)
{
    char*        pszAttr = NULL, *pszValue = NULL;
    BerElement   *ber=NULL;
    char         **ppszVals = NULL, *pszAttribute = NULL;
    const char   *t_xid;
    
    VSAA_NAME*   augment;
    unsigned int augmentCapacity = 20;
    unsigned int augmentCapacityIncrement = 10;
    unsigned int augmentCnt = 0, i;

    const VSAACfgAttrList     *getAttrListHeadPtr = getAttrListPtr;

    DIM_TRACE("DIM_AugmentUserDataWithLDAPEntry()");
    t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);

    if(!augmentedData) {
        return DIM_LogError(VSAA_INTERNAL_ERROR);
    } 

    const char* inputEncoding = VSAAUTIL_FindUserInputValue(VSAA_ENCODING_NAME, strlen(VSAA_ENCODING_NAME), userInput);

    augment = (VSAA_NAME *)VSAAUTIL_Malloc(augmentCapacity*sizeof(VSAA_NAME));
    if(!augment) {
        return DIM_LogError(VSAA_OUT_OF_MEMORY);
    } else {
        memset(augment, 0, augmentCapacity*sizeof(VSAA_NAME));
        augment[0].pszName  = VSAAUTIL_Strdup(VSAA_AUTHENTICATE);
        augment[0].pszValue = VSAAUTIL_Strdup(pszAuthValue);

        if(!augment[0].pszName || !augment[0].pszValue) {
            if(augment[0].pszName) VSAAUTIL_Free(augment[0].pszName);
            VSAAUTIL_Free(augment);
            return DIM_LogError(VSAA_OUT_OF_MEMORY);
        }

        augmentCnt++;
    }

    /* 
        Don't forget to make sure that the augment list 
        isn't overwritten.
        
        Now, populate argment list from hard coded set in configuration file.
    */
        
    while(setAttrListPtr && *setAttrListPtr->pszName) 
    {
        if (augmentCnt >= augmentCapacity - 1) { /* last element of augmentedData must be NULL */
            augment = (VSAA_NAME *)VSAAUTIL_Realloc(augment, (augmentCapacityIncrement+augmentCapacity)*sizeof(VSAA_NAME));
            if(!augment) {
                return DIM_LogError(VSAA_OUT_OF_MEMORY);
            } else {
                memset(augment+augmentCapacity*sizeof(VSAA_NAME), 0, augmentCapacityIncrement*sizeof(VSAA_NAME));
                augmentCapacity += augmentCapacityIncrement;            
            }
        }

        /* set attributes are HTML tags, their values are from configuration file which
           are UNICODE */

        augment[augmentCnt].pszName = VSAAUTIL_Strdup(setAttrListPtr->pszName);

        if(gDataSourceUseUTF8 == VSAA_TRUE && inputEncoding != NULL && strlen(inputEncoding) > 0) {
            pszValue = NULL;
            int rc = UTF8ToNative(&pszValue, setAttrListPtr->pszValue, inputEncoding);
            if(rc != 0) {
                // ignore conversion error which may be un-supported code pages
                VS_Log (VS_LOG_WARNING, __LINE__, __FILE__, t_xid,   (char *) "Conversion from UTF8 to native encoding failed for augment attribute (%s) with error (%d)", setAttrListPtr->pszName, rc);
                augment[augmentCnt].pszValue = VSAAUTIL_Strdup(setAttrListPtr->pszValue);
            } else {
                augment[augmentCnt].pszValue = pszValue;
            }
        } else {
            augment[augmentCnt].pszValue = VSAAUTIL_Strdup(setAttrListPtr->pszValue);
        }
        
        if(!augment[augmentCnt].pszName || !augment[augmentCnt].pszValue) {
            for(i=0; i<=augmentCnt; i++) {
                if(augment[i].pszName) VSAAUTIL_Free(augment[i].pszName);
                if(augment[i].pszValue) VSAAUTIL_Free(augment[i].pszValue);
            }
            VSAAUTIL_Free(augment);            
            return DIM_LogError(VSAA_OUT_OF_MEMORY);
        }

        augmentCnt++;
        setAttrListPtr = setAttrListPtr->next;
    }

    /* populate argument list from directory entry via get list */ 

    if (getAttrListPtr && getAttrListPtr->pszValue) {
        for (
              pszAttribute = ldap_first_attribute(pLdapID, pEntry, &ber);
              pszAttribute; 
              pszAttribute = ldap_next_attribute(pLdapID, pEntry, ber)
            ) 
        {
            getAttrListPtr = getAttrListHeadPtr;
            while(getAttrListPtr && getAttrListPtr->pszValue) {
                if(VSAAUTIL_StrCaseCmp(pszAttribute, getAttrListPtr->pszValue) == 0) {
                    if( 
                        (ppszVals = ldap_get_values((LDAP *)pLdapID, pEntry, pszAttribute)) != NULL 
                      )
                    {
                        if (*ppszVals) {
                            pszAttr = (char *) DIM_GetFDFAttrName(getAttrListPtr->pszValue);
                            if (pszAttr) {
                                if (augmentCnt >= augmentCapacity - 1) { /* last element of augmentedData must be NULL */
                                    augment = (VSAA_NAME *)VSAAUTIL_Realloc(augment, (augmentCapacityIncrement+augmentCapacity)*sizeof(VSAA_NAME));
                                    if(!augment) {
                                        return DIM_LogError(VSAA_OUT_OF_MEMORY);
                                    } else {
                                        memset(augment+augmentCapacity*sizeof(VSAA_NAME), 0, augmentCapacityIncrement*sizeof(VSAA_NAME));
                                        augmentCapacity += augmentCapacityIncrement;            
                                    }
                                }

                                /* the augmented value is converted to native if necessary */
                                augment[augmentCnt].pszName = VSAAUTIL_Strdup(pszAttr);
                                if(gDataSourceUseUTF8 == VSAA_TRUE && 
                                   inputEncoding != NULL && strlen(inputEncoding) > 0) {
                                    pszValue = NULL;
                                    int rc = UTF8ToNative(&pszValue, ppszVals[0], inputEncoding);
                                    if(rc != 0) {
                                        // ignore conversion error which may be un-supported code pages
                                        VS_Log (VS_LOG_WARNING, __LINE__, __FILE__, t_xid,   (char *) "Conversion from UTF8 to native encoding failed for augment attribute (%s) with error (%d)", pszAttr, rc);
                                        augment[augmentCnt].pszValue = VSAAUTIL_Strdup(ppszVals[0]);
                                    } else {
                                        augment[augmentCnt].pszValue = pszValue;
                                    }
                                } else {
                                    augment[augmentCnt].pszValue = VSAAUTIL_Strdup(ppszVals[0]);
                                }
                                
                                if(!augment[augmentCnt].pszName || !augment[augmentCnt].pszValue) {
                                    for(i=0; i<=augmentCnt; i++) {
                                        if(augment[i].pszName) VSAAUTIL_Free(augment[i].pszName);
                                        if(augment[i].pszValue) VSAAUTIL_Free(augment[i].pszValue);
                                    }
                                    VSAAUTIL_Free(augment);            
                                    return DIM_LogError(VSAA_OUT_OF_MEMORY);
                                }

                                augmentCnt++;
                            } else {
                                VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "No DIM_GetFDFAttrName mapping for: %s.", getAttrListPtr->pszValue);
                                for(i=0; i<augmentCnt; i++) {
                                    if(augment[i].pszName) VSAAUTIL_Free(augment[i].pszName);
                                    if(augment[i].pszValue) VSAAUTIL_Free(augment[i].pszValue);
                                }
                                VSAAUTIL_Free(augment);
                                return DIM_LogError(VSAA_ERR_INVALID_DATA);
                            }
                        }
                        
                    }
                }

                getAttrListPtr = getAttrListPtr->next;
            }
        
        }
    }
    
    if (ppszVals)
        ldap_value_free(ppszVals);

    if (pszAttribute)
        ldap_memfree(pszAttribute);

    if (ber) 
        ber_free(ber, 0);
    

    *augmentedData = augment;

    return VSAA_SUCCESS;
}

/* 
    This function verifies whether the user data of given attribute 
    matches the one given in LDAP server.
 */
   
VSAA_BOOL
DIM_VerifyUserDataWithLDAPEntry(    
    LDAP                      *pLdapID,
    LDAPMessage               *pEntry,
    const char                *pszX500Attr,
    const char                *pszUserData)
{
    VSAA_BOOL status = VSAA_FALSE;
    char      **ppszVals = NULL;

    DIM_TRACE("DIM_VerifyUserDataWithLDAPEntry()");

    if(!pszX500Attr || !pszUserData) return VSAA_FALSE;

    ppszVals = ldap_get_values((LDAP *)pLdapID, pEntry, pszX500Attr);
    if(ppszVals) {
        status = ((*ppszVals != NULL) && !strcmp(pszUserData, ppszVals[0]))?VSAA_TRUE:VSAA_FALSE;
        ldap_value_free(ppszVals);   
    } 

    return status;
}

VSAA_BOOL
DIM_IsExternalLDAPServerRequested(const VSAA_NAME userInput[])    
{
    const char* directory = VSAAUTIL_FindUserInputValue(KEY_DIRECTORY, strlen(KEY_DIRECTORY), userInput);
    
    DIM_TRACE("DIM_IsExternalLDAPServerRequested()");

    return (directory && (!VSAAUTIL_StrCaseCmp(directory, "external")));	
}

/*
   Determine which LDAP attributes will be used to identify
   the entry to populate certificate that is picked up.
*/

VSAA_STATUS
DIM_BuildPickupVerSetAttributes(
    VSAACfgAttrList   **verAttrListPtr, 
    VSAACfgNVPairList **setAttrListPtr, 
    const VSAA_NAME   userInput[])
{
    DIM_TRACE("DIM_BuildPickupVerSetAttributes()");
    
    /* 
       Use email address as the unique attribute.
       If email address is not unique across the scope of users,
       this piece of code should be customerized.
    */

    return DIM_BuildEmailVerSetAttributes(verAttrListPtr, setAttrListPtr, userInput);
}

void
DIM_FindCertLDAPAttr()
{
    DIM_TRACE("DIM_FindCertLDAPAttr()");

    if(gIsCertLDAPAttrQueried == VSAA_FALSE) {                        
        /* 
          Determine that cert_serial number is available from LDAP
          server in order to identifier the target entry with
          given value of certSerial.
        */
        
        VSAACfgAttrList *updAttrListPtr = gDIMCfg.updAttrListPtr;
        char* pszAttr = NULL;
        
        gIsCertLDAPAttrQueried = VSAA_TRUE;
        
        while(updAttrListPtr != NULL && *updAttrListPtr->pszValue) 
        {
            pszAttr = (char*)DIM_GetFDFAttrName(updAttrListPtr->pszValue);
            if(pszAttr && !strcmp(pszAttr, VSAA_CERT_BASE64)) {
                strcpy(gCertLDAPAttr, updAttrListPtr->pszValue);
                break;
            }
            updAttrListPtr = updAttrListPtr->next;
        }
    }
}

/*
   Determine which LDAP attributes will be used to identify
   the entry whose certificate is revoked.
   certSerial is the only available information from user input.
*/

VSAA_STATUS
DIM_BuildRevokeVerSetAttributes(
    VSAACfgAttrList   **verAttrListPtr, 
    VSAACfgNVPairList **setAttrListPtr, 
    const VSAA_NAME   userInput[],
    int revoke_count)
{
    VSAA_STATUS status = VSAA_SUCCESS;

    char        *x500UIdValue = NULL;
    int         x500UIdlen = 0;
    unsigned int idxOut;
    int         idxIn;
    const char  *t_xid;
 
    DIM_TRACE("DIM_BuildRevokeVerSetAttributes()");
    t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);

    if(!verAttrListPtr || !setAttrListPtr)
        return DIM_LogError(VSAA_INTERNAL_ERROR);

    *verAttrListPtr = NULL;
    *setAttrListPtr = NULL;

    if(gIsCertSerialNumberLDAPAttrQueried == VSAA_FALSE) {                        
        /* 
          Determine that cert_serial number is available from LDAP
          server in order to identifier the target entry with
          given value of certSerial.
        */
        
        VSAACfgAttrList *updAttrListPtr = gDIMCfg.updAttrListPtr;
        char* pszAttr = NULL;
        
        gIsCertSerialNumberLDAPAttrQueried = VSAA_TRUE;
        
        while(updAttrListPtr != NULL && *updAttrListPtr->pszValue) 
        {
            pszAttr = (char*)DIM_GetFDFAttrName(updAttrListPtr->pszValue);
            if(pszAttr && !strcmp(pszAttr, VSAA_CERT_SERIAL)) {
                strcpy(gCertSerialNumberLDAPAttr, updAttrListPtr->pszValue);
                break;
            }
            updAttrListPtr = updAttrListPtr->next;
        }
    }

    if(strlen(gCertSerialNumberLDAPAttr) > 0) {
        const char* pszValue = VSAAUTIL_FindUserInputValue(VSAA_SERIAL, strlen(VSAA_SERIAL), userInput);

        if (pszValue) {
            status = VSAAUTIL_AppendCfgAttrEntry(verAttrListPtr, gCertSerialNumberLDAPAttr);
            if(status == VSAA_SUCCESS) {
              if(revoke_count > 1)
                status = VSAAUTIL_AppendCfgNVPairEntry(setAttrListPtr, "cert_serial", pszValue); 
              else
              {
                x500UIdlen = strlen(pszValue)*8 + 4;

                x500UIdValue = (char *)malloc(x500UIdlen);

                x500UIdValue[0] = '\'';

                for(idxOut=0; idxOut<strlen(pszValue); idxOut++)
                {
                    char sChar = pszValue[idxOut];
                    for(idxIn=8;idxIn>0;idxIn--)
                    {
                        x500UIdValue[(idxOut*8)+idxIn] = '0' + (0x01 & sChar);
                        sChar >>= 1;
                    }
                }

                x500UIdValue[x500UIdlen-3] = '\'';     
                x500UIdValue[x500UIdlen-2] = 'B';     
                x500UIdValue[x500UIdlen-1] = '\0';     

                status = VSAAUTIL_AppendCfgNVPairEntry(setAttrListPtr, "cert_serial", x500UIdValue);
              }
                if(x500UIdValue != NULL)
                {
                    free(x500UIdValue);
                    x500UIdValue = NULL;
                }

                if(status != VSAA_SUCCESS) {
                    if(*verAttrListPtr) {
                        VSAAUTIL_FreeCfgAttrList(*verAttrListPtr);
                        *verAttrListPtr = NULL;
                    }
                    return DIM_LogError(status);
                }
                

            } else {
                return DIM_LogError(status);
            }
        } else {
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "No user input was found for attribute %s", VSAA_SERIAL);
            return VSAA_ERR_INVALID_DATA;
        }
    } else {
        /* 
           certificate serial number was not recorded, there is no way
           to locate the entry to be updated.
        */
    }
    
    return status;
}

/*
   Determine which LDAP attributes will be used to identify
   the entry to populate certificate that is renewed.
*/

VSAA_STATUS
DIM_BuildRenewalVerSetAttributes(
    VSAACfgAttrList   **verAttrListPtr, 
    VSAACfgNVPairList **setAttrListPtr, 
    const VSAA_NAME   userInput[])
{
    DIM_TRACE("DIM_BuildRenewalVerSetAttributes()");
    
    /* 
       Use email address as the unique attribute.
       If email address is not unique across the scope of users,
       this piece of code should be customerized.
    */

    return DIM_BuildEmailVerSetAttributes(verAttrListPtr, setAttrListPtr, userInput);
}

VSAA_STATUS
DIM_BuildEmailVerSetAttributes(
    VSAACfgAttrList   **verAttrListPtr, 
    VSAACfgNVPairList **setAttrListPtr, 
    const VSAA_NAME   userInput[])
{
    VSAA_STATUS status = VSAA_SUCCESS;
    char        *pszSrc;
    const char  *emailDefaultDNSearchToken = DEFAULT_DN_EMAIL_SEARCH_TOKEN;
    const char  *emailDefaultVerAttr = *gDIMCfg.verLDAPCfg.szEmailAttr?gDIMCfg.verLDAPCfg.szEmailAttr:DEFAULT_DN_EMAIL_VER_ATTR;
    const char  *pszCertDN;
    char        szEmailAddr[MAX_CFG_VALUE_LENGTH];    
    char        *pszEmailValueEnd = szEmailAddr;
    const char  *t_xid;
    
    VSAACfgNVPairList *tmpEmailSetAttrPtr = NULL;
    VSAACfgAttrList   *tmpEmailVerAttrPtr = NULL;
    
    DIM_TRACE("DIM_BuildEmailVerSetAttributes()");
    t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);

    if(!verAttrListPtr || !setAttrListPtr)
        return DIM_LogError(VSAA_INTERNAL_ERROR);

    *verAttrListPtr = NULL;
    *setAttrListPtr = NULL;

    /* First we need to get the VSAA_CERT_DN from the userInput */

    pszCertDN = VSAAUTIL_FindUserInputValue(VSAA_CERT_DN, strlen(VSAA_CERT_DN), userInput);
    if (NULL == pszCertDN) 
    {		
        /* VSAA_CERT_DN is missing, so return error */

        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "Missing %s.", VSAA_CERT_DN);
        return DIM_LogError(VSAA_ERR_INVALID_DATA);
    }

    /* 
        If we get here we have the cert_DN, so parse out the 
        email address.  We are dependent on the following DN format:    
       
            [Organization = SomeCompany <br>Organizational Unit = SomeUnit<br>Common Name = Some Name<br>Email Address = user@foo.bar.com<br>]

    */

    pszSrc = (char *)strstr(pszCertDN, emailDefaultDNSearchToken);
    if (NULL == pszSrc)
    {
        pszSrc = (char *)strstr(pszCertDN, "E=");
        if (NULL == pszSrc) { 
            /* email token is missing */
        
            VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "Search attribute [%s] or [E=] was not found in certficate DN input: %s.", emailDefaultDNSearchToken, pszCertDN);
            return DIM_LogError(VSAA_ERR_INVALID_DATA);
        } else {
            emailDefaultDNSearchToken="E=";
        } 
    }

    pszSrc += strlen(emailDefaultDNSearchToken);
        
    /* 
        Skip the leading space after the token and try to find
        its value. Scan the string for either the end of the line, 
        a '<', or white space.
    */

    while(*pszSrc && isspace(*pszSrc)) pszSrc++;

    memset(szEmailAddr, 0, sizeof(szEmailAddr));
    while(*pszSrc && !isspace(*pszSrc) && *pszSrc != '<' && *pszSrc != ',')
    {        
        *pszEmailValueEnd++ = *pszSrc++;
    }
    *pszEmailValueEnd = '\0';

    if(szEmailAddr[0] == 0) {
        /* email address is not given from input */        
        VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, t_xid,   (char *) "Value for %s was not valid: %s", emailDefaultDNSearchToken, pszCertDN);
        return DIM_LogError(VSAA_ERR_INVALID_DATA);    
    }

    status = VSAAUTIL_AppendCfgAttrEntry(&tmpEmailVerAttrPtr, emailDefaultVerAttr);
    if(status == VSAA_SUCCESS) {
        status = VSAAUTIL_AppendCfgNVPairEntry(&tmpEmailSetAttrPtr, (char*)DIM_GetFDFAttrName(emailDefaultVerAttr), szEmailAddr);
        if(status != VSAA_SUCCESS) {
            VSAAUTIL_FreeCfgAttrList(tmpEmailVerAttrPtr);
            return DIM_LogError(status);
        }
    }
    
    *verAttrListPtr = tmpEmailVerAttrPtr;
    *setAttrListPtr = tmpEmailSetAttrPtr;

    return VSAA_SUCCESS;  
}

VSAA_BOOL
DIM_CompareUserInputWithLDAPEntry(
    const VSAA_NAME           userInput[],
    LDAP                      *pLdapID,
    LDAPMessage               *pEntry,
    const VSAACfgAttrList     *authAttrListPtr)
{
    const char  *pszFDFAttr = NULL;
    const char  *pszUserVal = NULL;    
    const char  *t_xid;
 
    DIM_TRACE("DIM_CompareUserInputWithLDAPEntry()");
    t_xid = FindName(VSAA_XID, strlen (VSAA_XID), userInput);

    const char* inputEncoding = VSAAUTIL_FindUserInputValue(VSAA_ENCODING_NAME, strlen(VSAA_ENCODING_NAME), userInput);

    while(authAttrListPtr != NULL && authAttrListPtr->pszValue != NULL && *authAttrListPtr->pszValue) {
        pszFDFAttr = (char*)DIM_GetFDFAttrName(authAttrListPtr->pszValue);
        if( 
            pszFDFAttr &&
            (pszUserVal = (char*)VSAAUTIL_FindUserInputValue(pszFDFAttr, strlen(pszFDFAttr), userInput))
          ) 
        {
            /* pszUserVal is natively encoded. It may need to be
               converted into UTF-8 if database value is so. */

            char* pszUserValToCmp = NULL;
            if(gDataSourceUseUTF8 == VSAA_TRUE && inputEncoding != NULL && strlen(inputEncoding) > 0) {
                int rc = NativeToUTF8(&pszUserValToCmp, pszUserVal, inputEncoding);
                if(rc != 0) {
                    VS_Log (VS_LOG_WARNING, __LINE__, __FILE__, t_xid,   (char *) "Conversion from native to UTF-8 encoding failed on manual authentication value (%s) with error (%d)", pszUserVal, rc);
                   pszUserValToCmp = (char*)pszUserVal;
                }
            } else {
                pszUserValToCmp = (char*)pszUserVal;
            }

            VSAA_BOOL b = DIM_VerifyUserDataWithLDAPEntry(pLdapID, pEntry, authAttrListPtr->pszValue, pszUserValToCmp); 
            if(pszUserValToCmp != pszUserVal && pszUserValToCmp != NULL)
                free(pszUserValToCmp);
            if(b != VSAA_TRUE) return VSAA_FALSE;            
        } else
            return VSAA_FALSE;

        authAttrListPtr = authAttrListPtr->next;
    }

    return VSAA_TRUE;
}

VSAA_BOOL
DIM_IsLDAPEntryAuthorized(
    LDAP                      *pLdapID,
    LDAPMessage               *pEntry,
    const char                *inputEncoding,
    const VSAACfgNVPairList   *authAttrListPtr)
{
    DIM_TRACE("DIM_IsLDAPEntryAuthorized()");

    while(authAttrListPtr != NULL && authAttrListPtr->pszName != NULL && *authAttrListPtr->pszName) {

        /* The value from configuration file is UTF-8 encoded.
           If the data from LDAP is native, we need to input into 
           native for comparison. */

        char* authValue = authAttrListPtr->pszValue;
        if(gDataSourceUseUTF8 == VSAA_FALSE && inputEncoding != NULL && strlen(inputEncoding) > 0) { // database value is native
            int rc = UTF8ToNative(&authValue, authAttrListPtr->pszValue, inputEncoding);
            if(rc != 0) {
                VS_Log (VS_LOG_WARNING, __LINE__, __FILE__, NULL,   (char *) "Conversion from native to UTF-8 encoding failed on authentication value (%s) with error (%d)", authAttrListPtr->pszValue, rc);
                authValue = authAttrListPtr->pszValue;
            }
        } else {
            authValue = authAttrListPtr->pszValue; // both are UTF-8
        }

        VSAA_BOOL b = DIM_VerifyUserDataWithLDAPEntry(pLdapID, pEntry, authAttrListPtr->pszName, authValue);
        if(authValue != authAttrListPtr->pszValue && authValue != NULL)
            free(authValue);
        if(b != VSAA_TRUE) return VSAA_FALSE;                    

        authAttrListPtr = authAttrListPtr->next;
    }
    
    return VSAA_TRUE;
}

VSAA_STATUS 
VSAA_LINK validateDataSource(DIMCfgLDAPHost *pLdapHostCfg)
{
	VSAA_STATUS	status = VSAA_SUCCESS;
    
    LDAP        *pLdapID=NULL;
    LDAPMessage	*pResult=NULL;
    char        *pszUserDN = NULL;
    char        *pszUserPWD = NULL;
    char        *tmpPszUserDN = NULL;
    char        *tmpPszUserPWD = NULL;
    int         rc = 0;
	
    const char  *pszStatus = VSAA_YES;
    char szTemp[1024];
	
    DIM_TRACE("ValidateDataSource()");
	
	do {
		
		/* preparing the bind DN and PWD */
		if (!*pLdapHostCfg->szBindDN) {
			pszUserDN = pszUserPWD = NULL;
			status = VSAA_LDAP_ERR_CFG;
			break;
		} else {
			if(!VSAAUTIL_StrCaseCmp(pLdapHostCfg->szBindDN, "NULL")) { 
				tmpPszUserDN = pLdapHostCfg->szReadDN;
				tmpPszUserPWD = pLdapHostCfg->szReadPassword;
			} else {
				tmpPszUserDN = pLdapHostCfg->szBindDN;
				tmpPszUserPWD = pLdapHostCfg->szBindPassword;
			}
		}
		
		/* clean up quotes */
		if(tmpPszUserPWD[strlen(tmpPszUserPWD)-1] == CFG_BINDDN_END_CHAR) {
			pszUserPWD = VSAAUTIL_Strdup(&tmpPszUserPWD[1]);
			if(!pszUserPWD) {
				status = VSAA_OUT_OF_MEMORY;
				break;
			} else {
				pszUserPWD[strlen(pszUserPWD)-1]='\0';        /* filter out the trail '"' */
			} 
		}
		
		/* clean up quotes */
		if(tmpPszUserDN[strlen(tmpPszUserDN)-1] == CFG_BINDDN_END_CHAR) {
			pszUserDN = VSAAUTIL_Strdup(&tmpPszUserDN[1]);
			if(!pszUserDN) {
				status = VSAA_OUT_OF_MEMORY;
				break;
			} else {
				pszUserDN[strlen(pszUserDN)-1]='\0';        /* filter out the trail '"' */
			} 
		}
		
		unsigned int nPort = pLdapHostCfg->nSSLEnabled?pLdapHostCfg->nSSLPort:pLdapHostCfg->nPort;
		if(pLdapHostCfg->nSSLEnabled == VSAA_TRUE)
		{        
			if( ldapssl_client_init(pLdapHostCfg->szCertDB, NULL) < 0 )
			{
				VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Could not initialize netscape client certificate database %s", pLdapHostCfg->szCertDB); 
				status = VSAA_LDAP_ERR_INIT;
				break;
			}
			
			pLdapID = ldapssl_init(pLdapHostCfg->szHostName, nPort, 1);
			
		} else {
			
			pLdapID = ldap_init(pLdapHostCfg->szHostName, nPort); 
			
		}
		
		if( !pLdapID )
		{
			VS_Log(VS_LOG_CRITICAL, __LINE__, __FILE__, NULL,   (char *) "Could not initiate ldap seesion with %s", pLdapHostCfg->szHostName);
			status = VSAA_LDAP_ERR_INIT;
			break;
		}
		
		/* set ldap version to 3 */
		
		sprintf(szTemp, "Attempting to set protocol version to 3");
		DIM_TRACE(szTemp);
		
		int version = LDAP_VERSION3;
		rc = ldap_set_option(pLdapID, LDAP_OPT_PROTOCOL_VERSION, &version);
		if (LDAP_SUCCESS != rc) {
			sprintf(szTemp, "Call to set protocol version failed:  %s", ldap_err2string(rc));
			DIM_TRACE(szTemp);
		}
		
		/* authenticate  with the user binding information */
		rc = ldap_simple_bind_s(pLdapID, pszUserDN, pszUserPWD);
		
		
		if( LDAP_SUCCESS != rc ) {
			if (rc == LDAP_PARAM_ERROR) 
				status = VSAA_LDAP_ERR_AUTHENTICATE_FAILED;
			else if (rc == LDAP_SERVER_DOWN) 
				status = VSAA_LDAP_ERR_CONNECT_FAILED;
			else 
				status = VSAA_LDAP_ERR_BIND;
			
			break;
		}
	} while (0);
	
	if ( status != VSAA_SUCCESS)
		DIM_LogError(status);
	
	if ( pszUserDN ) {
		VSAAUTIL_Free(pszUserDN);
	}
	if ( pszUserPWD ) {
		VSAAUTIL_Free(pszUserPWD);
	}
    if ( !pLdapID ) {
		ldap_unbind(pLdapID);
	}
	
    return VSAA_SUCCESS;
}
    
VSAA_STATUS 
VSAA_LINK validateAuthenticationDataSource()
{
    DIMCfgLDAPHost *pLdapHostCfg = &gDIMCfg.verLDAPCfg;
	return validateDataSource(pLdapHostCfg);
}

VSAA_STATUS 
VSAA_LINK validateRegistrationDataSource()
{
    DIMCfgLDAPHost *pLdapHostCfg = &gDIMCfg.regLDAPCfg;
	return validateDataSource(pLdapHostCfg);

    return VSAA_SUCCESS;
}

VSAA_STATUS 
VSAA_LINK validateRecoverDataSource()
{
    DIMCfgLDAPHost *pLdapHostCfg = &gDIMCfg.recoverLDAPCfg;
	return validateDataSource(pLdapHostCfg);

    return VSAA_SUCCESS;
}


void
VSAALDAP_PrintCfgAttrList( const VSAACfgAttrList *attrListPtr)
{
  int i = 0;
  
  if ( VS_Log == NULL ) return;

  while(attrListPtr && attrListPtr->pszValue) {
    if(i == 0)
      VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG     %s ", attrListPtr->pszValue);
    else
      VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)" %s ", attrListPtr->pszValue);
    
    attrListPtr = attrListPtr->next;
    i++;
  }
}

void
VSAALDAP_PrintCfgNVPairList(const VSAACfgNVPairList *attrListPtr)
{
  if ( VS_Log == NULL ) return;

  while(attrListPtr && attrListPtr->pszName) {
    VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG     %s %s", attrListPtr->pszName, attrListPtr->pszValue);
    attrListPtr = attrListPtr->next;
  }
}

void
VSAALDAP_PrintCfgNVTripleList( const VSAACfgNVTripleList *attrListPtr )
{
  if ( VS_Log == NULL ) return;
  while(attrListPtr && attrListPtr->pszName) {
    VS_Log(VS_LOG_DEBUG, __LINE__, __FILE__, NULL, (char *)"CFG     %s %s %d", attrListPtr->pszName, attrListPtr->pszValue, attrListPtr->nValue);
    attrListPtr = attrListPtr->next;
  }
}

static VSAA_STATUS DoPrePickupProcess(const VSAA_NAME userInput[], VSAA_NAME  **augmentedData)
{
  VSAA_STATUS  status = VSAA_SUCCESS;

  // When you customize this code, you can replace the DoVerifyUser with another function
  status = DoVerifyUser(userInput, augmentedData);

  return status;
}

static VSAA_STATUS DoPreRevokeProcess(const VSAA_NAME userInput[], VSAA_NAME  **augmentedData)
{
  VSAA_STATUS  status = VSAA_SUCCESS;

  // When you customize this code, you can replace the DoVerifyUser with another function
  status = DoVerifyUser(userInput, augmentedData);

  return status;
}

static VSAA_STATUS DoPreRenewProcess(const VSAA_NAME userInput[], VSAA_NAME   **augmentedData)
{
  VSAA_STATUS  status = VSAA_SUCCESS;

  // When you customize this code, you can replace the DoVerifyUser with another function
  status = DoVerifyUser(userInput, augmentedData);

  return status;
}
