#ifndef VS_PLATFORM_DEFS_INCLUDED
#define VS_PLATFORM_DEFS_INCLUDED

#include <limits.h>

#if defined(WIN32)

   #include <windows.h>

   #if defined(VS_PLATFORM_DLL_BUILD)
      #define VS_PLATFORM_DLL_ENTRY _declspec(dllexport)
      #define VS_PLATFORM_DLL_ENTRY

   #else
      #define VS_PLATFORM_DLL_ENTRY _declspec(dllimport)
      #define VS_PLATFORM_DLL_ENTRY

   #endif

   #define VS_MAX_PATH                 _MAX_PATH
   #define VS_MAX_FILENAME             _MAX_FNAME
   #define VS_PATH_DELIMITER           '\\'
   #define VS_PATH_DELIMITER_STR       "\\"

#elif defined(SOLARIS) || defined(HPUX) || defined(AIX) || defined(LINUX)

   #define VS_PLATFORM_DLL_ENTRY

   #define VS_MAX_PATH                  PATH_MAX
   #define VS_MAX_FILENAME              PATH_MAX
   #define VS_PATH_DELIMITER            '/'
   #define VS_PATH_DELIMITER_STR        "/"

#endif


// time string length macro (for ctime and asctime)

#define VS_TIME_STRING_LEN 26


#endif // VS_PLATFORM_DEFS_INCLUDED
