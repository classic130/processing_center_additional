/*
 * $Revision: 1.2 $
 * $Header: /cvsroot/mpki/vssc/include/vsopensslext.h,v 1.2 2002/09/25 21:50:43 buildman Exp $
 */

/*--------------------------------------------------------------------\
| Copyright (C) VeriSign, Inc. created 2002. All rights reserved.     |
| This is an unpublished work protected as such under copyright law.  |  
| This work contains proprietary, confidential, and trade secret      |
| information of VeriSign, Inc.  Use, disclosure or reproduction      |
| without the expressed written authorization of VeriSign, Inc.       |
| is prohibited.                                                      |
\--------------------------------------------------------------------*/

/*
 * This file contains functions that are available in SSLC but not openssl
 * and thread setup functions.
 */

#ifndef _VSOPENSSLEXT_H_
#define _VSOPENSSLEXT_H_

#include "openssl/ssl.h"
#include "openssl/x509.h"

#ifdef  __cplusplus
extern "C" {
#endif

/* Thread setup functions to make proper locking */
void vssc_thread_setup();
void vssc_thread_cleanup();

/* The following functions are given by SSLC but not openssl */
int         SSL_get_peer_cert_chain_count(SSL *ssl);
X509 *      SSL_get_peer_cert_chain_item(SSL *ssl,int n);
char *		X509_get_serialNumber_buf(X509 *x,char *buf,int size);
int 		X509_NAME_get_entry_count(X509_NAME *name);
char *		X509_EXTENSION_get_oid_buf(X509_EXTENSION *xe,char *buf,int size);
char *		X509_NAME_ENTRY_get_oid_buf(X509_NAME_ENTRY *ne,char *buf,int size);
char *		X509_NAME_ENTRY_get_data_ptr(X509_NAME_ENTRY *ne);
char *		X509_get_notBefore_str(X509 *x);
char *		X509_get_notBefore_buf(X509 *x,char *buf,int size);
char *		X509_get_notAfter_str(X509 *x);
char *		X509_get_notAfter_buf(X509 *x,char *buf,int size);

#ifdef  __cplusplus
}
#endif

#endif //_VSOPENSSLEXT_H_
