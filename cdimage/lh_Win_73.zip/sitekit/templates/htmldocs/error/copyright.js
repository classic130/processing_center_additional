﻿var COPYRIGHT_STRING = "Copyright © 1998-2010"
