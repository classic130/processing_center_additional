#
# Readme.txt file for installing Luna drivers
#
# VeriSign, Inc.
#
# Last modified: 5-Aug-2003
#

Files included

Name           Description
----------     -----------------------------------------
instgd.pdf     Installation document
lunasys.bff    8.1 Drivers for AIX 5.1
lunasys.depot  8.2 Drivers for HP-UX 11i
lunasys.ds     8.1 Drivers for Solaris 8 or 9
lunasys.zip    8.1 Drivers for Windows 2000 Service Pack 2 or Windows 2003
readme.txt     This file

Instructions

The instructions below are a brief overview of the installation
process intended for those familiar with Luna installation.
For complete installation instructions for all platforms, refer
to the included installation document instgd.pdf. 

1> Remove any previous installations of Luna and reader drivers.
Solaris example:
% pkgrm ltk lca LITpcm lunacr lunacr64

2> Connect the reader.
Connect the reader to the machine using the appropriate cable.  When
connecting a single reader, be sure to connect the cable to the
connector marked "A".

Note: For Windows 2000 installations only, install the Luna drivers
first (step 3) before connecting the reader (step 2).

3> Install Luna drivers.
Copy the Luna drivers software package to a convenient location.
Use the package installation program to install the drivers.
Solaris example:
% cp lunasys.ds /tmp
% pkgadd -d /tmp/lunasys.ds

4> Install reader drivers.
Change directory to the Luna drivers directory.  Use the package
installation program to install the reader drivers.
Solaris example: (64-bit Solaris with Luna Dock reader)
% cd /usr/luna/drivers
% pkgadd -d lunacr64.ds

5> Perform diagnostics.
Use lunadiag to test the reader connections and drivers.
Solaris example:
% cd /usr/luna/bin
% lunadiag

----------------------------------------------------------------------------
