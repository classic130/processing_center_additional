/*
 * $Revision: 1.14 $
 * $Header: /cvsroot/mpki/vssc/include/vssc.h,v 1.14 1999/07/28 23:19:49 tcheung Exp $
 */

/*--------------------------------------------------------------------\
| Copyright (C) VeriSign, Inc. created 1998. All rights reserved.     |
| This is an unpublished work protected as such under copyright law.  |  
| This work contains proprietary, confidential, and trade secret      |
| information of VeriSign, Inc.  Use, disclosure or reproduction      |
| without the expressed written authorization of VeriSign, Inc.       |
| is prohibited.                                                      |
\--------------------------------------------------------------------*/

/*
 * VeriSign Secure Channel API.
 */

#ifndef _VSSC_H_
#define _VSSC_H_

#include <stdio.h>

#ifdef  __cplusplus
extern "C" {
#endif

#ifdef WIN32
#	ifdef VSSC_SOURCE
#		define SC_ENTRY __declspec(dllexport)
#	else
#		define SC_ENTRY
#	endif
#else
#	define SC_ENTRY
#endif


/*********************************************************************/
/*                         DATA DEFINITIONS                          */
/*********************************************************************/

typedef enum
{
  VSSC_LOG_DEBUG,	// Logs debug info (max amount of logging)
  VSSC_LOG_INFO,	// Logs information messages
  VSSC_LOG_ERROR,	// Logs serious errors only
  VSSC_LOG_NONE		// No logging at all
} VSSC_LOG_TYPE;

typedef enum
{
   VSSC_SUCCESS 			= 0,
   SC_ERROR_BASE			= 0x9000,
   SC_ERROR_ALLOC,
   SC_ERROR_SSLC_NOT_SUPPORTED,	
   SC_ERROR_SSLC_CTX_NEW,
   SC_ERROR_SSLC_NEW,
   SC_ERROR_SSLC_BIO_NEW,	
   SC_ERROR_SSL_SSL,	
   SC_ERROR_SSL_SYSCALL,	
   SC_ERROR_SSL_SOCK_CLOSED,
   SC_ERROR_SSLC_ACCEPT,	
   SC_ERROR_SSLC_READ_ERROR,
   SC_ERROR_SSLC_WRITE_ERROR,
   SC_ERROR_SSLC_READ_CERTIFICATE,
   SC_ERROR_SSLC_READ_PRIVATE_KEY,
   SC_ERROR_SSLC_CHECK_PRIVATE_KEY,
   SC_ERROR_SSLC_NEW_ACCEPT,
   SC_ERROR_SSLC_INITIALIZE_ACCEPT,
   SC_ERROR_SSLC_LOAD_ROOT_FILE,	
   SC_ERROR_CANNOT_VERIFY_SERVER,
   SC_ERROR_CANNOT_VERIFY_SERVER_DNS_NAME,
   SC_ERROR_INVALID_ARGUMENT,
   SC_ERROR_MUTEX_CREATE_FAILED,
   SC_ERROR_MUTEX_LOCK_FAILED,
   SC_ERROR_MUTEX_UNLOCK_FAILED,
   SC_ERROR_MUTEX_DESTROY_FAILED
} VSSC_ERROR;

typedef void * VSSC_SOCKET;

/*********************************************************************/
/*                            SOCKET CALLS                           */
/*********************************************************************/

/*
 * SERVER
 *
 * 1. Initialize the server by attaching to the specified port.
 * The server private key and the server certificate chain is loaded
 * from the specified file name.
 */
VSSC_ERROR SC_ENTRY VSSC_StartSrv(
    VSSC_SOCKET *listenSocket,
    unsigned short port,
    const char *password,
    const char *keyFile);

/*
 * 2. Wait in a infinite loop for incoming call.
 */
VSSC_ERROR SC_ENTRY VSSC_IncomingCall(
    VSSC_SOCKET listenSocket,
	VSSC_SOCKET *incomingSocket);

/*
 * 3. For each incoming call, the server can now exchange data with the client
 * securely by using VSSC_Read() and VSSC_Write().
 */


/*
 * CLIENT
 *
 * 1. Call the server with the specified host name and port.
 * The server chain root certificate is loaded from the specified file name.
 */
VSSC_ERROR SC_ENTRY VSSC_Call(
    VSSC_SOCKET *s, 
    unsigned short port, 
    const char *hostName,
    const char *rootFile);

/*
 * 2. Once the call is established, the client can now exchange data with the
 * server securely by using VSSC_Read() and VSSC_Write().
 */



/*
 * Read a buffer from the socket. The call will be blocked until the
 * entire message is read. The caller shall use VSSC_Free() to free
 * up the buffer after use.
 */
VSSC_ERROR SC_ENTRY VSSC_Read(
    VSSC_SOCKET s,
	unsigned char **buffer,
	unsigned long *len);

/*
 * Free a buffer obtained previously from VSSC_Read()
 */
void SC_ENTRY VSSC_Free(
	unsigned char *buffer);

/*
 * Write a buffer to the socket.
 */
VSSC_ERROR SC_ENTRY VSSC_Write(
    VSSC_SOCKET s,
	unsigned char *buffer,
	unsigned long len);


/*
 * Clean up the socket. After the socket is used, this function shall be called
 * to clean up the socket as well as data associated with the call.
 */
void SC_ENTRY VSSC_Close(
    VSSC_SOCKET s); 

/* 
 * Opens a file where subsequent logging message will be written into.
 */
int SC_ENTRY VSSC_OpenLogFile (const char *filename);

/*
 * Sets a file pointer where subsequent logging message will be written into.
 */
int SC_ENTRY VSSC_setLogFP (FILE *fp);

/* 
 * Sets logging level.
 */
int SC_ENTRY VSSC_SetLogLevel (VSSC_LOG_TYPE level);

/* 
 * Closes the log file.
 */
int SC_ENTRY VSSC_CloseLogFile (void);

#ifdef  __cplusplus
}
#endif

#endif /*_VSSC_H_*/
