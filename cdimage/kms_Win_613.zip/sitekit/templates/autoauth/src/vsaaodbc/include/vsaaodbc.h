
/*--------------------------------------------------------------------\
| Copyright (C) VeriSign, Inc. created 1998. All rights reserved.     |
| This is an unpublished work protected as such under copyright law.  |  
| This work contains proprietary, confidential, and trade secret      |
| information of VeriSign, Inc.  Use, disclosure or reproduction      |
| without the expressed written authorization of VeriSign, Inc.       |
| is prohibited.                                                      |
\--------------------------------------------------------------------*/

#ifndef _VSAAODBC_H_
#define _VSAAODBC_H_

#ifdef __cplusplus
extern "C" {
#endif

#define ODBC_MAX_PATH                  1024
#define ODBC_MAX_SQL_LENGTH            8096
#define ODBC_MAX_DATA_LENGTH           8096
#define ODBC_MAX_LOGIN_LENGTH          256
#define ODBC_LOG                       ("ODBC_ERROR_LOG")
#define ODBC_LOG_LEVEL                 ("ODBC_LOG_LEVEL")
#define ODBC_LOG_FILE_NAME             "vsaaodbc.log"

#define ODBC_AUTOAUTH_CFG_DSN                   ("VER_REG_DATABASE")
#define ODBC_AUTOAUTH_CFG_LOGIN_NAME            ("VER_REG_DBUSERNAME")
#define ODBC_AUTOAUTH_CFG_LOGIN_PWD             ("VER_REG_DBPASSWORD")

#define ODBC_RECOVER_CFG_DSN                   ("RECOVER_DATABASE")
#define ODBC_RECOVER_CFG_LOGIN_NAME            ("RECOVER_DBUSERNAME")
#define ODBC_RECOVER_CFG_LOGIN_PWD             ("RECOVER_DBPASSWORD")

// Customizations for VeriSign ECA Service
#define ODBC_RECOVER_CFG_ENCKEY_SLOT           ("HARDWARE_ENCRYPT_SLOT_ID")
#define ODBC_RECOVER_CFG_ENCKEY_DN             ("HARDWARE_ENCRYPT_KEY_DN")
// end custom

#define ODBC_SQL_FROM_WHERE	       ("ODBC_SQL_FROM_WHERE")
#define ODBC_SQL_UPDATE_WHERE 	       ("ODBC_SQL_UPDATE_WHERE")
#define ODBC_UPDATE_TABLE_NAME	       ("ODBC_UPDATE_TABLE_NAME")
#define ODBC_ATTR_MAP                  ("ODBC_ATTR_MAP")
#define ODBC_ATTR_SET                  ("ODBC_ATTR_SET")
#define ODBC_ATTR_GET                  ("ODBC_ATTR_GET")
#define ODBC_ATTR_REG                  ("ODBC_ATTR_REG")
#define ODBC_ATTR_VER                  ("ODBC_ATTR_VER")
#define ODBC_ATTR_UPD                  ("ODBC_ATTR_UPD")
#define ODBC_ATTR_AUTH                 ("ODBC_ATTR_VER")
#define ODBC_ATTR_MANUAL_AUTH          ("ODBC_ATTR_MANUAL_VER")
#define ODBC_ATTR_CERT_STATUS          ("ODBC_ATTR_CERT_STATUS")
#define ODBC_VALUE_CERT_STATUS_VALID   ("ODBC_VALUE_CERT_STATUS_VALID")
#define ODBC_VALUE_CERT_STATUS_INVALID ("ODBC_VALUE_CERT_STATUS_INVALID")
#define ODBC_VALUE_CERT_STATUS_REVOKED ("ODBC_VALUE_CERT_STATUS_REVOKED")


typedef struct
{
    /* database and SQL information */
    
    char autoAuthDatabase[ODBC_MAX_PATH];
    char autoAuthUsername[ODBC_MAX_LOGIN_LENGTH];
    char autoAuthPassword[ODBC_MAX_LOGIN_LENGTH];

    char recoverDatabase[ODBC_MAX_PATH];
    char recoverUsername[ODBC_MAX_LOGIN_LENGTH];
    char recoverPassword[ODBC_MAX_LOGIN_LENGTH];

    // Customizations for VeriSign ECA Service
	char ecaEncryptionKeySlot[1];
	char ecaEncryptionKeyDN[ODBC_MAX_LOGIN_LENGTH];
	// end custom
    
    char fromWhereSqlCommand[ODBC_MAX_SQL_LENGTH];     /* use for verification */
    char updateWhereSqlCommand[ODBC_MAX_SQL_LENGTH];   /* use for registration */

    
    /* fields derived from fromWhereSqlCommand */

    char fromSqlCommand[ODBC_MAX_SQL_LENGTH];
    char whereSqlCommand[ODBC_MAX_SQL_LENGTH];
    VSAACfgAttrList*      tableNameListPtr;
    VSAACfgAttrList*      whereAttrListPtr;   

    /* fields derived from UpdateWhereSqlCommand */

    char updWhereSqlCommand[ODBC_MAX_SQL_LENGTH];
    char updTableName[ODBC_MAX_LOGIN_LENGTH];
    VSAACfgAttrList*      updWhereAttrListPtr;   


    /* attributes for AA rules */

    VSAACfgNVPairList*    mapAttrListPtr;
    VSAACfgNVPairList*    authAttrListPtr;
    VSAACfgAttrList*      manualAuthAttrListPtr;
    VSAACfgAttrList*      getAttrListPtr;
    VSAACfgNVPairList*    setAttrListPtr;
    
    /* 
        attributes for registration 
        there should must be one attribute for certificate.
        This field is listed seperately out of the list
        for better performance in implementation.
    */

    VSAACfgAttrList*      updAttrListPtr;
    char                  certAttrName[ODBC_MAX_PATH];
    char                  certSerialAttrName[ODBC_MAX_PATH];
    
    /* fields for certificate status */
    
    char certStatusAttrName[ODBC_MAX_PATH];
    char certStatusValid[ODBC_MAX_PATH];
    char certStatusInvalid[ODBC_MAX_PATH];
    char certStatusRevoked[ODBC_MAX_PATH];

    /* some optional fields */

    VSAACfgNVTripleList*  regAttrListPtr;
    VSAACfgAttrList*      verAttrListPtr;
    
    /* log flag */

    VSAA_BOOL             nLogEnabled;
    unsigned int          nLogLevel;

    VSAA_BOOL             nPrePickupProcess;
    VSAA_BOOL             nPreRevokeProcess;
    VSAA_BOOL             nPreRenewalProcess;

} ODBCCfg, *ODBCCfgPtr;

/* Configuration related functions */

void        ODBC_SetDefaultCfg(ODBCCfg* pODBCCfg);
void        ODBC_FreeCfg(ODBCCfg* pODBCCfg);
void        ODBC_PrintCfg();
VSAA_STATUS ODBC_ValidateCfg(ODBCCfg* pODBCCfg);
VSAA_STATUS ODBC_ReadConfigFile(const char* pszServiceCfgFileName);
VSAA_STATUS ODBC_ValidateCfg(ODBCCfg* pODBCCfg);
VSAA_BOOL   ODBC_IsFDFFieldPresent(const VSAACfgAttrList *attrListPtr, const VSAACfgNVPairList *mapAttrListPtr);

VSAA_STATUS ODBC_InitDb();
void        ODBC_CleanUpDb(void);

/* The caller is responsible to free ppszSql */
VSAA_STATUS ODBC_PopulateWhereSQLStatement(char *whereStatementType, char **ppszSql, const VSAA_NAME userInput[]);

VSAA_BOOL
ODBC_IsFDFFieldPresent(
    const VSAACfgAttrList   *attrListPtr, 
    const VSAACfgNVPairList *mapAttrListPtr);

VSAA_STATUS
ODBC_QueryDatabase(
    unsigned int *queryResultCnt,
    char         **ppSelectSQLStatement,
    const char   *whereSQLStatement);

VSAA_BOOL
ODBC_CompareUserInputWithDatabaseEntry(
    const VSAA_NAME           userInput[],
    const char                *whereSQLStatement,
    const VSAACfgAttrList     *authAttrListPtr);

VSAA_BOOL
ODBC_IsDatabaseEntryAuthorized(
    const char                *inputEncoding, 
    const char                *whereSQLStatement,
    const VSAACfgNVPairList   *authAttrListPtr);

VSAA_STATUS
ODBC_AugmentUserDataWithDatabaseEntry(
    VSAA_NAME                 **augmentedData,
    const char                *inputEncoding, 
    const char                *pszAuthValue,
    const char                *whereSqlStatement,
    const VSAACfgNVPairList   *setAttrListPtr,
    const VSAACfgAttrList     *getAttrListPtr);

VSAA_STATUS    
ODBC_UpdateDatabaseEntry(
    char                   **ppUpdateSQLStatement,
    const VSAA_NAME        userInput[],
    const char             *certBase64, 
    const char             *certStatus,
    const char             *whereSQLStatement,
    const VSAACfgAttrList  *updAttrListPtr);

VSAA_STATUS    
ODBC_RevokeDatabaseEntry(
    char                   **ppRevokeSQLStatement,
    const VSAA_NAME        userInput[],
    const char             *certStatus,
    const char             *whereSQLStatement);

VSAA_STATUS ODBC_LogError(VSAA_STATUS status, const char* msg);

VSAA_STATUS 
ODBCKMInsertRow(const VSAA_NAME  subInfo[]);

VSAA_STATUS 
ODBCKMUpdateToIssued(const VSAA_NAME  subInfo[]);

VSAA_STATUS 
ODBCKMUpdateToPending(const VSAA_NAME  subInfo[]);

VSAA_STATUS 
ODBCKMRetrievePwd(const VSAA_NAME  subInfo[]);

VSAA_STATUS 
ODBCKMRecoverKeyAndCert(const VSAA_NAME  subInfo[]);

VSAA_STATUS 
ODBCKMUpdateCertForPickup(const VSAA_NAME  subInfo[]);

VSAA_STATUS 
ODBCKMFindEntryByWebPin(const VSAA_NAME  subInfo[]);

VSAA_STATUS 
ODBCKMDeleteFailedEntry(const VSAA_NAME  subInfo[]);

VSAA_STATUS 
ODBCKMChangePickupPassword(const VSAA_NAME  subInfo[]);

VSAA_STATUS 
KMOperation(const VSAA_NAME subInfo[], const char* operation);

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif /* _VSAALDAP_H */
