
INSERT INTO Addresses ( 
  AddressID,
  EmployeeID,
  PIN,
  FirstName,
  LastName,
  MiddleName,
  JobTitle,
  Address,
  City,
  StateOrProvince,
  PostalCode,
  Country,
  EmailAddress,
  HomePhone,
  CommonName
) 
VALUES (
  VSAA_ADDRESS_ID.nextval,
  1001,
  'password',
  'NewUsr1',
  'Tester',
  'A.',
  'Tester',
  '1350 Charleston Road',
  'Mountain View',
  'CA',
  '94043',
  'US',
  'newusr1tester@foo.bar.com',
  '(650)123-4567',
  'NewUsr1 Tester'
);
 
exit; 
